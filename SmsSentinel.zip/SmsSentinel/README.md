# SMS Sentinel

Rule-based SMS alerts for Android 16 (Samsung A55). Fully offline: no INTERNET permission.

UI is Jetpack Compose + Material 3 (icy blue/white, a snowfall background, and a baby
penguin that waddles during brief loading moments). All matching/notify/alarm/reminder/
forward logic is unchanged from the original app — this update only touches the screens.

Each rule = who the SMS is from + what it contains + what to do:
notification, loud alarm, repeating reminder (until a stop message arrives), and/or forward to another number.
Two example rules are created on first launch.

## Build in Android Studio
File > Open this folder, wait for Gradle sync, then Build > Build APK(s).
APK: app/build/outputs/apk/debug/app-debug.apk

## Build on GitHub (phone friendly)
Upload SmsSentinel.zip to a private repo and use the workflow from the chat (unzips and builds), or push this folder
as-is and run Actions > Build APK.

## On the phone
1. Install the APK (allow unknown apps; Play Protect may warn, since it can read SMS).
2. App info > menu (3 dots) > Allow restricted settings, if permissions are greyed out.
3. Open the app > Grant permissions > Battery Unrestricted. Samsung: add to Never sleeping apps.
4. Edit or add rules, then use "Test alert now".
