# Guardly

Smart SMS actions for Android 16 (tested target: Samsung Galaxy A55). Fully offline: the app declares no network permission.

A **rule** = who the SMS is from + what it says + what to do:

* show a notification,
* ring a loud alarm (full-screen, with snooze),
* repeat a reminder until a "stop" SMS arrives or you tap Mark as done,
* forward the SMS to another number (optionally with a prefix such as `AIRTEL OTP`).

Rules can be limited to certain hours, ignore repeat matches (cooldown) and switch themselves off after N triggers.
Two editable example rules are created on first launch. Settings has a permission checklist, tests, backup/restore.

## Updating the app instead of reinstalling

Android only installs a new APK over an old one when **all three** are true:

1. same package name (`com.example.smssentinel`, set in `app/build.gradle.kts`),
2. same signing key (`app/sentinel.jks`, committed to the repo on purpose),
3. a higher version code (computed automatically from the build time).

Never change the package name, never delete or regenerate `sentinel.jks`, and keep the repository **private**
(whoever has the key can sign an update for the app). Settings > About shows the signing key of the installed app;
the GitHub build log prints the key of the new APK. If both match, the update will install.

Builds made before this project had the fixed key were signed with random keys, so uninstall once; after that every build updates in place.

## Build in Android Studio
File > Open this folder, wait for Gradle sync, then Build > Build APK(s). APK: `app/build/outputs/apk/debug/app-debug.apk`.

## Build on GitHub (phone friendly)
Push this folder to a private repo (workflow included: Actions > Build APK > Run workflow), or keep `SmsSentinel.zip`
in the repo and use `build-from-zip.yml`. Download the `Guardly-apk` artifact, unzip it and install `Guardly.apk`.

## On the phone
1. Install the APK (allow unknown apps; Play Protect may warn because the app reads SMS).
2. If permissions are greyed out: Settings > Apps > Guardly > 3-dot menu > Allow restricted settings.
3. Open Guardly > Settings > Setup and allow everything. Battery: Unrestricted; Samsung: add to Never sleeping apps.
4. Edit or add rules, then use Send test alert.
