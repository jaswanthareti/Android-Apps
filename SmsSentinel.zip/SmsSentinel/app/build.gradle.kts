import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.smssentinel"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.example.smssentinel"
        minSdk = 26
        targetSdk = 36
        // Every build gets a higher versionCode (minutes since 1970), so a new APK is always
        // accepted as an update over the installed one. Never change applicationId or sentinel.jks.
        versionCode = (System.currentTimeMillis() / 60000L).toInt()
        versionName = "1.1." + SimpleDateFormat("yyMMdd.HHmm", Locale.US).format(Date())
    }

    // One fixed signing key for every build, so new APKs can update the installed app.
    signingConfigs {
        create("fixed") {
            storeFile = file("sentinel.jks")
            storePassword = "sentinel-store-2026"
            keyAlias = "sentinel"
            keyPassword = "sentinel-key-2026"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("fixed")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("fixed")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
// No dependencies on purpose: the app is tiny and needs no internet.
