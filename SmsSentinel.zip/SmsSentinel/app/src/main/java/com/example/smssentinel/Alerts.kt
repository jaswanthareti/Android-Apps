package com.example.smssentinel

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import java.util.Calendar

object Alerts {
    const val CH_ALERT = "alerts"
    const val CH_ALARM = "alarm"
    const val ACTION_FIRE = "com.example.smssentinel.FIRE"
    const val ACTION_STOP = "com.example.smssentinel.STOP"
    const val ACTION_DISMISS = "com.example.smssentinel.DISMISS"
    const val EXTRA_RULE = "rule"

    private const val FLAGS = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

    /** Quiet hours: 11 PM to 7 AM. */
    fun isQuiet(): Boolean {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return h >= 23 || h < 7
    }

    private fun createChannels(nm: NotificationManager) {
        nm.createNotificationChannel(
            NotificationChannel(CH_ALERT, "Alerts", NotificationManager.IMPORTANCE_HIGH)
        )
        val alarm = NotificationChannel(CH_ALARM, "Loud alarms", NotificationManager.IMPORTANCE_HIGH)
        alarm.setSound(
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        alarm.enableVibration(true)
        alarm.vibrationPattern = longArrayOf(0, 600, 400, 600, 400, 600)
        nm.createNotificationChannel(alarm)
    }

    private fun ruleIntent(ctx: Context, action: String, id: Int): Intent =
        Intent(ctx, ReminderReceiver::class.java).setAction(action).putExtra(EXTRA_RULE, id)

    private fun action(ctx: Context, label: String, pi: PendingIntent): Notification.Action =
        Notification.Action.Builder(
            Icon.createWithResource(ctx, android.R.drawable.ic_menu_close_clear_cancel), label, pi
        ).build()

    /** Shows the alert for a rule. [force] ignores quiet hours (used by the Test button). */
    fun fire(ctx: Context, rule: Rule, text: String, force: Boolean = false) {
        if (rule.quiet && !force && isQuiet()) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        createChannels(nm)

        val open = PendingIntent.getActivity(
            ctx, rule.id * 10 + 2, Intent(ctx, MainActivity::class.java), FLAGS
        )
        val dismiss = PendingIntent.getBroadcast(
            ctx, rule.id * 10 + 4, ruleIntent(ctx, ACTION_DISMISS, rule.id), FLAGS
        )
        val b = Notification.Builder(ctx, if (rule.alarm) CH_ALARM else CH_ALERT)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(rule.name)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setAutoCancel(!rule.alarm)
            .addAction(action(ctx, if (rule.alarm) "Silence" else "Dismiss", dismiss))

        if (rule.remind && isReminding(ctx, rule.id)) {
            val stop = PendingIntent.getBroadcast(
                ctx, rule.id * 10 + 3, ruleIntent(ctx, ACTION_STOP, rule.id), FLAGS
            )
            b.addAction(action(ctx, "Stop reminders", stop))
        }
        if (rule.alarm) {
            b.setCategory(Notification.CATEGORY_ALARM)
            b.setTimeoutAfter(10 * 60 * 1000L)  // stop ringing after 10 minutes
        }
        val n = b.build()
        if (rule.alarm) n.flags = n.flags or Notification.FLAG_INSISTENT  // sound repeats until silenced
        nm.notify(rule.id, n)
    }

    // ---------- repeating reminders ----------

    fun isReminding(ctx: Context, id: Int) = RuleStore.prefs(ctx).getBoolean("rem_$id", false)

    fun reminderText(ctx: Context, id: Int): String = RuleStore.prefs(ctx).getString("remtext_$id", "") ?: ""

    fun startReminder(ctx: Context, rule: Rule, text: String) {
        val wasActive = isReminding(ctx, rule.id)
        RuleStore.prefs(ctx).edit()
            .putBoolean("rem_${rule.id}", true)
            .putString("remtext_${rule.id}", text)
            .apply()
        if (!wasActive) {
            ActivityLog.add(ctx, "Reminders started: ${rule.name}")
            scheduleNext(ctx, rule)
        }
    }

    fun stopReminder(ctx: Context, id: Int, why: String) {
        val was = isReminding(ctx, id)
        RuleStore.prefs(ctx).edit().putBoolean("rem_$id", false).apply()
        ctx.getSystemService(AlarmManager::class.java).cancel(firePi(ctx, id))
        ctx.getSystemService(NotificationManager::class.java).cancel(id)
        if (was) ActivityLog.add(ctx, "Reminders stopped ($why): rule #$id")
    }

    private fun firePi(ctx: Context, id: Int): PendingIntent =
        PendingIntent.getBroadcast(ctx, id * 10 + 1, ruleIntent(ctx, ACTION_FIRE, id), FLAGS)

    fun scheduleNext(ctx: Context, rule: Rule) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val pi = firePi(ctx, rule.id)
        val at = System.currentTimeMillis() + maxOf(1, rule.intervalMin) * 60_000L
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }
}
