package com.example.smssentinel.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

private data class Flake(
    val x: Float,
    val y: Float,
    val radius: Float,
    val speed: Float,
    val driftAmp: Float,
    val driftFreq: Float,
    val phase: Float,
    val alpha: Float
)

/**
 * A quiet, slow snowfall drawn behind the screen content. Purely decorative:
 * no state, no interaction, cheap to redraw.
 */
@Composable
fun SnowBackground(modifier: Modifier = Modifier, flakeCount: Int = 36) {
    val flakes = remember(flakeCount) {
        List(flakeCount) {
            Flake(
                x = Random.nextFloat(),
                y = Random.nextFloat(),
                radius = Random.nextFloat() * 3.5f + 2f,
                speed = Random.nextFloat() * 0.5f + 0.25f,
                driftAmp = Random.nextFloat() * 0.03f + 0.01f,
                driftFreq = Random.nextFloat() * 1.5f + 0.5f,
                phase = Random.nextFloat() * (2f * PI.toFloat()),
                alpha = Random.nextFloat() * 0.5f + 0.35f
            )
        }
    }
    val infinite = rememberInfiniteTransition(label = "snowTime")
    val time by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(durationMillis = 14000, easing = LinearEasing)),
        label = "snowTimeAnim"
    )
    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        flakes.forEach { f ->
            val progress = (f.y + time * f.speed) % 1f
            val drift = sin(time * 2f * PI.toFloat() * f.driftFreq + f.phase) * f.driftAmp
            var cx = (f.x + drift) % 1f
            if (cx < 0f) cx += 1f
            drawCircle(
                color = Color.White.copy(alpha = f.alpha),
                radius = f.radius,
                center = Offset(cx * w, progress * h)
            )
        }
    }
}
