package com.example.smssentinel.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

enum class MascotMood { Calm, Alert, Sleep }

/**
 * "Pip", the Sentinel penguin. Hand-drawn on a 100x100 grid: breathing bob, drifting gaze,
 * random-looking blinks, a waving flipper, an aurora scarf and a shield badge on the belly.
 */
@Composable
fun Mascot(modifier: Modifier = Modifier, size: Dp = 96.dp, mood: MascotMood = MascotMood.Calm) {
    val p = Sentinel.colors
    val t = rememberInfiniteTransition(label = "mascot")
    val bob by t.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(if (mood == MascotMood.Sleep) 3200 else 2200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "bob"
    )
    val look by t.animateFloat(
        -1f, 1f,
        infiniteRepeatable(tween(5200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "look"
    )
    val wave by t.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(if (mood == MascotMood.Alert) 380 else 1100, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "wave"
    )
    val blink by t.animateFloat(
        0f, 1f,
        infiniteRepeatable(
            keyframes {
                durationMillis = 4200
                0f at 0
                0f at 3850
                1f at 3980
                0f at 4120
            }
        ),
        label = "blink"
    )

    val navy = Color(0xFF1B2B4D)
    val navyHi = Color(0xFF30487A)
    val cream = Color(0xFFF5F9FF)
    val ink = Color(0xFF0B1220)
    val orange = Color(0xFFFF8A3D)
    val scarf = if (mood == MascotMood.Alert) listOf(p.coral, p.amber) else p.aurora

    Canvas(modifier.size(size)) {
        val u = this.size.minDimension / 100f
        fun o(x: Float, y: Float) = Offset(x * u, y * u)
        fun sz(w: Float, h: Float) = Size(w * u, h * u)

        // ground shadow
        drawOval(Color.Black.copy(alpha = 0.22f - bob * 0.05f), o(30f + bob * 1.5f, 91.5f), sz(40f - bob * 3f, 6f))

        translate(top = (bob - 0.5f) * 2.4f * u) {
            // feet
            drawOval(orange, o(34f, 88f), sz(15f, 7f))
            drawOval(orange, o(51f, 88f), sz(15f, 7f))

            // flippers
            val flap = if (mood == MascotMood.Alert) 42f else 9f
            rotate(degrees = 14f + wave * flap, pivot = o(25f, 52f)) {
                drawOval(navy, o(15f, 52f), sz(11f, 28f))
            }
            rotate(degrees = -14f - (1f - wave) * (flap * 0.4f), pivot = o(75f, 52f)) {
                drawOval(navy, o(74f, 52f), sz(11f, 28f))
            }

            // body
            drawOval(
                Brush.radialGradient(listOf(navyHi, navy), center = o(40f, 34f), radius = 64f * u),
                o(21f, 20f), sz(58f, 72f)
            )
            // belly + face mask
            drawOval(cream, o(33f, 62f), sz(34f, 29f))
            drawOval(cream, o(30f, 35f), sz(40f, 28f))

            // cheeks
            drawCircle(p.coral.copy(alpha = 0.30f), 4.2f * u, o(35f, 54f))
            drawCircle(p.coral.copy(alpha = 0.30f), 4.2f * u, o(65f, 54f))

            // eyes
            val eyeY = 48f
            for (ex in listOf(41f, 59f)) {
                if (mood == MascotMood.Sleep) {
                    val lid = Path().apply {
                        moveTo(o(ex - 4.2f, eyeY).x, o(ex - 4.2f, eyeY).y)
                        cubicTo(
                            o(ex - 2f, eyeY + 4f).x, o(ex - 2f, eyeY + 4f).y,
                            o(ex + 2f, eyeY + 4f).x, o(ex + 2f, eyeY + 4f).y,
                            o(ex + 4.2f, eyeY).x, o(ex + 4.2f, eyeY).y
                        )
                    }
                    drawPath(lid, ink, style = Stroke(width = 1.7f * u, cap = StrokeCap.Round))
                } else {
                    val big = if (mood == MascotMood.Alert) 1.18f else 1f
                    val open = (1f - blink).coerceAtLeast(0.08f)
                    val w = 6.4f * big
                    val h = 7.6f * big * open
                    drawOval(ink, o(ex - w / 2f + look * 1.3f, eyeY - h / 2f), sz(w, h))
                    if (open > 0.5f) {
                        drawCircle(Color.White, 1.45f * u, o(ex + look * 1.3f - 1.1f, eyeY - 1.6f * big))
                    }
                }
            }

            // beak
            val beak = Path().apply {
                moveTo(o(45f, 54f).x, o(45f, 54f).y)
                cubicTo(o(47.5f, 52.2f).x, o(47.5f, 52.2f).y, o(52.5f, 52.2f).x, o(52.5f, 52.2f).y, o(55f, 54f).x, o(55f, 54f).y)
                cubicTo(o(54f, 58.5f).x, o(54f, 58.5f).y, o(52f, 61f).x, o(52f, 61f).y, o(50f, 61f).x, o(50f, 61f).y)
                cubicTo(o(48f, 61f).x, o(48f, 61f).y, o(46f, 58.5f).x, o(46f, 58.5f).y, o(45f, 54f).x, o(45f, 54f).y)
                close()
            }
            drawPath(beak, Brush.verticalGradient(listOf(p.amber, orange), startY = 52f * u, endY = 61f * u))

            // aurora scarf
            val scarfPath = Path().apply {
                moveTo(o(26f, 63f).x, o(26f, 63f).y)
                cubicTo(o(36f, 72f).x, o(36f, 72f).y, o(64f, 72f).x, o(64f, 72f).y, o(74f, 63f).x, o(74f, 63f).y)
            }
            drawPath(
                scarfPath,
                Brush.horizontalGradient(scarf, startX = 26f * u, endX = 74f * u),
                style = Stroke(width = 8f * u, cap = StrokeCap.Round)
            )
            rotate(degrees = -10f, pivot = o(66f, 68f)) {
                drawRoundRect(
                    Brush.verticalGradient(listOf(scarf.last(), scarf[scarf.size / 2]), startY = 68f * u, endY = 86f * u),
                    topLeft = o(62f, 68f), size = sz(8f, 18f), cornerRadius = CornerRadius(4f * u, 4f * u)
                )
            }

            // shield badge
            val shield = Path().apply {
                moveTo(o(50f, 74f).x, o(50f, 74f).y)
                lineTo(o(56f, 76.5f).x, o(56f, 76.5f).y)
                lineTo(o(56f, 80.5f).x, o(56f, 80.5f).y)
                cubicTo(o(56f, 85f).x, o(56f, 85f).y, o(53f, 87.5f).x, o(53f, 87.5f).y, o(50f, 89f).x, o(50f, 89f).y)
                cubicTo(o(47f, 87.5f).x, o(47f, 87.5f).y, o(44f, 85f).x, o(44f, 85f).y, o(44f, 80.5f).x, o(44f, 80.5f).y)
                lineTo(o(44f, 76.5f).x, o(44f, 76.5f).y)
                close()
            }
            drawPath(shield, Brush.linearGradient(listOf(p.teal, p.sky), start = o(44f, 74f), end = o(56f, 89f)))
            val tick = Path().apply {
                moveTo(o(47.2f, 81.5f).x, o(47.2f, 81.5f).y)
                lineTo(o(49.4f, 83.7f).x, o(49.4f, 83.7f).y)
                lineTo(o(53f, 79.2f).x, o(53f, 79.2f).y)
            }
            drawPath(tick, Color.White, style = Stroke(width = 1.5f * u, cap = StrokeCap.Round))

            // alert sparks
            if (mood == MascotMood.Alert) {
                val a = 0.35f + wave * 0.65f
                val st = Stroke(width = 2.2f * u, cap = StrokeCap.Round)
                fun spark(x1: Float, y1: Float, x2: Float, y2: Float) {
                    val s = Path().apply {
                        moveTo(o(x1, y1).x, o(x1, y1).y); lineTo(o(x2, y2).x, o(x2, y2).y)
                    }
                    drawPath(s, p.coral.copy(alpha = a), style = st)
                }
                spark(50f, 15f, 50f, 8f); spark(35f, 19f, 29f, 13f); spark(65f, 19f, 71f, 13f)
            }
        }
    }
}

/** Radar-style orb: pulsing rings and a rotating sweep around the mascot. */
@Composable
fun SentinelOrb(modifier: Modifier = Modifier, size: Dp = 210.dp, mood: MascotMood = MascotMood.Calm) {
    val p = Sentinel.colors
    val inf = rememberInfiniteTransition(label = "orb")
    val ring by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(3600, easing = LinearEasing)), label = "ring")
    val sweep by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(7000, easing = LinearEasing)), label = "sweep")
    val tint = if (mood == MascotMood.Alert) p.coral else p.teal

    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val c = center
            val r = this.size.minDimension / 2f
            drawCircle(
                Brush.radialGradient(listOf(tint.copy(alpha = 0.30f), tint.copy(alpha = 0.07f), Color.Transparent), center = c, radius = r),
                radius = r, center = c
            )
            for (i in 0..2) {
                val f = (ring + i / 3f) % 1f
                drawCircle(
                    tint.copy(alpha = (1f - f) * 0.5f),
                    radius = r * (0.46f + 0.54f * f), center = c,
                    style = Stroke(width = 1.5.dp.toPx())
                )
            }
            rotate(degrees = sweep, pivot = c) {
                drawCircle(
                    Brush.sweepGradient(listOf(Color.Transparent, Color.Transparent, tint.copy(alpha = 0.40f)), center = c),
                    radius = r * 0.94f, center = c
                )
            }
            drawCircle(
                Brush.radialGradient(listOf(p.surface, p.bg), center = c, radius = r * 0.52f),
                radius = r * 0.52f, center = c
            )
            drawCircle(
                Brush.sweepGradient(p.aurora + p.aurora.first(), center = c),
                radius = r * 0.52f, center = c, style = Stroke(width = 2.dp.toPx())
            )
        }
        Mascot(size = size * 0.52f, mood = mood)
    }
}

@Composable
fun MascotLoader(modifier: Modifier = Modifier, label: String = "Loading…") {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        SentinelOrb(size = 190.dp)
        Text(label, style = MaterialTheme.typography.titleMedium, color = Sentinel.colors.inkSoft)
    }
}
