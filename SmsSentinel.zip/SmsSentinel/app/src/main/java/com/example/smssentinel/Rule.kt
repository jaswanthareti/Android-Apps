package com.example.smssentinel

import android.content.Context
import android.telephony.PhoneNumberUtils
import org.json.JSONObject

data class Rule(
    var id: Int = 0,
    var name: String = "New rule",
    var enabled: Boolean = true,
    // --- what to match ---
    var sender: String = "",          // blank = any sender
    var content: String = "",         // blank = any text
    var regex: Boolean = false,       // content/stopContent are regular expressions
    // --- what to do ---
    var notify: Boolean = true,
    var alarm: Boolean = false,
    var remind: Boolean = false,
    var intervalMin: Int = 60,
    var quiet: Boolean = false,       // pause alerts 11 PM - 7 AM
    var stopSender: String = "",      // reminder stops when an SMS matches these
    var stopContent: String = "",
    var forward: Boolean = false,
    var forwardTo: String = "",
    var prefix: String = ""
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("name", name).put("enabled", enabled)
        .put("sender", sender).put("content", content).put("regex", regex)
        .put("notify", notify).put("alarm", alarm).put("remind", remind)
        .put("intervalMin", intervalMin).put("quiet", quiet)
        .put("stopSender", stopSender).put("stopContent", stopContent)
        .put("forward", forward).put("forwardTo", forwardTo).put("prefix", prefix)

    fun summary(): String {
        val acts = mutableListOf<String>()
        if (notify) acts.add("Notify")
        if (alarm) acts.add("Loud alarm")
        if (remind) acts.add("Remind every $intervalMin min")
        if (forward) acts.add("Forward to " + forwardTo.ifBlank { "(no number)" })
        val textPart = content.ifBlank { "any" } + (if (regex && content.isNotBlank()) " (regex)" else "")
        return "From: " + sender.ifBlank { "any" } + "\nText: " + textPart +
            "\nDoes: " + acts.joinToString(", ").ifBlank { "nothing" }
    }

    companion object {
        fun fromJson(o: JSONObject) = Rule(
            id = o.optInt("id"),
            name = o.optString("name", "Rule"),
            enabled = o.optBoolean("enabled", true),
            sender = o.optString("sender", ""),
            content = o.optString("content", ""),
            regex = o.optBoolean("regex", false),
            notify = o.optBoolean("notify", true),
            alarm = o.optBoolean("alarm", false),
            remind = o.optBoolean("remind", false),
            intervalMin = o.optInt("intervalMin", 60),
            quiet = o.optBoolean("quiet", false),
            stopSender = o.optString("stopSender", ""),
            stopContent = o.optString("stopContent", ""),
            forward = o.optBoolean("forward", false),
            forwardTo = o.optString("forwardTo", ""),
            prefix = o.optString("prefix", "")
        )
    }
}

object Matcher {
    private fun digits(s: String) = s.filter { it.isDigit() }

    /** Blank pattern = any sender. Names (with letters) match if the sender CONTAINS the text. */
    fun senderMatches(ctx: Context, sender: String, pattern: String): Boolean {
        val p = pattern.trim()
        if (p.isEmpty()) return true
        if (p.any { it.isLetter() }) return sender.contains(p, ignoreCase = true)
        val dp = digits(p)
        return PhoneNumberUtils.compare(ctx, sender, p) || (dp.length >= 7 && digits(sender).endsWith(dp))
    }

    /** Blank pattern = any text. */
    fun contentMatches(body: String, pattern: String, regex: Boolean): Boolean {
        val p = pattern.trim()
        if (p.isEmpty()) return true
        if (!regex) return body.contains(p, ignoreCase = true)
        return try {
            Regex(p, setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).containsMatchIn(body)
        } catch (e: Exception) {
            false
        }
    }

    fun validRegex(p: String): Boolean = try { Regex(p); true } catch (e: Exception) { false }

    fun triggers(ctx: Context, r: Rule, sender: String, body: String): Boolean {
        // A rule with no sender AND no text would match every SMS: never allow that.
        if (r.sender.isBlank() && r.content.isBlank()) return false
        return senderMatches(ctx, sender, r.sender) && contentMatches(body, r.content, r.regex)
    }

    fun stops(ctx: Context, r: Rule, sender: String, body: String): Boolean {
        if (r.stopSender.isBlank() && r.stopContent.isBlank()) return false
        return senderMatches(ctx, sender, r.stopSender) && contentMatches(body, r.stopContent, r.regex)
    }
}
