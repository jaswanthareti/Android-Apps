package com.example.smssentinel

import android.view.View
import android.widget.LinearLayout
import android.widget.PopupMenu

/** Rules tab: every rule as a card with an on/off switch and a "more" menu. */
fun MainActivity.rulesScreen(): View {
    val a = this
    val p = page(a)
    val rules = RuleStore.load(a)
    val sub = if (rules.isEmpty()) "No rules yet" else "${rules.count { it.enabled }} active, ${rules.size} total"
    p.put(screenHeader(a, "Rules", sub, addButton(a) { a.openWizard(0) }))

    if (rules.isEmpty()) {
        p.put(
            emptyState(a, "No rules yet", "A rule says: when an SMS like this arrives, do this.", "Create a rule") { a.openWizard(0) },
            top = 12
        )
    } else {
        for (r in rules) p.put(ruleCard(a, r), top = 12)
        p.put(button(a, "New rule", Btn.PRIMARY) { a.openWizard(0) }, top = 18)
    }
    return scrolled(a, p)
}

/** Icon and colour that best describe what a rule does. */
fun ruleIcon(r: Rule): Pair<Int, Int> = when {
    r.alarm -> R.drawable.ic_bell to BAD
    r.remind -> R.drawable.ic_clock to PURPLE
    r.forward -> R.drawable.ic_send to ACCENT
    else -> R.drawable.ic_sms to TEAL
}

private fun ruleCard(a: MainActivity, r: Rule): LinearLayout {
    val c = card(a)
    c.setOnClickListener { a.openWizard(r.id) }
    val (icon, color) = ruleIcon(r)

    val top = row(a)
    top.addView(iconTile(a, icon, if (r.enabled) color else MUTED))
    val titles = column(a)
    titles.addView(text(a, r.name, 16f, if (r.enabled) INK else MUTED, true))
    if (r.description.isNotBlank()) titles.addView(text(a, r.description, 13f, MUTED))
    top.putH(titles, 1f, 12)
    top.putH(switchView(a, r.enabled) { on -> toggleRule(a, r.id, on) }, 0f, 8)
    val more = iconButton(a, R.drawable.ic_more, MUTED) { }
    more.setOnClickListener { showMenu(a, more, r) }
    top.addView(more)
    c.addView(top)

    c.put(text(a, r.describe(), 13f, MUTED), top = 10)
    val chips = r.chips()
    if (chips.isNotEmpty()) c.put(chipRow(a, chips), top = 10)

    val last = RuleStore.lastTriggered(a, r.id)
    val n = RuleStore.triggerCount(a, r.id)
    val footer = if (last == 0L) "Never triggered" else "Last triggered ${whenLabel(last)}  -  $n total"
    c.put(text(a, footer, 12f, MUTED), top = 10)
    return c
}

private fun toggleRule(a: MainActivity, id: Int, on: Boolean) {
    val r = RuleStore.get(a, id) ?: return
    r.enabled = on
    RuleStore.upsert(a, r)
    if (!on) Alerts.stopReminder(a, id, "rule turned off")
    a.refresh()
}

private fun showMenu(a: MainActivity, anchor: View, r: Rule) {
    val m = PopupMenu(a, anchor)
    m.menu.add(0, 1, 0, "Edit")
    m.menu.add(0, 2, 1, "Send test alert")
    m.menu.add(0, 3, 2, "Duplicate")
    m.menu.add(0, 4, 3, "Delete")
    m.setOnMenuItemClickListener { item ->
        when (item.itemId) {
            1 -> a.openWizard(r.id)
            2 -> sendTest(a, r)
            3 -> {
                RuleStore.upsert(a, r.copy(id = 0, name = r.name + " copy", enabled = false))
                toast(a, "Duplicated. The copy is switched off.")
                a.refresh()
            }
            4 -> confirm(a, "Delete rule?", "\"${r.name}\" will be removed.", "Delete") {
                Alerts.stopReminder(a, r.id, "rule deleted")
                RuleStore.delete(a, r.id)
                a.refresh()
            }
        }
        true
    }
    m.show()
}

/** Shared by the Rules menu, the wizard and Settings. */
fun sendTest(a: android.content.Context, r: Rule) {
    if (!Perms.notifications(a)) {
        toast(a, "Notifications are off. Allow them in Settings first.")
        return
    }
    Alerts.test(a, r)
    toast(a, "Test alert sent")
}
