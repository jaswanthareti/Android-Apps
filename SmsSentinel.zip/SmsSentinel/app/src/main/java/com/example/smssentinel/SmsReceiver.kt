package com.example.smssentinel

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Telephony
import android.telephony.PhoneNumberUtils
import android.telephony.SmsManager

class SmsReceiver : BroadcastReceiver() {

    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        if (msgs.isNullOrEmpty()) return
        val sender = msgs[0].originatingAddress ?: return
        val body = msgs.joinToString("") { it.messageBody ?: "" }

        val rules = RuleStore.load(ctx).filter { it.enabled }

        // 1) Stop any running reminders whose "stop" condition matches this SMS.
        val stopped = HashSet<Int>()
        for (r in rules) {
            if (r.remind && Alerts.isReminding(ctx, r.id) && Matcher.stops(ctx, r, sender, body)) {
                Alerts.stopReminder(ctx, r.id, "stop message received")
                stopped.add(r.id)
            }
        }

        // 2) Run every rule that matches.
        for (r in rules) {
            if (r.id in stopped) continue
            if (!Matcher.triggers(ctx, r, sender, body)) continue
            val text = "$sender: " + body.trim().take(300)
            ActivityLog.add(ctx, "Matched '${r.name}' from $sender")
            if (r.notify || r.alarm || r.remind) Alerts.fire(ctx, r, text)
            if (r.remind) Alerts.startReminder(ctx, r, text)
            if (r.forward) forward(ctx, r, sender, body)
        }
    }

    private fun forward(ctx: Context, r: Rule, sender: String, body: String) {
        val to = r.forwardTo.trim()
        if (to.isEmpty()) {
            ActivityLog.add(ctx, "Forward skipped for '${r.name}': no number set")
            return
        }
        if (PhoneNumberUtils.compare(ctx, to, sender)) return  // avoid loops
        val prefix = r.prefix.trim()
        val text = if (prefix.isEmpty()) body.trim() else "$prefix ${body.trim()}"
        try {
            val sms = smsManager(ctx, RuleStore.prefs(ctx).getInt("subId", -1))
            sms.sendMultipartTextMessage(to, null, sms.divideMessage(text), null, null)
            ActivityLog.add(ctx, "Forwarded '${r.name}' to $to")
        } catch (e: Exception) {
            ActivityLog.add(ctx, "Forward FAILED: ${e.javaClass.simpleName} ${e.message ?: ""}")
        }
    }

    private fun smsManager(ctx: Context, subId: Int): SmsManager {
        val base: SmsManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            ctx.getSystemService(SmsManager::class.java)
        else
            @Suppress("DEPRECATION") SmsManager.getDefault()
        return if (subId >= 0) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) base.createForSubscriptionId(subId)
            else @Suppress("DEPRECATION") SmsManager.getSmsManagerForSubscriptionId(subId)
        } else base
    }
}
