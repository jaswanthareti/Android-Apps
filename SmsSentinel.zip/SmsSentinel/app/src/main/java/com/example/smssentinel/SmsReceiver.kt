package com.example.smssentinel

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Telephony
import android.telephony.PhoneNumberUtils
import android.telephony.SmsManager

/** The entry point: runs for every incoming SMS and applies the rules. */
class SmsReceiver : BroadcastReceiver() {

    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        if (msgs.isNullOrEmpty()) return
        val sender = msgs[0].originatingAddress ?: return
        val body = msgs.joinToString("") { it.messageBody ?: "" }

        val rules = RuleStore.load(ctx).filter { it.enabled }

        // 1) Stop running reminders whose "stop" condition matches this SMS.
        val stopped = HashSet<Int>()
        for (r in rules) {
            if (r.remind && Alerts.isReminding(ctx, r.id) && Matcher.stops(ctx, r, sender, body)) {
                Alerts.stopReminder(ctx, r.id, "stop message received")
                stopped.add(r.id)
            }
        }

        // 2) Run every rule that matches.
        for (r in rules) {
            if (r.id in stopped) continue
            if (Matcher.triggers(ctx, r, sender, body)) trigger(ctx, r, sender, body)
        }
    }

    private fun trigger(ctx: Context, r: Rule, sender: String, body: String) {
        if (!Matcher.inWindow(r)) {
            EventLog.add(ctx, EV_SYSTEM, r.name, "Matched, but outside the allowed time")
            return
        }
        if (!RuleStore.cooldownOk(ctx, r)) {
            EventLog.add(ctx, EV_SYSTEM, r.name, "Skipped (cooldown period)")
            return
        }
        val count = RuleStore.markTriggered(ctx, r)
        val text = "$sender: " + body.trim().take(300)

        if (r.remind) Alerts.startReminder(ctx, r)
        when {
            r.alarm -> {
                Alerts.post(ctx, r, text, KIND_ALARM)
                EventLog.add(ctx, EV_ALARM, r.name, text)
            }
            r.notify || r.remind -> {
                Alerts.post(ctx, r, text, KIND_ALERT)
                if (r.remind) EventLog.add(ctx, EV_REMINDER, r.name, "Reminders started: $text")
                else EventLog.add(ctx, EV_MATCHED, r.name, text)
            }
        }
        if (r.forward) forward(ctx, r, sender, body)

        if (r.maxTriggers > 0 && count >= r.maxTriggers) {
            r.enabled = false
            RuleStore.upsert(ctx, r)
            Alerts.stopReminder(ctx, r.id, "rule reached its limit")
            EventLog.add(ctx, EV_SYSTEM, r.name, "Turned off after $count triggers")
        }
    }

    private fun forward(ctx: Context, r: Rule, sender: String, body: String) {
        val to = r.forwardTo.trim()
        if (to.isEmpty()) {
            EventLog.add(ctx, EV_SYSTEM, r.name, "Not forwarded: no number set")
            return
        }
        if (PhoneNumberUtils.compare(ctx, to, sender)) return  // never forward back to the sender
        val prefix = r.prefix.trim()
        val text = if (prefix.isEmpty()) body.trim() else "$prefix ${body.trim()}"
        try {
            val sms = defaultSmsManager(ctx)
            sms.sendMultipartTextMessage(to, null, sms.divideMessage(text), null, null)
            EventLog.add(ctx, EV_FORWARDED, "SMS forwarded", "${r.name}: from $sender to $to")
            Alerts.notifyForwarded(ctx, r, to)
        } catch (e: Exception) {
            EventLog.add(ctx, EV_SYSTEM, "Forward failed", "${r.name}: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    @Suppress("DEPRECATION")
    private fun defaultSmsManager(ctx: Context): SmsManager =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) ctx.service<SmsManager>()
        else SmsManager.getDefault()
}
