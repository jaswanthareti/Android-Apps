package com.example.smssentinel.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.sin

private val PenguinBody = Color(0xFF20242B)
private val PenguinBelly = Color(0xFFFFFFFF)
private val PenguinBeak = Color(0xFFF4A033)

/** Draws one simple, friendly penguin centered at [center]. [waddle] in -1f..1f tilts it. */
private fun DrawScope.drawPenguin(center: Offset, scale: Float, waddle: Float) {
    val bodyRx = 26f * scale
    val bodyRy = 32f * scale

    // feet (drawn first, behind the body)
    val footSpread = 16f * scale
    val footLift = (6f * scale) * waddle.coerceIn(-1f, 1f)
    drawOval(
        color = PenguinBeak,
        topLeft = Offset(center.x - footSpread - 7f * scale, center.y + bodyRy - 6f * scale - footLift.coerceAtLeast(0f)),
        size = androidx.compose.ui.geometry.Size(14f * scale, 7f * scale)
    )
    drawOval(
        color = PenguinBeak,
        topLeft = Offset(center.x + footSpread - 7f * scale, center.y + bodyRy - 6f * scale + footLift.coerceAtMost(0f)),
        size = androidx.compose.ui.geometry.Size(14f * scale, 7f * scale)
    )

    // body
    drawOval(
        color = PenguinBody,
        topLeft = Offset(center.x - bodyRx, center.y - bodyRy),
        size = androidx.compose.ui.geometry.Size(bodyRx * 2f, bodyRy * 2f)
    )

    // belly
    val bellyRx = 15f * scale
    val bellyRy = 20f * scale
    drawOval(
        color = PenguinBelly,
        topLeft = Offset(center.x - bellyRx, center.y - bellyRy * 0.3f),
        size = androidx.compose.ui.geometry.Size(bellyRx * 2f, bellyRy * 2f)
    )

    // eyes
    val eyeY = center.y - bodyRy * 0.45f
    val eyeDx = 8.5f * scale
    val eyeR = 3.6f * scale
    drawCircle(color = PenguinBelly, radius = eyeR, center = Offset(center.x - eyeDx, eyeY))
    drawCircle(color = PenguinBelly, radius = eyeR, center = Offset(center.x + eyeDx, eyeY))
    val pupilR = 1.6f * scale
    drawCircle(color = PenguinBody, radius = pupilR, center = Offset(center.x - eyeDx + 0.6f * scale, eyeY + 0.6f * scale))
    drawCircle(color = PenguinBody, radius = pupilR, center = Offset(center.x + eyeDx + 0.6f * scale, eyeY + 0.6f * scale))

    // beak
    val beakY = center.y - bodyRy * 0.1f
    val beakHalf = 4.6f * scale
    val beakPath = androidx.compose.ui.graphics.Path().apply {
        moveTo(center.x, beakY)
        lineTo(center.x + beakHalf, beakY + 6f * scale)
        lineTo(center.x - beakHalf, beakY + 6f * scale)
        close()
    }
    drawPath(path = beakPath, color = PenguinBeak)
}

/**
 * A small baby penguin that waddles back and forth. Used for brief loading moments
 * (app open, saving a rule) instead of a plain spinner.
 */
@Composable
fun PenguinLoader(modifier: Modifier = Modifier, label: String = "Loading…") {
    val infinite = rememberInfiniteTransition(label = "babyPenguinWalk")
    val walk by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1100, easing = LinearEasing), RepeatMode.Reverse),
        label = "walk"
    )
    val step by infinite.animateFloat(
        initialValue = -1f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(260, easing = LinearEasing), RepeatMode.Reverse),
        label = "step"
    )
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(modifier = Modifier.size(width = 130.dp, height = 78.dp)) {
            val w = size.width
            val x = w * (0.22f + 0.56f * walk)
            val bob = kotlin.math.abs(sin(walk * PI.toFloat() * 6f)) * 3.5f
            drawPenguin(center = Offset(x, size.height - 24f - bob), scale = 0.62f, waddle = step)
        }
        Spacer(Modifier.height(10.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium, color = SentinelInkSoft)
    }
}

/**
 * A larger, mostly-still adult penguin used as a quiet decorative accent
 * (empty states, section headers) — gentle idle bob only, no walking.
 */
@Composable
fun PenguinDecor(modifier: Modifier = Modifier, size: androidx.compose.ui.unit.Dp = 96.dp) {
    val infinite = rememberInfiniteTransition(label = "adultPenguinIdle")
    val idle by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2200, easing = LinearEasing), RepeatMode.Reverse),
        label = "idle"
    )
    Canvas(modifier = modifier.size(size)) {
        val bob = sin(idle * PI.toFloat()) * 3f
        drawPenguin(
            center = Offset(this.size.width / 2f, this.size.height / 2f + bob),
            scale = this.size.minDimension / 110f,
            waddle = 0f
        )
    }
}
