package com.example.smssentinel

import android.Manifest
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.telephony.SubscriptionManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.example.smssentinel.ui.PenguinDecor
import com.example.smssentinel.ui.PenguinLoader
import com.example.smssentinel.ui.SectionHeading
import com.example.smssentinel.ui.SentinelBackground
import com.example.smssentinel.ui.SentinelCard
import com.example.smssentinel.ui.SentinelTheme
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {

    companion object {
        private val SMS_PERMS = arrayOf(
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_PHONE_STATE
        )
        private val PERMS: Array<String> =
            if (Build.VERSION.SDK_INT >= 33) SMS_PERMS + Manifest.permission.POST_NOTIFICATIONS
            else SMS_PERMS
    }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh() }

    // ---- hoisted UI state, refreshed from the same RuleStore/Alerts used by the receivers ----
    private var hasSmsPerms by mutableStateOf(false)
    private var notificationsAllowed by mutableStateOf(false)
    private var activeReminders by mutableStateOf(0)
    private var rules by mutableStateOf(listOf<Rule>())
    private var logText by mutableStateOf("")
    private var simLabels by mutableStateOf(listOf("Default SIM"))
    private var simIds by mutableStateOf(listOf(-1))
    private var selectedSimIndex by mutableStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SentinelTheme {
                var loading by remember { mutableStateOf(true) }
                LaunchedEffect(Unit) {
                    delay(550)
                    loading = false
                }
                SentinelBackground {
                    if (loading) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            PenguinLoader(label = "Waking up Sentinel…")
                        }
                    } else {
                        MainScreen(
                            hasSmsPerms = hasSmsPerms,
                            notificationsAllowed = notificationsAllowed,
                            activeReminders = activeReminders,
                            rules = rules,
                            logText = logText,
                            simLabels = simLabels,
                            selectedSimIndex = selectedSimIndex,
                            onGrantPermissions = { permissionLauncher.launch(PERMS) },
                            onBatterySettings = {
                                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                            },
                            onAppSettings = {
                                startActivity(
                                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                                        .setData(Uri.parse("package:$packageName"))
                                )
                            },
                            onSimSelected = { index ->
                                selectedSimIndex = index
                                if (hasSmsPerms && index in simIds.indices) {
                                    RuleStore.prefs(this@MainActivity).edit()
                                        .putInt("subId", simIds[index]).apply()
                                }
                            },
                            onToggleRule = { rule, checked ->
                                rule.enabled = checked
                                RuleStore.upsert(this@MainActivity, rule)
                                if (!checked) Alerts.stopReminder(this@MainActivity, rule.id, "rule disabled")
                                refresh()
                            },
                            onEditRule = { rule ->
                                startActivity(Intent(this@MainActivity, RuleEditActivity::class.java).putExtra("id", rule.id))
                            },
                            onAddRule = {
                                startActivity(Intent(this@MainActivity, RuleEditActivity::class.java))
                            }
                        )
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun hasSmsPermsNow() =
        SMS_PERMS.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    private fun refresh() {
        hasSmsPerms = hasSmsPermsNow()
        val nm = getSystemService(NotificationManager::class.java)
        notificationsAllowed = nm.areNotificationsEnabled()
        rules = RuleStore.load(this)
        activeReminders = rules.count { it.enabled && Alerts.isReminding(this, it.id) }
        logText = ActivityLog.get(this).ifBlank { "(nothing yet)" }
        loadSims()
    }

    private fun loadSims() {
        val labels = arrayListOf("Default SIM")
        val ids = arrayListOf(-1)
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
            try {
                val sm = getSystemService(SubscriptionManager::class.java)
                sm.activeSubscriptionInfoList?.forEach {
                    labels.add("SIM ${it.simSlotIndex + 1} - ${it.carrierName}")
                    ids.add(it.subscriptionId)
                }
            } catch (_: Exception) { }
        }
        simLabels = labels
        simIds = ids
        val saved = RuleStore.prefs(this).getInt("subId", -1)
        selectedSimIndex = ids.indexOf(saved).coerceAtLeast(0)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MainScreen(
    hasSmsPerms: Boolean,
    notificationsAllowed: Boolean,
    activeReminders: Int,
    rules: List<Rule>,
    logText: String,
    simLabels: List<String>,
    selectedSimIndex: Int,
    onGrantPermissions: () -> Unit,
    onBatterySettings: () -> Unit,
    onAppSettings: () -> Unit,
    onSimSelected: (Int) -> Unit,
    onToggleRule: (Rule, Boolean) -> Unit,
    onEditRule: (Rule) -> Unit,
    onAddRule: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("SMS Sentinel", style = MaterialTheme.typography.headlineSmall)
                Text(
                    "Watches your messages and acts on your rules. Works fully offline.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            PenguinDecor(size = 56.dp)
        }

        Spacer(Modifier.height(16.dp))

        SentinelCard {
            StatusLine("SMS permissions", if (hasSmsPerms) "Granted" else "Missing", hasSmsPerms)
            StatusLine("Notifications", if (notificationsAllowed) "Allowed" else "Blocked", notificationsAllowed)
            StatusLine("Active reminders", activeReminders.toString(), true)
        }

        SectionHeading("Setup")
        SentinelCard {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = onGrantPermissions, modifier = Modifier.fillMaxWidth()) {
                    Text("Grant permissions")
                }
                OutlinedButton(onClick = onBatterySettings, modifier = Modifier.fillMaxWidth()) {
                    Text("Battery: set to unrestricted")
                }
                OutlinedButton(onClick = onAppSettings, modifier = Modifier.fillMaxWidth()) {
                    Text("App settings")
                }
                Text(
                    "SIM used when forwarding SMS",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                SimPicker(simLabels, selectedSimIndex, onSimSelected)
            }
        }

        SectionHeading("Rules")
        if (rules.isEmpty()) {
            SentinelCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    PenguinDecor(size = 64.dp)
                    Spacer(Modifier.width(12.dp))
                    Text("No rules yet. Add one below.", style = MaterialTheme.typography.bodyLarge)
                }
            }
        } else {
            rules.forEach { rule ->
                Spacer(Modifier.height(10.dp))
                RuleCard(rule, onToggle = { checked -> onToggleRule(rule, checked) }, onEdit = { onEditRule(rule) })
            }
        }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = onAddRule, modifier = Modifier.fillMaxWidth()) {
            Text("+ Add rule")
        }

        SectionHeading("Recent activity")
        SentinelCard {
            Text(logText, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        Spacer(Modifier.height(18.dp))
        Text(
            "Tip (Samsung): Settings > Battery > Background usage limits > Never sleeping apps > add SMS Sentinel.",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun StatusLine(label: String, value: String, ok: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyLarge)
        Text(
            value,
            style = MaterialTheme.typography.bodyLarge,
            color = if (ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SimPicker(labels: List<String>, selected: Int, onSelected: (Int) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text(labels.getOrElse(selected) { "Default SIM" })
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            labels.forEachIndexed { index, label ->
                DropdownMenuItem(text = { Text(label) }, onClick = {
                    expanded = false
                    onSelected(index)
                })
            }
        }
    }
}

@Composable
private fun RuleCard(rule: Rule, onToggle: (Boolean) -> Unit, onEdit: () -> Unit) {
    SentinelCard {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.weight(1f)) {
                Text(rule.name, style = MaterialTheme.typography.titleMedium)
            }
            Switch(checked = rule.enabled, onCheckedChange = onToggle)
        }
        Spacer(Modifier.height(4.dp))
        Text(
            rule.summary(),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(8.dp))
        TextButton(onClick = onEdit) { Text("Edit") }
    }
}
