package com.example.smssentinel

import android.Manifest
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.telephony.SubscriptionManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.smssentinel.ui.AuroraSwitch
import com.example.smssentinel.ui.Chip
import com.example.smssentinel.ui.ChipFlow
import com.example.smssentinel.ui.Divider
import com.example.smssentinel.ui.Glyph
import com.example.smssentinel.ui.GradientButton
import com.example.smssentinel.ui.IconBadge
import com.example.smssentinel.ui.Mascot
import com.example.smssentinel.ui.MascotLoader
import com.example.smssentinel.ui.MascotMood
import com.example.smssentinel.ui.SectionTitle
import com.example.smssentinel.ui.Sentinel
import com.example.smssentinel.ui.SentinelBackground
import com.example.smssentinel.ui.SentinelCard
import com.example.smssentinel.ui.SentinelIcon
import com.example.smssentinel.ui.SentinelOrb
import com.example.smssentinel.ui.SentinelTheme
import com.example.smssentinel.ui.StatTile
import com.example.smssentinel.ui.staggerIn
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {

    companion object {
        private val SMS_PERMS = arrayOf(
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_PHONE_STATE
        )
        private val PERMS: Array<String> =
            if (Build.VERSION.SDK_INT >= 33) SMS_PERMS + Manifest.permission.POST_NOTIFICATIONS
            else SMS_PERMS
    }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh() }

    // ---- hoisted UI state, refreshed from the same RuleStore/Alerts used by the receivers ----
    private var hasSmsPerms by mutableStateOf(false)
    private var notificationsAllowed by mutableStateOf(false)
    private var activeReminders by mutableStateOf(0)
    private var rules by mutableStateOf(listOf<Rule>())
    private var logText by mutableStateOf("")
    private var simLabels by mutableStateOf(listOf("Default SIM"))
    private var simIds by mutableStateOf(listOf(-1))
    private var selectedSimIndex by mutableStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            SentinelTheme {
                var loading by remember { mutableStateOf(true) }
                LaunchedEffect(Unit) {
                    delay(550)
                    loading = false
                }
                SentinelBackground {
                    if (loading) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            MascotLoader(label = "Waking up Sentinel…")
                        }
                    } else {
                        MainScreen(
                            hasSmsPerms = hasSmsPerms,
                            notificationsAllowed = notificationsAllowed,
                            activeReminders = activeReminders,
                            rules = rules,
                            logText = logText,
                            simLabels = simLabels,
                            selectedSimIndex = selectedSimIndex,
                            onGrantPermissions = { permissionLauncher.launch(PERMS) },
                            onBatterySettings = {
                                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                            },
                            onAppSettings = {
                                startActivity(
                                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                                        .setData(Uri.parse("package:$packageName"))
                                )
                            },
                            onSimSelected = { index ->
                                selectedSimIndex = index
                                if (hasSmsPerms && index in simIds.indices) {
                                    RuleStore.prefs(this@MainActivity).edit()
                                        .putInt("subId", simIds[index]).apply()
                                }
                            },
                            onToggleRule = { rule, checked ->
                                // Never mutate the Rule in place: the old list would then equal the
                                // reloaded one and Compose would skip the update (switch stays put).
                                val updated = rule.copy(enabled = checked)
                                rules = rules.map { if (it.id == updated.id) updated else it }
                                RuleStore.upsert(this@MainActivity, updated)
                                if (!checked) Alerts.stopReminder(this@MainActivity, updated.id, "rule disabled")
                                refresh()
                            },
                            onEditRule = { rule ->
                                startActivity(Intent(this@MainActivity, RuleEditActivity::class.java).putExtra("id", rule.id))
                            },
                            onAddRule = {
                                startActivity(Intent(this@MainActivity, RuleEditActivity::class.java))
                            }
                        )
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun hasSmsPermsNow() =
        SMS_PERMS.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    private fun refresh() {
        hasSmsPerms = hasSmsPermsNow()
        val nm = getSystemService(NotificationManager::class.java)
        notificationsAllowed = nm.areNotificationsEnabled()
        rules = RuleStore.load(this)
        activeReminders = rules.count { it.enabled && Alerts.isReminding(this, it.id) }
        logText = ActivityLog.get(this).ifBlank { "(nothing yet)" }
        loadSims()
    }

    private fun loadSims() {
        val labels = arrayListOf("Default SIM")
        val ids = arrayListOf(-1)
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
            try {
                val sm = getSystemService(SubscriptionManager::class.java)
                sm.activeSubscriptionInfoList?.forEach {
                    labels.add("SIM ${it.simSlotIndex + 1} - ${it.carrierName}")
                    ids.add(it.subscriptionId)
                }
            } catch (_: Exception) { }
        }
        simLabels = labels
        simIds = ids
        val saved = RuleStore.prefs(this).getInt("subId", -1)
        selectedSimIndex = ids.indexOf(saved).coerceAtLeast(0)
    }
}


// ════════════════════════════════ Screen ════════════════════════════════

@Composable
private fun MainScreen(
    hasSmsPerms: Boolean,
    notificationsAllowed: Boolean,
    activeReminders: Int,
    rules: List<Rule>,
    logText: String,
    simLabels: List<String>,
    selectedSimIndex: Int,
    onGrantPermissions: () -> Unit,
    onBatterySettings: () -> Unit,
    onAppSettings: () -> Unit,
    onSimSelected: (Int) -> Unit,
    onToggleRule: (Rule, Boolean) -> Unit,
    onEditRule: (Rule) -> Unit,
    onAddRule: () -> Unit
) {
    val p = Sentinel.colors
    val allGood = hasSmsPerms && notificationsAllowed
    val activeRules = rules.count { it.enabled }

    Box(Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .statusBarsPadding()
                .padding(horizontal = 20.dp)
                .padding(top = 8.dp, bottom = 120.dp)
        ) {
            // ── Top bar ──
            Row(Modifier.fillMaxWidth().staggerIn(0), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "Sentinel",
                        style = MaterialTheme.typography.headlineSmall.copy(
                            brush = Brush.horizontalGradient(p.aurora)
                        )
                    )
                    Text("SMS watchdog", style = MaterialTheme.typography.labelSmall, color = p.inkSoft)
                }
                Chip("100% offline", p.teal, glyph = Glyph.Shield)
            }

            // ── Hero ──
            Column(
                Modifier.fillMaxWidth().padding(top = 8.dp).staggerIn(1),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                SentinelOrb(
                    size = 230.dp,
                    mood = if (allGood) MascotMood.Calm else MascotMood.Alert
                )
                Text(
                    when {
                        !allGood -> "Needs attention"
                        activeRules == 0 -> "Ready when you are"
                        else -> "Standing guard"
                    },
                    style = MaterialTheme.typography.displaySmall.copy(
                        brush = Brush.horizontalGradient(
                            if (allGood) p.aurora else listOf(p.coral, p.amber)
                        )
                    )
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    when {
                        !hasSmsPerms -> "Grant SMS permission so rules can run."
                        !notificationsAllowed -> "Notifications are blocked, so alerts stay silent."
                        activeRules == 0 -> "Add your first rule to start watching."
                        activeReminders > 0 ->
                            "Watching with $activeRules active rule" + (if (activeRules == 1) "" else "s") +
                                ", $activeReminders reminder" + (if (activeReminders == 1) "" else "s") + " running."
                        else -> "Watching with $activeRules active rule" + (if (activeRules == 1) "." else "s.")
                    },
                    style = MaterialTheme.typography.bodyLarge,
                    color = p.inkSoft,
                    modifier = Modifier.padding(horizontal = 12.dp)
                )
            }

            Spacer(Modifier.height(20.dp))
            Row(Modifier.fillMaxWidth().staggerIn(2), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile(activeRules.toString(), "Active", p.teal, Modifier.weight(1f))
                StatTile((rules.size - activeRules).toString(), "Paused", p.inkSoft, Modifier.weight(1f))
                StatTile(activeReminders.toString(), "Reminders", p.violet, Modifier.weight(1f))
            }

            // ── Readiness ──
            SectionTitle("Readiness")
            SentinelCard(Modifier.staggerIn(3)) {
                ReadyRow(
                    Glyph.Shield, "SMS permissions",
                    if (hasSmsPerms) "Granted" else "Needed to read and forward SMS",
                    hasSmsPerms, if (hasSmsPerms) "Review" else "Grant", onGrantPermissions
                )
                Divider(Modifier.padding(vertical = 10.dp))
                ReadyRow(
                    Glyph.Bell, "Notifications",
                    if (notificationsAllowed) "Allowed" else "Blocked in system settings",
                    notificationsAllowed, "Open", onAppSettings
                )
                Divider(Modifier.padding(vertical = 10.dp))
                ReadyRow(
                    Glyph.Battery, "Battery",
                    "Set to Unrestricted so alerts never sleep",
                    true, "Open", onBatterySettings
                )
                Divider(Modifier.padding(vertical = 10.dp))
                SimRow(simLabels, selectedSimIndex, onSimSelected)
            }

            // ── Rules ──
            SectionTitle("Rules", trailing = rules.size.toString())
            if (rules.isEmpty()) {
                SentinelCard(Modifier.staggerIn(4)) {
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Mascot(size = 96.dp, mood = MascotMood.Sleep)
                        Spacer(Modifier.height(8.dp))
                        Text("No rules yet", style = MaterialTheme.typography.titleMedium, color = p.ink)
                        Text(
                            "Tap New rule and teach Sentinel what to watch for.",
                            style = MaterialTheme.typography.bodyMedium, color = p.inkSoft
                        )
                    }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    rules.forEachIndexed { i, rule ->
                        key(rule.id) {
                            RuleCard(
                                rule,
                                onToggle = { checked -> onToggleRule(rule, checked) },
                                onEdit = { onEditRule(rule) },
                                modifier = Modifier.staggerIn(4 + i)
                            )
                        }
                    }
                }
            }

            // ── Activity ──
            SectionTitle("Recent activity")
            SentinelCard { ActivityTimeline(logText) }

            Spacer(Modifier.height(20.dp))
            Text(
                "Samsung tip: Settings > Battery > Background usage limits > Never sleeping apps > add Sentinel.",
                style = MaterialTheme.typography.labelMedium,
                color = p.inkSoft,
                modifier = Modifier.padding(horizontal = 4.dp)
            )
        }

        // bottom fade + floating action
        Box(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(150.dp)
                .background(Brush.verticalGradient(listOf(Color.Transparent, p.bg.copy(alpha = 0.92f))))
        )
        GradientButton(
            text = "New rule",
            onClick = onAddRule,
            glyph = Glyph.Plus,
            modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 18.dp)
        )
    }
}

@Composable
private fun ReadyRow(glyph: Glyph, title: String, status: String, ok: Boolean, action: String, onClick: () -> Unit) {
    val p = Sentinel.colors
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconBadge(glyph, if (ok) p.teal else p.coral, size = 42.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = p.ink)
            Text(status, style = MaterialTheme.typography.bodyMedium, color = if (ok) p.inkSoft else p.coral)
        }
        Text(action, style = MaterialTheme.typography.labelLarge, color = if (ok) p.sky else p.coral)
        SentinelIcon(Glyph.Chevron, size = 18.dp, tint = p.inkSoft)
    }
}

@Composable
private fun SimRow(labels: List<String>, selected: Int, onSelected: (Int) -> Unit) {
    val p = Sentinel.colors
    var expanded by remember { mutableStateOf(false) }
    Box {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable { expanded = true },
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconBadge(Glyph.Sim, p.violet, size = 42.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Forwarding SIM", style = MaterialTheme.typography.titleMedium, color = p.ink)
                Text(
                    labels.getOrElse(selected) { "Default SIM" },
                    style = MaterialTheme.typography.bodyMedium, color = p.inkSoft,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            Text("Change", style = MaterialTheme.typography.labelLarge, color = p.sky)
            SentinelIcon(Glyph.Chevron, size = 18.dp, tint = p.inkSoft)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            labels.forEachIndexed { index, label ->
                DropdownMenuItem(text = { Text(label) }, onClick = {
                    expanded = false
                    onSelected(index)
                })
            }
        }
    }
}

@Composable
private fun RuleCard(rule: Rule, onToggle: (Boolean) -> Unit, onEdit: () -> Unit, modifier: Modifier = Modifier) {
    val p = Sentinel.colors
    val dim by animateFloatAsState(if (rule.enabled) 1f else 0.5f, label = "ruleDim")
    val (glyph, tint, second) = when {
        rule.alarm -> Triple(Glyph.Alarm, p.coral, p.amber)
        rule.forward -> Triple(Glyph.Send, p.violet, p.sky)
        rule.remind -> Triple(Glyph.Repeat, p.sky, p.teal)
        else -> Triple(Glyph.Bell, p.teal, p.sky)
    }
    val match = listOf(rule.sender, rule.content).filter { it.isNotBlank() }.joinToString("  ·  ").ifBlank { "Any SMS" }

    SentinelCard(modifier.animateContentSize(), onClick = onEdit) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBadge(glyph, tint, Modifier.alpha(dim), second = second)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f).alpha(dim)) {
                Text(rule.name, style = MaterialTheme.typography.titleMedium, color = p.ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(match, style = MaterialTheme.typography.bodyMedium, color = p.inkSoft, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.width(10.dp))
            AuroraSwitch(rule.enabled, onToggle)
        }
        Spacer(Modifier.height(12.dp))
        Column(Modifier.alpha(dim)) {
            ChipFlow {
                if (rule.notify) Chip("Notify", p.teal, glyph = Glyph.Bell)
                if (rule.alarm) Chip("Loud alarm", p.coral, glyph = Glyph.Alarm)
                if (rule.remind) Chip("Every ${rule.intervalMin} min", p.sky, glyph = Glyph.Repeat)
                if (rule.forward) Chip("To " + rule.forwardTo.ifBlank { "(no number)" }, p.violet, glyph = Glyph.Send)
                if (rule.quiet) Chip("Quiet 11 PM-7 AM", p.inkSoft)
                if (rule.regex) Chip("Regex", p.amber)
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            StatusPill(rule.enabled)
            Spacer(Modifier.weight(1f))
            Text("Edit", style = MaterialTheme.typography.labelLarge, color = p.sky)
            SentinelIcon(Glyph.Chevron, size = 16.dp, tint = p.sky)
        }
    }
}

@Composable
private fun StatusPill(active: Boolean) {
    val p = Sentinel.colors
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(if (active) p.teal else p.inkSoft))
        Spacer(Modifier.width(6.dp))
        Text(
            if (active) "Active" else "Paused",
            style = MaterialTheme.typography.labelMedium,
            color = if (active) p.teal else p.inkSoft
        )
    }
}

/** Log lines look like "dd MMM HH:mm  message" (12-char timestamp, then two spaces). */
@Composable
private fun ActivityTimeline(logText: String) {
    val p = Sentinel.colors
    val lines = logText.lines().filter { it.isNotBlank() && it != "(nothing yet)" }
    if (lines.isEmpty()) {
        Text(
            "Nothing yet. Activity shows up here the moment a rule fires.",
            style = MaterialTheme.typography.bodyMedium, color = p.inkSoft
        )
        return
    }
    Column {
        lines.forEachIndexed { i, line ->
            val time = if (line.length > 12) line.substring(0, 12) else ""
            val msg = if (line.length > 12) line.substring(12).trim() else line
            val last = i == lines.lastIndex
            val dotColor = p.sky
            val lineColor = p.glassBorder
            Column(
                Modifier.fillMaxWidth()
                    .drawBehind {
                        val x = 4.dp.toPx()
                        if (!last) drawLine(lineColor, Offset(x, 14.dp.toPx()), Offset(x, size.height), strokeWidth = 1.5.dp.toPx())
                        drawCircle(dotColor, 4.dp.toPx(), Offset(x, 7.dp.toPx()))
                    }
                    .padding(start = 22.dp, bottom = if (last) 0.dp else 14.dp)
            ) {
                Text(msg, style = MaterialTheme.typography.bodyMedium, color = p.ink)
                Text(time, style = MaterialTheme.typography.labelMedium, color = p.inkSoft)
            }
        }
    }
}
