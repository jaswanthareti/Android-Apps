package com.example.smssentinel

import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout

/** Home tab: protection status, rule summary, counters, running reminders and recent activity. */
fun MainActivity.homeScreen(): View {
    val a = this
    val p = page(a)
    val rules = RuleStore.load(a)
    val active = rules.count { it.enabled }
    val ready = Perms.coreReady(a)

    // ---- header: logo, name and status pill
    val head = row(a)
    head.addView(logoTile(a, 46))
    val titles = column(a)
    titles.addView(text(a, "Guardly", 24f, INK, true))
    titles.addView(text(a, "Smart SMS actions. Fully offline.", 13f, MUTED))
    head.putH(titles, 1f, 12)
    head.putH(statusPill(a, ready) { a.go(MainActivity.TAB_SETTINGS) })
    p.put(head)

    // ---- setup banner
    if (!ready) {
        val warn = card(a, tint(WARN, 0.10f), WARN)
        warn.addView(text(a, "Finish setup", 16f, WARN, true))
        warn.put(
            text(a, "Guardly needs permission to read and send SMS and to show notifications before rules can run.", 14f, INK),
            top = 4
        )
        warn.put(button(a, "Allow permissions", Btn.PRIMARY) { a.requestCore() }, top = 12)
        p.put(warn, top = 16)
    }

    // ---- hero
    val hero = row(a)
    hero.background = gradient(a, Color.parseColor("#0C4A6E"), Color.parseColor("#4C1D95"), 22)
    hero.setPadding(a.dp(18), a.dp(18), a.dp(14), a.dp(18))
    val left = column(a)
    left.addView(text(a, if (ready) "You're protected" else "Almost ready", 21f, Color.WHITE, true))
    val summary = when {
        rules.isEmpty() -> "No rules yet. Create your first one."
        active == 0 -> "All ${rules.size} rules are paused."
        else -> "$active of ${rules.size} rules are watching your SMS."
    }
    left.put(text(a, summary, 14f, Color.parseColor("#CBD5E1")), top = 4, bottom = 14)
    left.addView(button(a, "New rule", Btn.SECONDARY) { a.openWizard(0) })
    hero.putH(left, 1f)
    hero.addView(roundedImage(a, R.drawable.art_hero, 16), LinearLayout.LayoutParams(a.dp(112), a.dp(112)))
    p.put(hero, top = 18)

    // ---- counters
    val stats = row(a)
    stats.putH(statCard(a, R.drawable.ic_send, ACCENT, EventLog.count(a, "n_forwarded"), "Forwarded"), 1f)
    stats.putH(statCard(a, R.drawable.ic_bell, BAD, EventLog.count(a, "n_alarms"), "Alarms"), 1f, 10)
    stats.putH(statCard(a, R.drawable.ic_clock, PURPLE, EventLog.count(a, "n_reminders"), "Reminders"), 1f, 10)
    p.put(stats, top = 14)

    // ---- reminders that are repeating right now
    val running = rules.filter { it.remind && Alerts.isReminding(a, it.id) }
    if (running.isNotEmpty()) {
        p.put(sectionHeader(a, "Reminders running"))
        for (r in running) {
            val c = card(a)
            val line = row(a)
            line.addView(iconTile(a, R.drawable.ic_clock, PURPLE, 40, 20))
            val col = column(a)
            col.addView(text(a, r.name, 15f, INK, true))
            col.addView(text(a, "Repeats every ${fmtInterval(r.intervalMin)} until stopped", 13f, MUTED))
            line.putH(col, 1f, 12)
            line.putH(pill(a, "Mark done", OK) {
                Alerts.stopReminder(a, r.id, "marked as done")
                a.refresh()
            }, 0f, 8)
            c.addView(line)
            p.put(c, bottom = 8)
        }
    }

    // ---- recent activity
    p.put(sectionHeader(a, "Recent activity", "See all") { a.go(MainActivity.TAB_ACTIVITY) })
    val events = EventLog.all(a).take(4)
    val recent = card(a)
    if (events.isEmpty()) {
        recent.addView(text(a, "Nothing yet. Activity appears here when a rule forwards, alerts or reminds.", 14f, MUTED))
    } else {
        events.forEachIndexed { i, e ->
            if (i > 0) recent.addView(divider(a))
            recent.addView(eventRow(a, e, true))
        }
    }
    p.put(recent)

    // ---- tip
    val tip = card(a)
    val tipRow = row(a)
    tipRow.addView(iconTile(a, R.drawable.ic_bulb, WARN, 40, 20))
    val tipText = column(a)
    tipText.addView(text(a, "Tip", 15f, INK, true))
    tipText.addView(text(a, "Open a rule and use Send test alert to preview how it looks and sounds, without waiting for a real SMS.", 13f, MUTED))
    tipRow.putH(tipText, 1f, 12)
    tip.addView(tipRow)
    p.put(tip, top = 18)

    return scrolled(a, p)
}

private fun statCard(ctx: Context, icon: Int, color: Int, value: Int, label: String): LinearLayout {
    val c = card(ctx)
    c.setPadding(ctx.dp(14), ctx.dp(12), ctx.dp(14), ctx.dp(12))
    c.addView(iconView(ctx, icon, 20, color))
    c.put(text(ctx, value.toString(), 24f, INK, true), top = 6)
    c.addView(text(ctx, label, 12f, MUTED))
    return c
}

private fun statusPill(ctx: Context, ready: Boolean, onClick: () -> Unit): LinearLayout {
    val color = if (ready) OK else WARN
    val pillView = row(ctx)
    pillView.background = rounded(ctx, tint(color, 0.16f), 16)
    pillView.setPadding(ctx.dp(12), ctx.dp(7), ctx.dp(12), ctx.dp(7))
    pillView.addView(dot(ctx, color))
    pillView.addView(text(ctx, if (ready) "Protected" else "Setup needed", 12f, color, true))
    pillView.setOnClickListener { onClick() }
    return pillView
}

/** Icon and colour for each kind of activity event. */
fun eventStyle(type: String): Pair<Int, Int> = when (type) {
    EV_FORWARDED -> R.drawable.ic_send to ACCENT
    EV_ALARM -> R.drawable.ic_bell to BAD
    EV_REMINDER -> R.drawable.ic_clock to PURPLE
    EV_MATCHED -> R.drawable.ic_sms to TEAL
    else -> R.drawable.ic_info to MUTED
}

/** One line of the activity list: icon, title, detail and time. */
fun eventRow(ctx: Context, e: Event, relativeTime: Boolean = false): LinearLayout {
    val (icon, color) = eventStyle(e.type)
    val r = row(ctx)
    r.setPadding(0, ctx.dp(10), 0, ctx.dp(10))
    r.gravity = Gravity.CENTER_VERTICAL
    r.addView(iconTile(ctx, icon, color, 40, 20))
    val col = column(ctx)
    col.addView(text(ctx, e.title, 15f, INK, true))
    if (e.detail.isNotBlank()) {
        val d = text(ctx, e.detail, 13f, MUTED)
        d.maxLines = 2
        d.ellipsize = android.text.TextUtils.TruncateAt.END
        col.addView(d)
    }
    r.putH(col, 1f, 12)
    r.putH(text(ctx, if (relativeTime) relative(e.time) else clock(e.time), 12f, MUTED), 0f, 8)
    return r
}
