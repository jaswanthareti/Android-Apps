package com.example.smssentinel

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.window.OnBackInvokedDispatcher

/**
 * Full-screen alarm shown over the lock screen. The sound comes from the alarm notification
 * (insistent, alarm volume); this screen lets you snooze or dismiss it.
 */
class AlarmActivity : Activity() {
    private var ruleId = 0
    private var alarmText = ""
    private var snoozeMin = 10

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        wakeScreen()
        readIntent(intent)
        build()
        if (Build.VERSION.SDK_INT >= 33) {
            onBackInvokedDispatcher.registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT) { dismissAlarm() }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readIntent(intent)
        build()
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        dismissAlarm()
    }

    @Suppress("DEPRECATION")
    private fun wakeScreen() {
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun readIntent(i: Intent) {
        ruleId = i.getIntExtra(Alerts.EXTRA_RULE, 0)
        alarmText = i.getStringExtra(Alerts.EXTRA_TEXT) ?: Alerts.savedText(this, ruleId)
    }

    private fun build() {
        val rule = RuleStore.get(this, ruleId)
        val name = rule?.name ?: "Alarm"

        val p = column(this)
        p.gravity = Gravity.CENTER_HORIZONTAL
        p.setPadding(dp(24), dp(24), dp(24), dp(24))

        p.addView(roundedImage(this, R.drawable.art_alarm, 28), LinearLayout.LayoutParams(dp(170), dp(170)))
        p.addView(
            chip(this, "ALARM", BAD),
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dp(18) }
        )
        p.put(text(this, clock(System.currentTimeMillis()), 44f, INK, true).apply { gravity = Gravity.CENTER }, top = 6)
        p.put(text(this, name, 22f, INK, true).apply { gravity = Gravity.CENTER }, top = 2)

        if (alarmText.isNotBlank()) {
            val c = card(this)
            c.addView(text(this, alarmText, 15f, INK))
            p.put(c, top = 18)
        }

        p.put(text(this, "Snooze for", 13f, MUTED, true), top = 22, bottom = 8)
        val options = listOf(5, 10, 15, 30)
        p.put(choiceRow(this, options.map { "$it min" }, options.indexOf(snoozeMin).coerceAtLeast(0)) { snoozeMin = options[it] })

        p.put(button(this, "Snooze", Btn.PRIMARY) { snooze(rule) }, top = 20)
        p.put(button(this, "Dismiss", Btn.GHOST) { dismissAlarm() }, top = 10)
        if (rule != null && Alerts.isReminding(this, rule.id)) {
            p.put(button(this, "Mark as done (stop reminders)", Btn.SECONDARY) {
                Alerts.stopReminder(this, ruleId, "marked as done")
                close()
            }, top = 10)
        }

        val root = ScrollView(this)
        root.setBackgroundColor(BG)
        root.isFillViewport = true
        root.addView(p)
        setContentView(root)
        applyInsets(root)
    }

    private fun snooze(rule: Rule?) {
        if (rule != null) {
            Alerts.snoozeAlarm(this, rule, snoozeMin)
            toast(this, "Snoozed for $snoozeMin min")
        } else {
            Alerts.dismiss(this, ruleId)
        }
        close()
    }

    private fun dismissAlarm() {
        Alerts.dismiss(this, ruleId)
        close()
    }

    private fun close() {
        finishAndRemoveTask()
    }
}
