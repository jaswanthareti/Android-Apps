package com.example.smssentinel.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// A calm, icy palette: whites and cold blues, one warm accent for alarms.
val IceBackground = Color(0xFFF2F8FC)
val IceSurface = Color(0xFFFFFFFF)
val IceSurfaceAlt = Color(0xFFE7F1F8)
val IceOutline = Color(0xFFD6E5EF)
val SentinelBlue = Color(0xFF0A84FF)
val SentinelBlueDark = Color(0xFF0760C4)
val SentinelInk = Color(0xFF1C1C1E)
val SentinelInkSoft = Color(0xFF6E7781)
val SentinelWarn = Color(0xFFFF3B30)
val SentinelSnow = Color(0xFFFFFFFF)

private val SentinelLightColors = lightColorScheme(
    primary = SentinelBlue,
    onPrimary = Color.White,
    primaryContainer = IceSurfaceAlt,
    onPrimaryContainer = SentinelBlueDark,
    secondary = SentinelWarn,
    onSecondary = Color.White,
    background = IceBackground,
    onBackground = SentinelInk,
    surface = IceSurface,
    onSurface = SentinelInk,
    surfaceVariant = IceSurfaceAlt,
    onSurfaceVariant = SentinelInkSoft,
    outline = IceOutline,
    error = SentinelWarn,
    onError = Color.White
)

private val SentinelDarkColors = darkColorScheme(
    primary = SentinelBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF13293D),
    onPrimaryContainer = Color(0xFFBFE0FF),
    secondary = SentinelWarn,
    onSecondary = Color.White,
    background = Color(0xFF0E1620),
    onBackground = Color(0xFFEAF2F8),
    surface = Color(0xFF162231),
    onSurface = Color(0xFFEAF2F8),
    surfaceVariant = Color(0xFF1E2C3D),
    onSurfaceVariant = Color(0xFFA9BACB),
    outline = Color(0xFF2B3C4F),
    error = SentinelWarn,
    onError = Color.White
)

private val SentinelTypography = Typography(
    headlineSmall = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 24.sp, lineHeight = 30.sp),
    titleLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 19.sp, lineHeight = 24.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 16.sp, lineHeight = 22.sp),
    bodyLarge = TextStyle(fontWeight = FontWeight.Normal, fontSize = 15.sp, lineHeight = 21.sp),
    bodyMedium = TextStyle(fontWeight = FontWeight.Normal, fontSize = 13.sp, lineHeight = 18.sp),
    labelLarge = TextStyle(fontWeight = FontWeight.Medium, fontSize = 14.sp, lineHeight = 18.sp),
    labelMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 16.sp)
)

@Composable
fun SentinelTheme(content: @Composable () -> Unit) {
    val colors = if (isSystemInDarkTheme()) SentinelDarkColors else SentinelLightColors
    MaterialTheme(colorScheme = colors, typography = SentinelTypography, content = content)
}
