package com.example.smssentinel.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * "Frost Aurora": deep midnight (or frosted daylight) surfaces lit by a teal -> sky -> violet
 * aurora. Coral is reserved for alarms/attention, amber for warmth (beak, loud alarm).
 */
@Immutable
class SentinelPalette(
    val isDark: Boolean,
    val bg: Color,
    val surface: Color,
    val glass: Color,
    val glassBorder: Color,
    val ink: Color,
    val inkSoft: Color,
    val teal: Color,
    val sky: Color,
    val violet: Color,
    val coral: Color,
    val amber: Color
) {
    val aurora: List<Color> get() = listOf(teal, sky, violet)
    val onAccent: Color get() = if (isDark) Color(0xFF04101F) else Color.White
}

private val DarkPalette = SentinelPalette(
    isDark = true,
    bg = Color(0xFF060A13),
    surface = Color(0xFF0F1727),
    glass = Color.White.copy(alpha = 0.065f),
    glassBorder = Color.White.copy(alpha = 0.10f),
    ink = Color(0xFFF1F6FF),
    inkSoft = Color(0xFF93A4BD),
    teal = Color(0xFF3EE6C3),
    sky = Color(0xFF58A8FF),
    violet = Color(0xFF9A87FF),
    coral = Color(0xFFFF6B7A),
    amber = Color(0xFFFFB347)
)

private val LightPalette = SentinelPalette(
    isDark = false,
    bg = Color(0xFFF2F6FC),
    surface = Color(0xFFFFFFFF),
    glass = Color.White.copy(alpha = 0.80f),
    glassBorder = Color(0xFF0B1B3A).copy(alpha = 0.08f),
    ink = Color(0xFF0A1226),
    inkSoft = Color(0xFF5B6B85),
    teal = Color(0xFF0FB89E),
    sky = Color(0xFF2F7DFF),
    violet = Color(0xFF6D58F5),
    coral = Color(0xFFE5384F),
    amber = Color(0xFFE08A00)
)

val LocalSentinel = staticCompositionLocalOf { DarkPalette }

object Sentinel {
    val colors: SentinelPalette
        @Composable get() = LocalSentinel.current
}

private val SentinelTypography = Typography(
    displaySmall = TextStyle(fontWeight = FontWeight.Bold, fontSize = 30.sp, lineHeight = 36.sp, letterSpacing = (-0.5).sp),
    headlineSmall = TextStyle(fontWeight = FontWeight.Bold, fontSize = 24.sp, lineHeight = 30.sp, letterSpacing = (-0.3).sp),
    titleLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 20.sp, lineHeight = 26.sp, letterSpacing = (-0.2).sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 22.sp),
    bodyLarge = TextStyle(fontWeight = FontWeight.Normal, fontSize = 15.sp, lineHeight = 22.sp),
    bodyMedium = TextStyle(fontWeight = FontWeight.Normal, fontSize = 13.5.sp, lineHeight = 19.sp),
    labelLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 18.sp),
    labelMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 16.sp, letterSpacing = 0.2.sp),
    labelSmall = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 11.sp, lineHeight = 14.sp, letterSpacing = 0.8.sp)
)

@Composable
fun SentinelTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val p = if (dark) DarkPalette else LightPalette
    val scheme = if (dark) {
        darkColorScheme(
            primary = p.sky, onPrimary = p.onAccent,
            secondary = p.teal, tertiary = p.violet,
            background = p.bg, onBackground = p.ink,
            surface = p.surface, onSurface = p.ink,
            surfaceVariant = p.surface, onSurfaceVariant = p.inkSoft,
            primaryContainer = p.sky.copy(alpha = 0.18f), onPrimaryContainer = p.sky,
            outline = p.glassBorder, error = p.coral, onError = Color.White
        )
    } else {
        lightColorScheme(
            primary = p.sky, onPrimary = p.onAccent,
            secondary = p.teal, tertiary = p.violet,
            background = p.bg, onBackground = p.ink,
            surface = p.surface, onSurface = p.ink,
            surfaceVariant = p.surface, onSurfaceVariant = p.inkSoft,
            primaryContainer = p.sky.copy(alpha = 0.14f), onPrimaryContainer = p.sky,
            outline = p.glassBorder, error = p.coral, onError = Color.White
        )
    }
    CompositionLocalProvider(LocalSentinel provides p) {
        MaterialTheme(colorScheme = scheme, typography = SentinelTypography, content = content)
    }
}
