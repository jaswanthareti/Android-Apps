package com.example.smssentinel

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object RuleStore {
    const val PREFS = "cfg"

    fun prefs(ctx: Context): SharedPreferences = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(ctx: Context): MutableList<Rule> {
        val p = prefs(ctx)
        val s = p.getString("rules", null)
        if (s == null) {
            val seeded = seed(ctx)
            saveAll(ctx, seeded)
            return seeded
        }
        val out = mutableListOf<Rule>()
        try {
            val arr = JSONArray(s)
            for (i in 0 until arr.length()) out.add(Rule.fromJson(arr.getJSONObject(i)))
        } catch (e: Exception) { }
        return out
    }

    fun saveAll(ctx: Context, rules: List<Rule>) {
        val arr = JSONArray()
        rules.forEach { arr.put(it.toJson()) }
        prefs(ctx).edit().putString("rules", arr.toString()).apply()
    }

    private fun nextId(ctx: Context): Int {
        val p = prefs(ctx)
        val n = p.getInt("nextId", 1)
        p.edit().putInt("nextId", n + 1).apply()
        return n
    }

    fun upsert(ctx: Context, r: Rule) {
        val list = load(ctx)
        if (r.id == 0) {
            r.id = nextId(ctx)
            list.add(r)
        } else {
            val i = list.indexOfFirst { it.id == r.id }
            if (i >= 0) list[i] = r else list.add(r)
        }
        saveAll(ctx, list)
    }

    fun delete(ctx: Context, id: Int) {
        saveAll(ctx, load(ctx).filter { it.id != id })
    }

    /** Two editable examples shown on first launch. */
    private fun seed(ctx: Context): MutableList<Rule> = mutableListOf(
        Rule(
            id = nextId(ctx),
            name = "Low balance (example)",
            sender = "AD-LBA",
            content = "your balance is below the threshold value of rs\\.?\\s*[0-9.,]+",
            regex = true,
            notify = true, alarm = false, remind = true, intervalMin = 60, quiet = true,
            stopSender = "AIRTEL-S", stopContent = "Digital Purchases: Tns"
        ),
        Rule(
            id = nextId(ctx),
            name = "Forward OTP (example)",
            enabled = false,
            sender = "AD-AIRTEL-S",
            notify = false, forward = true, forwardTo = "", prefix = "AIRTEL OTP"
        )
    )
}

object ActivityLog {
    fun add(ctx: Context, msg: String) {
        val p = RuleStore.prefs(ctx)
        val time = SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()).format(Date())
        val old = (p.getString("log", "") ?: "").lines().filter { it.isNotBlank() }
        val all = (listOf("$time  $msg") + old).take(30)
        p.edit().putString("log", all.joinToString("\n")).apply()
    }

    fun get(ctx: Context): String = RuleStore.prefs(ctx).getString("log", "") ?: ""
}
