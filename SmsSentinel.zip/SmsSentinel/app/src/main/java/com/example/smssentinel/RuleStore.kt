package com.example.smssentinel

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

object RuleStore {
    const val PREFS = "cfg"

    fun prefs(ctx: Context): SharedPreferences = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(ctx: Context): MutableList<Rule> {
        val s = prefs(ctx).getString("rules", null)
        if (s == null) {
            val seeded = seed(ctx)
            saveAll(ctx, seeded)
            return seeded
        }
        val out = mutableListOf<Rule>()
        try {
            val arr = JSONArray(s)
            for (i in 0 until arr.length()) out.add(Rule.fromJson(arr.getJSONObject(i)))
        } catch (e: Exception) {
            // unreadable rules: return what we have
        }
        return out
    }

    fun get(ctx: Context, id: Int): Rule? = load(ctx).firstOrNull { it.id == id }

    fun saveAll(ctx: Context, rules: List<Rule>) {
        val arr = JSONArray()
        rules.forEach { arr.put(it.toJson()) }
        prefs(ctx).edit().putString("rules", arr.toString()).apply()
    }

    private fun nextId(ctx: Context): Int {
        val p = prefs(ctx)
        val n = p.getInt("nextId", 1)
        p.edit().putInt("nextId", n + 1).apply()
        return n
    }

    /** Inserts a new rule (id == 0) or replaces the rule with the same id. Returns the saved rule. */
    fun upsert(ctx: Context, r: Rule): Rule {
        val list = load(ctx)
        if (r.id == 0) {
            r.id = nextId(ctx)
            list.add(r)
        } else {
            val i = list.indexOfFirst { it.id == r.id }
            if (i >= 0) list[i] = r else list.add(r)
        }
        saveAll(ctx, list)
        return r
    }

    fun delete(ctx: Context, id: Int) {
        saveAll(ctx, load(ctx).filter { it.id != id })
        prefs(ctx).edit().remove("last_$id").remove("count_$id").remove("rem_$id").remove("alerttext_$id").apply()
    }

    // ---- per-rule trigger bookkeeping ----

    fun lastTriggered(ctx: Context, id: Int): Long = prefs(ctx).getLong("last_$id", 0L)

    fun triggerCount(ctx: Context, id: Int): Int = prefs(ctx).getInt("count_$id", 0)

    fun cooldownOk(ctx: Context, r: Rule, now: Long = System.currentTimeMillis()): Boolean {
        if (r.cooldownMin <= 0) return true
        val last = lastTriggered(ctx, r.id)
        return last == 0L || now - last >= r.cooldownMin * 60_000L
    }

    /** Records a trigger and returns how many times the rule has triggered in total. */
    fun markTriggered(ctx: Context, r: Rule): Int {
        val p = prefs(ctx)
        val n = p.getInt("count_${r.id}", 0) + 1
        p.edit().putLong("last_${r.id}", System.currentTimeMillis()).putInt("count_${r.id}", n).apply()
        return n
    }

    // ---- settings ----

    fun confirmForward(ctx: Context): Boolean = prefs(ctx).getBoolean("confirmForward", true)

    fun setConfirmForward(ctx: Context, v: Boolean) {
        prefs(ctx).edit().putBoolean("confirmForward", v).apply()
    }

    // ---- backup / restore (rules survive reinstalling the app) ----

    fun exportJson(ctx: Context): String {
        val arr = JSONArray()
        load(ctx).forEach { arr.put(it.toJson()) }
        return JSONObject().put("app", "guardly").put("version", 1).put("rules", arr).toString()
    }

    /** Replaces all rules with the backup. Returns the number of rules restored. */
    fun importJson(ctx: Context, text: String): Int {
        val root = JSONObject(text.trim())
        val arr = root.getJSONArray("rules")
        val rules = mutableListOf<Rule>()
        for (i in 0 until arr.length()) {
            val r = Rule.fromJson(arr.getJSONObject(i))
            r.id = nextId(ctx)
            rules.add(r)
        }
        load(ctx).forEach { Alerts.stopReminder(ctx, it.id, "rules restored") }
        saveAll(ctx, rules)
        return rules.size
    }

    /** Two editable examples shown on first launch. */
    private fun seed(ctx: Context): MutableList<Rule> = mutableListOf(
        Rule(
            id = nextId(ctx),
            name = "Low balance alert",
            description = "Remind me every hour until I recharge",
            sender = "AD-LBA",
            matchType = MATCH_REGEX,
            pattern = "your balance is below the threshold value of rs\\.?\\s*[0-9.,]+",
            notify = true, remind = true, intervalMin = 60,
            stopSender = "AIRTEL-S", stopPattern = "Digital Purchases: Tns",
            timeLimit = true, fromMin = 7 * 60, toMin = 23 * 60
        ),
        Rule(
            id = nextId(ctx),
            name = "Forward OTP",
            description = "Add your father's number, then switch this rule on",
            enabled = false,
            sender = "AD-AIRTEL-S",
            matchType = MATCH_ANY,
            notify = false, forward = true, forwardTo = "", prefix = "AIRTEL OTP"
        )
    )
}
