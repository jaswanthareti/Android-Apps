package com.example.smssentinel

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.PowerManager

/** Live permission / setup state, used by the home pill and the Settings screen. */
object Perms {
    private fun granted(ctx: Context, p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    fun smsReceive(ctx: Context) = granted(ctx, Manifest.permission.RECEIVE_SMS)
    fun smsSend(ctx: Context) = granted(ctx, Manifest.permission.SEND_SMS)
    fun notifications(ctx: Context) = ctx.service<NotificationManager>().areNotificationsEnabled()

    fun fullScreen(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 34) ctx.service<NotificationManager>().canUseFullScreenIntent() else true

    fun battery(ctx: Context): Boolean =
        ctx.service<PowerManager>().isIgnoringBatteryOptimizations(ctx.packageName)

    /** SMS in/out and notifications: the minimum for the app to do its job. */
    fun coreReady(ctx: Context) = smsReceive(ctx) && smsSend(ctx) && notifications(ctx)

    fun allReady(ctx: Context) = coreReady(ctx) && fullScreen(ctx) && battery(ctx)
}
