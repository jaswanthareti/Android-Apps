package com.example.smssentinel

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        RuleStore.load(ctx)
            .filter { it.enabled && it.remind && Alerts.isReminding(ctx, it.id) }
            .forEach { Alerts.scheduleNext(ctx, it) }
    }
}
