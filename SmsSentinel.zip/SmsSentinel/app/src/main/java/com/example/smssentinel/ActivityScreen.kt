package com.example.smssentinel

import android.view.View

private val FILTERS = listOf("All", "Forwarded", "Alarms", "Reminders", "Other")

private fun matchesFilter(e: Event, filter: Int): Boolean = when (filter) {
    1 -> e.type == EV_FORWARDED
    2 -> e.type == EV_ALARM
    3 -> e.type == EV_REMINDER
    4 -> e.type == EV_MATCHED || e.type == EV_SYSTEM
    else -> true
}

/** Activity tab: history of everything the rules did, grouped by day. */
fun MainActivity.activityScreen(): View {
    val a = this
    val p = page(a)
    val all = EventLog.all(a)

    val clear = if (all.isEmpty()) null else pill(a, "Clear", BAD) {
        confirm(a, "Clear history?", "This removes the activity list. Your rules are not affected.", "Clear") {
            EventLog.clear(a)
            a.refresh()
        }
    }
    p.put(screenHeader(a, "Activity", if (all.isEmpty()) "Nothing yet" else "Last ${all.size} events", clear))
    p.put(
        filterChips(a, FILTERS, a.activityFilter) {
            a.activityFilter = it
            a.refresh()
        },
        top = 14
    )

    val shown = all.filter { matchesFilter(it, a.activityFilter) }
    if (shown.isEmpty()) {
        p.put(
            emptyState(
                a,
                "No activity here",
                if (all.isEmpty()) "When a rule forwards an SMS, rings an alarm or sends a reminder, it shows up here."
                else "Nothing matches this filter."
            ),
            top = 12
        )
    } else {
        for ((day, list) in shown.groupBy { dayLabel(it.time) }) {
            p.put(text(a, day, 13f, MUTED, true), top = 18, bottom = 8)
            val c = card(a)
            list.forEachIndexed { i, e ->
                if (i > 0) c.addView(divider(a))
                c.addView(eventRow(a, e))
            }
            p.put(c)
        }
    }
    return scrolled(a, p)
}
