package com.example.smssentinel

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.view.View
import android.widget.LinearLayout
import java.security.MessageDigest

/** Settings tab: setup checklist, preferences, backup, tests, help and about. */
fun MainActivity.settingsScreen(): View {
    val a = this
    val p = page(a)
    p.put(screenHeader(a, "Settings", "Permissions, backup and help"))

    // ---------------------------------------------------------------- setup
    p.put(sectionHeader(a, "Setup"))
    val setup = card(a)
    setup.addView(statusRow(a, R.drawable.ic_sms, "Receive SMS", "Lets Guardly see incoming messages", Perms.smsReceive(a), "Allow") { a.requestCore() })
    setup.addView(divider(a))
    setup.addView(statusRow(a, R.drawable.ic_send, "Send SMS", "Only used to forward messages you chose", Perms.smsSend(a), "Allow") { a.requestCore() })
    setup.addView(divider(a))
    setup.addView(statusRow(a, R.drawable.ic_bell, "Notifications", "Alerts, reminders and the alarm", Perms.notifications(a), "Allow") {
        if (Perms.smsReceive(a) && Perms.smsSend(a)) a.openNotificationSettings() else a.requestCore()
    })
    setup.addView(divider(a))
    setup.addView(statusRow(a, R.drawable.ic_bolt, "Full-screen alarm", "Shows the alarm screen over the lock screen", Perms.fullScreen(a), "Allow") { a.openFullScreenSettings() })
    setup.addView(divider(a))
    setup.addView(statusRow(a, R.drawable.ic_shield, "Run in background", "Recommended so Samsung never stops Guardly", Perms.battery(a), "Open") { a.openBatterySettings() })
    p.put(setup)

    if (!Perms.coreReady(a)) {
        p.put(button(a, "Allow required permissions", Btn.PRIMARY) { a.requestCore() }, top = 12)
    }
    p.put(
        settingRow(a, R.drawable.ic_settings, MUTED, "Open app settings", "If an Allow button does nothing, switch the permission on here", null) { a.openAppSettings() }
            .also { it.setPadding(a.dp(2), a.dp(12), 0, 0) }
    )

    val help = card(a)
    help.addView(text(a, "Samsung tips", 15f, INK, true))
    help.put(
        text(
            a,
            "If permissions are greyed out: Settings > Apps > Guardly > the 3-dot menu > Allow restricted settings.\n\n" +
                "For reliable alarms: Settings > Apps > Guardly > Battery > Unrestricted, and add Guardly to Device care > Battery > Background usage limits > Never sleeping apps.",
            13f, MUTED
        ),
        top = 6
    )
    p.put(help, top = 8)

    // ---------------------------------------------------------------- preferences
    p.put(sectionHeader(a, "Preferences"))
    val prefs = card(a)
    prefs.addView(
        settingRow(
            a, R.drawable.ic_send, ACCENT, "Forwarding confirmation",
            "Show a quiet notification after each forwarded SMS",
            switchView(a, RuleStore.confirmForward(a)) { RuleStore.setConfirmForward(a, it) }
        )
    )
    p.put(prefs)

    // ---------------------------------------------------------------- try it
    p.put(sectionHeader(a, "Try it"))
    val tests = card(a)
    tests.addView(
        settingRow(a, R.drawable.ic_bell, BAD, "Test the alarm", "Rings and opens the alarm screen", pill(a, "Test", BAD) {
            sendTest(a, Rule(name = "Guardly test", alarm = true))
        })
    )
    tests.addView(divider(a))
    tests.addView(
        settingRow(a, R.drawable.ic_sms, TEAL, "Test a notification", "A normal alert, as a rule would show", pill(a, "Test", TEAL) {
            sendTest(a, Rule(name = "Guardly test"))
        })
    )
    p.put(tests)

    // ---------------------------------------------------------------- backup
    p.put(sectionHeader(a, "Backup"))
    val backup = card(a)
    backup.addView(text(a, "Updating the app keeps your rules. Use a backup only when you move to a new phone or uninstall.", 13f, MUTED))
    val br = row(a)
    br.putH(button(a, "Copy backup", Btn.SECONDARY) { copyBackup(a) }, 1f)
    br.putH(button(a, "Restore", Btn.GHOST) { restoreBackup(a) }, 1f, 10)
    backup.put(br, top = 12)
    p.put(backup)

    // ---------------------------------------------------------------- how it works
    p.put(sectionHeader(a, "How Guardly works"))
    val how = card(a)
    val hr = row(a)
    hr.addView(roundedImage(a, R.drawable.art_help, 14), LinearLayout.LayoutParams(a.dp(88), a.dp(88)))
    val ht = column(a)
    ht.addView(text(a, "A rule has three parts", 15f, INK, true))
    ht.addView(text(a, "Who the SMS is from, what it says, and what to do: notify, alarm, repeat a reminder or forward it.", 13f, MUTED))
    hr.putH(ht, 1f, 14)
    how.addView(hr)
    p.put(how)

    // ---------------------------------------------------------------- about
    p.put(sectionHeader(a, "About"))
    val about = card(a)
    about.addView(aboutLine(a, "App", "Guardly  -  " + versionLabel(a)))
    about.addView(aboutLine(a, "Package", a.packageName))
    about.addView(aboutLine(a, "Signing key", signingKey(a)))
    about.addView(aboutLine(a, "Internet", "No internet permission. Nothing leaves your phone except SMS you choose to forward."))
    about.put(
        text(a, "The signing key and package name stay the same on every build, so a new APK installs over the old app as an update.", 12f, MUTED),
        top = 10
    )
    p.put(about)

    return scrolled(a, p)
}

private fun statusRow(
    ctx: Context, icon: Int, title: String, sub: String, ok: Boolean, action: String, onClick: () -> Unit
): LinearLayout {
    val trailing: View = if (ok) iconView(ctx, R.drawable.ic_check, 22, OK) else pill(ctx, action, WARN, onClick)
    return settingRow(ctx, icon, if (ok) OK else WARN, title, sub, trailing)
}

private fun aboutLine(ctx: Context, label: String, value: String): LinearLayout {
    val c = column(ctx)
    c.setPadding(0, ctx.dp(6), 0, ctx.dp(6))
    c.addView(text(ctx, label, 12f, MUTED, true))
    c.addView(text(ctx, value, 14f, INK))
    return c
}

// ---------------------------------------------------------------- backup helpers

private fun copyBackup(a: MainActivity) {
    val cm = a.service<ClipboardManager>()
    cm.setPrimaryClip(ClipData.newPlainText("Guardly rules", RuleStore.exportJson(a)))
    toast(a, "Backup copied. Paste it somewhere safe, for example a note to yourself.")
}

private fun restoreBackup(a: MainActivity) {
    val cm = a.service<ClipboardManager>()
    val clip = cm.primaryClip
    val text = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(a).toString() else ""
    if (!text.contains("\"guardly\"")) {
        toast(a, "The clipboard does not contain a Guardly backup. Copy it first, then tap Restore.")
        return
    }
    confirm(a, "Restore backup?", "This replaces all your current rules with the backup.", "Restore") {
        try {
            val n = RuleStore.importJson(a, text)
            toast(a, "Restored $n rules")
            a.refresh()
        } catch (e: Exception) {
            toast(a, "That backup could not be read.")
        }
    }
}

// ---------------------------------------------------------------- about helpers

private fun versionLabel(ctx: Context): String = try {
    val pi = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
    "Version ${pi.versionName} (build ${buildNumber(pi)})"
} catch (e: Exception) {
    "Version unknown"
}

@Suppress("DEPRECATION")
private fun buildNumber(pi: android.content.pm.PackageInfo): Long =
    if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else pi.versionCode.toLong()

/** Short SHA-256 of the key the installed APK is signed with. Must be identical for updates to work. */
private fun signingKey(ctx: Context): String = try {
    val sig = firstSignature(ctx)
    if (sig == null) {
        "unknown"
    } else {
        val d = MessageDigest.getInstance("SHA-256").digest(sig.toByteArray())
        d.take(8).joinToString(":") { "%02X".format(it) }
    }
} catch (e: Exception) {
    "unknown"
}

@Suppress("DEPRECATION")
private fun firstSignature(ctx: Context): android.content.pm.Signature? =
    if (Build.VERSION.SDK_INT >= 28) {
        ctx.packageManager.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
            .signingInfo?.apkContentsSigners?.firstOrNull()
    } else {
        ctx.packageManager.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNATURES).signatures?.firstOrNull()
    }
