package com.example.smssentinel

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Handles reminder alarms and the buttons on notifications (Done, Snooze, Dismiss). */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getIntExtra(Alerts.EXTRA_RULE, 0)
        if (id == 0) return
        val minutes = intent.getIntExtra(Alerts.EXTRA_MIN, 0)
        val rule = RuleStore.get(ctx, id)

        when (intent.action) {
            Alerts.ACTION_FIRE -> {
                if (rule == null || !rule.enabled || !Alerts.isReminding(ctx, id)) {
                    Alerts.stopReminder(ctx, id, "rule turned off or removed")
                    return
                }
                val text = Alerts.savedText(ctx, id)
                if (Alerts.post(ctx, rule, text, KIND_REMINDER)) {
                    EventLog.add(ctx, EV_REMINDER, rule.name, "Reminder sent")
                }
                Alerts.scheduleNext(ctx, rule, rule.intervalMin)
            }
            Alerts.ACTION_STOP -> Alerts.stopReminder(ctx, id, "marked as done")
            Alerts.ACTION_DISMISS -> Alerts.dismiss(ctx, id)
            Alerts.ACTION_SNOOZE_REMINDER -> if (rule != null) Alerts.snoozeReminder(ctx, rule, if (minutes > 0) minutes else 60)
            Alerts.ACTION_SNOOZE_ALARM -> if (rule != null) Alerts.snoozeAlarm(ctx, rule, if (minutes > 0) minutes else 10)
            Alerts.ACTION_ALARM_AGAIN -> if (rule != null) {
                Alerts.post(ctx, rule, Alerts.savedText(ctx, id), KIND_ALARM, true)
                EventLog.add(ctx, EV_ALARM, rule.name, "Alarm rang again after snooze")
            }
        }
    }
}
