package com.example.smssentinel

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getIntExtra(Alerts.EXTRA_RULE, 0)
        if (id == 0) return
        when (intent.action) {
            Alerts.ACTION_FIRE -> {
                val r = RuleStore.load(ctx).firstOrNull { it.id == id }
                if (r == null || !r.enabled || !Alerts.isReminding(ctx, id)) {
                    Alerts.stopReminder(ctx, id, "rule off or removed")
                    return
                }
                Alerts.fire(ctx, r, "Reminder: " + Alerts.reminderText(ctx, id))
                Alerts.scheduleNext(ctx, r)
            }
            Alerts.ACTION_STOP -> Alerts.stopReminder(ctx, id, "stopped by you")
            Alerts.ACTION_DISMISS -> ctx.getSystemService(NotificationManager::class.java).cancel(id)
        }
    }
}
