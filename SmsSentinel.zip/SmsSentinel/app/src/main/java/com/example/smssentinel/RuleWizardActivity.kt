package com.example.smssentinel

import android.app.Activity
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.window.OnBackInvokedDispatcher

/**
 * Create or edit a rule in three steps: Trigger (who / what), Actions (what to do), Settings (when, limits).
 * Pass [EXTRA_ID] to edit an existing rule; leave it out to create a new one.
 */
class RuleWizardActivity : Activity() {
    companion object {
        const val EXTRA_ID = "rule_id"
        private val STEP_NAMES = listOf("Trigger", "Actions", "Settings")
        private val NO_SUGGEST = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
    }

    private val ctx: Context get() = this

    private lateinit var r: Rule
    private var isNew = true
    private var step = 0
    private var saved = false

    // sample SMS used by the live tester (kept when moving between steps)
    private var sampleSender = ""
    private var sampleText = ""
    private var testResult: TextView? = null

    private lateinit var titleView: TextView
    private lateinit var subView: TextView
    private lateinit var stepper: LinearLayout
    private lateinit var body: FrameLayout
    private lateinit var bar: LinearLayout
    private lateinit var backBtn: Button
    private lateinit var nextBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getIntExtra(EXTRA_ID, 0)
        r = (if (id != 0) RuleStore.get(this, id) else null) ?: Rule(name = "")
        isNew = r.id == 0

        val root = column(this)
        root.setBackgroundColor(BG)

        // header
        val head = row(this)
        head.setPadding(dp(8), dp(10), dp(20), dp(0))
        head.addView(iconButton(this, R.drawable.ic_close) { finish() })
        val titles = column(this)
        titleView = text(this, "", 20f, INK, true)
        subView = text(this, "", 13f, MUTED)
        titles.addView(titleView)
        titles.addView(subView)
        head.putH(titles, 1f, 4)
        root.addView(head)

        stepper = row(this)
        stepper.setPadding(dp(28), dp(14), dp(28), dp(6))
        root.addView(stepper)

        body = FrameLayout(this)
        root.addView(body, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        // bottom bar
        bar = row(this)
        bar.setPadding(dp(20), dp(10), dp(20), dp(14))
        backBtn = button(this, "Cancel", Btn.GHOST) { goBack() }
        nextBtn = button(this, "Next", Btn.PRIMARY) { onNext() }
        bar.putH(backBtn, 1f)
        bar.putH(nextBtn, 1f, 12)
        root.addView(bar)

        setContentView(root)
        applyInsets(root)
        showStep()

        if (Build.VERSION.SDK_INT >= 33) {
            onBackInvokedDispatcher.registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT) { goBack() }
        }
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        goBack()
    }

    private fun goBack() {
        if (step > 0 && !saved) {
            step--
            showStep()
        } else {
            finish()
        }
    }

    private fun onNext() {
        if (step < 2) {
            val problem = problem(step)
            if (problem != null) {
                toast(this, problem)
                return
            }
            step++
            showStep()
        } else {
            save()
        }
    }

    // ---------------------------------------------------------------- validation

    /** Returns what is wrong with the rule up to and including [through] (0 = trigger, 1 = actions), or null. */
    private fun problem(through: Int): String? {
        if (r.sender.isBlank() && r.matchType == MATCH_ANY) {
            return "Enter a sender, or choose a text condition. Otherwise every SMS would match."
        }
        if (r.matchType != MATCH_ANY && r.pattern.isBlank()) return "Enter the text to look for."
        if (r.matchType == MATCH_REGEX && !Matcher.validRegex(r.pattern)) return "That pattern is not a valid regular expression."
        if (through >= 1) {
            if (!r.notify && !r.alarm && !r.remind && !r.forward) return "Turn on at least one action."
            if (r.forward && r.forwardTo.filter { it.isDigit() }.length < 3) return "Enter the number to forward to."
            if (r.remind && r.intervalMin < 1) return "The reminder interval must be at least 1 minute."
        }
        return null
    }

    private fun autoName(): String =
        if (r.sender.isNotBlank()) "SMS from ${r.sender.trim()}" else "My rule"

    private fun save() {
        val problem = problem(1)
        if (problem != null) {
            toast(this, problem)
            return
        }
        if (r.name.isBlank()) r.name = autoName()
        r.intervalMin = r.intervalMin.coerceAtLeast(1)
        val wasReminding = r.id != 0 && Alerts.isReminding(this, r.id)
        r = RuleStore.upsert(this, r)
        if (wasReminding && (!r.remind || !r.enabled)) Alerts.stopReminder(this, r.id, "rule changed")
        saved = true
        showSaved()
    }

    // ---------------------------------------------------------------- frame: stepper, buttons

    private fun showStep() {
        testResult = null
        renderStepper()
        titleView.text = if (isNew) "New rule" else "Edit rule"
        subView.text = "Step ${step + 1} of 3  -  ${STEP_NAMES[step]}"
        backBtn.text = if (step == 0) "Cancel" else "Back"
        nextBtn.text = if (step == 2) "Save rule" else "Next"

        val p = column(this)
        p.setPadding(dp(20), dp(12), dp(20), dp(24))
        when (step) {
            0 -> buildTrigger(p)
            1 -> buildActions(p)
            else -> buildSettings(p)
        }
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(p)
        body.removeAllViews()
        body.addView(sv)
        hideKeyboard()
    }

    private fun renderStepper() {
        stepper.removeAllViews()
        STEP_NAMES.forEachIndexed { i, name ->
            if (i > 0) {
                val line = View(this)
                line.setBackgroundColor(if (i <= step) PRIMARY_A else LINE)
                stepper.addView(line, LinearLayout.LayoutParams(0, dp(2), 1f).apply { bottomMargin = dp(18) })
            }
            val col = column(this)
            col.gravity = Gravity.CENTER_HORIZONTAL
            val circle = TextView(this)
            circle.gravity = Gravity.CENTER
            circle.text = if (i < step) "✓" else (i + 1).toString()
            circle.setTextColor(if (i <= step) Color.WHITE else MUTED)
            circle.setTypeface(circle.typeface, android.graphics.Typeface.BOLD)
            circle.background = if (i <= step) gradient(this, PRIMARY_A, PRIMARY_B, 16) else rounded(this, CARD, 16, LINE)
            col.addView(circle, LinearLayout.LayoutParams(dp(32), dp(32)))
            col.addView(text(this, name, 12f, if (i == step) INK else MUTED, i == step).apply { setPadding(0, dp(4), 0, 0) })
            stepper.addView(col)
        }
    }

    private fun hideKeyboard() {
        val v = currentFocus ?: body
        service<InputMethodManager>().hideSoftInputFromWindow(v.windowToken, 0)
    }

    // ---------------------------------------------------------------- step 1: trigger

    private fun buildTrigger(p: LinearLayout) {
        p.put(text(ctx, "What should trigger this rule?", 20f, INK, true))
        p.put(text(ctx, "Tell Guardly which SMS to look for.", 14f, MUTED), top = 4, bottom = 18)

        p.put(fieldLabel(ctx, "Rule name"))
        p.put(input(ctx, "e.g. Low balance alert", r.name, InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES) { r.name = it })

        p.put(fieldLabel(ctx, "SMS is from"), top = 18)
        p.put(input(ctx, "e.g. AD-LBA or +919876543210", r.sender, NO_SUGGEST) {
            r.sender = it
            updateTest()
        })
        p.put(note(ctx, "A sender name or a phone number. Leave empty to accept any sender."))

        p.put(fieldLabel(ctx, "SMS text"), top = 18)
        val patternBox = column(ctx)
        val patternHelp = note(ctx, "")
        val patternInput = input(ctx, "", r.pattern, NO_SUGGEST) {
            r.pattern = it
            updateTest()
        }
        fun applyType() {
            patternBox.visibility = if (r.matchType == MATCH_ANY) View.GONE else View.VISIBLE
            when (r.matchType) {
                MATCH_KEYWORDS -> {
                    patternInput.hint = "e.g. low balance, threshold"
                    patternHelp.text = "Separate several words with commas. The SMS matches if it contains any one of them."
                }
                MATCH_EXACT -> {
                    patternInput.hint = "The full SMS text"
                    patternHelp.text = "The SMS must be exactly this text, nothing more."
                }
                else -> {
                    patternInput.hint = "e.g. balance.*below"
                    patternHelp.text = "Advanced: a regular expression. Use the tester below to check it."
                }
            }
        }
        p.put(choiceRow(ctx, listOf("Any text", "Contains", "Exact", "Pattern"), r.matchType) {
            r.matchType = it
            applyType()
            updateTest()
        })
        patternBox.put(patternInput, top = 10)
        patternBox.put(patternHelp)
        p.put(patternBox)
        applyType()

        val opts = card(ctx)
        opts.addView(
            settingRow(
                ctx, R.drawable.ic_info, ACCENT, "Ignore capital letters", "ABC and abc count as the same",
                switchView(ctx, !r.caseSensitive) {
                    r.caseSensitive = !it
                    updateTest()
                }
            )
        )
        opts.addView(divider(ctx))
        opts.addView(
            settingRow(
                ctx, R.drawable.ic_info, ACCENT, "Ignore spaces around the text", "Leading and trailing spaces are removed first",
                switchView(ctx, r.trimSpaces) {
                    r.trimSpaces = it
                    updateTest()
                }
            )
        )
        p.put(opts, top = 16)

        // live tester
        val t = card(ctx)
        t.addView(text(ctx, "Try it with a sample SMS", 15f, INK, true))
        t.put(input(ctx, "Sample sender (optional)", sampleSender, NO_SUGGEST) {
            sampleSender = it
            updateTest()
        }, top = 10)
        t.put(input(ctx, "Paste or type a sample SMS", sampleText, InputType.TYPE_CLASS_TEXT, 3) {
            sampleText = it
            updateTest()
        }, top = 8)
        val result = text(ctx, "", 14f, MUTED)
        testResult = result
        t.put(result, top = 10)
        p.put(t, top = 16)
        updateTest()
    }

    private fun updateTest() {
        val tv = testResult ?: return
        if (r.sender.isBlank() && r.matchType == MATCH_ANY) {
            tv.setTextColor(WARN)
            tv.text = "Add a sender or a text condition, otherwise this rule would match every SMS."
            return
        }
        if (r.matchType == MATCH_REGEX && r.pattern.isNotBlank() && !Matcher.validRegex(r.pattern)) {
            tv.setTextColor(BAD)
            tv.text = "That pattern is not a valid regular expression."
            return
        }
        val senderChecked = sampleSender.isNotBlank()
        val textChecked = sampleText.isNotBlank()
        if (!senderChecked && !textChecked) {
            tv.setTextColor(MUTED)
            tv.text = "Type a sample above to see whether the rule would trigger."
            return
        }
        val senderOk = !senderChecked || Matcher.senderMatches(ctx, sampleSender, r.sender)
        val textOk = !textChecked || Matcher.textMatches(r, sampleText)
        val hit = senderOk && textOk
        val lines = mutableListOf<String>()
        lines.add(if (hit) "Match: this rule would trigger." else "No match: this rule would stay quiet.")
        if (senderChecked) lines.add("Sender: " + if (senderOk) "matches" else "does not match")
        if (textChecked) lines.add("Text: " + if (textOk) "matches" else "does not match")
        if (!senderChecked && r.sender.isNotBlank()) lines.add("Add a sample sender to check the sender too.")
        tv.setTextColor(if (hit) OK else BAD)
        tv.text = lines.joinToString("\n")
    }

    // ---------------------------------------------------------------- step 2: actions

    private fun buildActions(p: LinearLayout) {
        p.put(text(ctx, "What should Guardly do?", 20f, INK, true))
        p.put(text(ctx, "Pick one or more actions.", 14f, MUTED), top = 4, bottom = 14)

        p.put(
            actionCard(R.drawable.ic_sms, TEAL, "Show a notification", "A normal alert in your notification shade", r.notify, null) { r.notify = it },
            bottom = 12
        )
        p.put(
            actionCard(
                R.drawable.ic_bell, BAD, "Ring a loud alarm", "Alarm sound and a full-screen alert until you dismiss or snooze it",
                r.alarm, null
            ) { r.alarm = it },
            bottom = 12
        )
        p.put(actionCard(R.drawable.ic_clock, PURPLE, "Repeat a reminder", "Remind me again and again until a stop message arrives", r.remind, reminderDetails()) { r.remind = it }, bottom = 12)
        p.put(actionCard(R.drawable.ic_send, ACCENT, "Forward the SMS", "Send a copy to another number using your default SIM", r.forward, forwardDetails()) { r.forward = it })
    }

    private fun actionCard(
        icon: Int, color: Int, title: String, sub: String, on: Boolean, details: View?, onToggle: (Boolean) -> Unit
    ): LinearLayout {
        val c = card(ctx)
        fun paint(v: Boolean) {
            c.background = rounded(ctx, if (v) tint(color, 0.10f) else CARD, 18, if (v) color else LINE)
            details?.visibility = if (v) View.VISIBLE else View.GONE
        }
        val sw = switchView(ctx, on) { v ->
            paint(v)
            onToggle(v)
        }
        c.addView(settingRow(ctx, icon, color, title, sub, sw))
        if (details != null) c.put(details, top = 6)
        paint(on)
        return c
    }

    private fun reminderDetails(): View {
        val d = column(ctx)
        d.addView(divider(ctx))
        d.put(fieldLabel(ctx, "Repeat every"), top = 12)

        val presets = listOf(15, 30, 60, 120, 240, 720, 1440)
        val labels = presets.map { fmtInterval(it) } + "Custom"
        val sel = presets.indexOf(r.intervalMin).let { if (it < 0) presets.size else it }
        val customBox = column(ctx)
        customBox.visibility = if (sel == presets.size) View.VISIBLE else View.GONE
        d.put(choiceRow(ctx, labels, sel) { i ->
            if (i < presets.size) {
                r.intervalMin = presets[i]
                customBox.visibility = View.GONE
            } else {
                customBox.visibility = View.VISIBLE
            }
        })
        customBox.put(fieldLabel(ctx, "Minutes between reminders"), top = 10)
        customBox.put(input(ctx, "e.g. 45", r.intervalMin.toString(), InputType.TYPE_CLASS_NUMBER) {
            val n = it.toIntOrNull()
            if (n != null && n > 0) r.intervalMin = n
        })
        customBox.put(note(ctx, "Android may delay reminders shorter than 15 minutes while the phone is idle."))
        d.put(customBox)

        d.put(fieldLabel(ctx, "Stop when an SMS arrives from"), top = 16)
        d.put(input(ctx, "e.g. AIRTEL-S", r.stopSender, NO_SUGGEST) { r.stopSender = it })
        d.put(fieldLabel(ctx, "...and its text contains"), top = 12)
        d.put(input(ctx, "e.g. Digital Purchases: Tns", r.stopPattern, NO_SUGGEST) { r.stopPattern = it })
        d.put(note(ctx, "Leave both empty to stop only with Mark as done on the notification."))
        return d
    }

    private fun forwardDetails(): View {
        val d = column(ctx)
        d.addView(divider(ctx))
        d.put(fieldLabel(ctx, "Forward to number"), top = 12)
        d.put(input(ctx, "e.g. +91 98765 43210", r.forwardTo, InputType.TYPE_CLASS_PHONE) { r.forwardTo = it })
        d.put(fieldLabel(ctx, "Text to add before the message (optional)"), top = 12)
        val preview = note(ctx, "")
        fun updatePreview() {
            val pre = r.prefix.trim()
            preview.text = "Sent as: " + (if (pre.isEmpty()) "" else "$pre ") + "838452 is your one-time password"
        }
        d.put(input(ctx, "e.g. AIRTEL OTP", r.prefix) {
            r.prefix = it
            updatePreview()
        })
        d.put(preview)
        updatePreview()
        return d
    }

    // ---------------------------------------------------------------- step 3: settings

    private fun buildSettings(p: LinearLayout) {
        p.put(text(ctx, "Fine-tune the rule", 20f, INK, true))
        p.put(text(ctx, "All optional. The defaults work well.", 14f, MUTED), top = 4, bottom = 14)

        p.put(fieldLabel(ctx, "Note (optional)"))
        p.put(input(ctx, "e.g. Remind me every hour until I recharge", r.description, InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES) {
            r.description = it
        })

        // allowed hours
        val hours = card(ctx)
        val hoursDetails = column(ctx)
        hoursDetails.visibility = if (r.timeLimit) View.VISIBLE else View.GONE
        hours.addView(
            settingRow(
                ctx, R.drawable.ic_clock, PURPLE, "Only run during certain hours",
                "Outside these hours matches are ignored and reminders wait",
                switchView(ctx, r.timeLimit) {
                    r.timeLimit = it
                    hoursDetails.visibility = if (it) View.VISIBLE else View.GONE
                }
            )
        )
        val times = row(ctx)
        times.putH(timeButton("From", { r.fromMin }, { r.fromMin = it }), 1f)
        times.putH(timeButton("To", { r.toMin }, { r.toMin = it }), 1f, 10)
        hoursDetails.put(times, top = 6)
        hours.put(hoursDetails)
        p.put(hours, top = 16)

        // repeat protection
        p.put(fieldLabel(ctx, "Ignore repeat matches for"), top = 20)
        p.put(numberChoice(listOf(0, 5, 15, 30, 60, 360), r.cooldownMin, { if (it == 0) "Off" else fmtInterval(it) }) { r.cooldownMin = it })
        p.put(note(ctx, "Stops a burst of similar SMS from alerting you again and again."))

        // auto switch-off
        p.put(fieldLabel(ctx, "Turn the rule off after"), top = 20)
        p.put(
            numberChoice(listOf(0, 1, 3, 10, 50), r.maxTriggers, {
                when (it) {
                    0 -> "Never"
                    1 -> "1 time"
                    else -> "$it times"
                }
            }) { r.maxTriggers = it }
        )

        // summary
        val s = card(ctx)
        s.addView(text(ctx, "Summary", 15f, INK, true))
        s.put(text(ctx, r.describe(), 14f, INK), top = 8)
        val chips = r.chips()
        if (chips.isNotEmpty()) s.put(chipRow(ctx, chips), top = 10)
        s.put(divider(ctx), top = 10)
        s.addView(
            settingRow(
                ctx, R.drawable.ic_shield, OK, "Rule is active", "Switch off to keep it without running it",
                switchView(ctx, r.enabled) { r.enabled = it }
            )
        )
        p.put(s, top = 22)

        p.put(button(ctx, "Send test alert", Btn.SECONDARY) { sendTest(ctx, r) }, top = 12)
        if (!isNew) {
            p.put(button(ctx, "Delete rule", Btn.DANGER) {
                confirm(ctx, "Delete rule?", "\"${r.name}\" will be removed.", "Delete") {
                    Alerts.stopReminder(ctx, r.id, "rule deleted")
                    RuleStore.delete(ctx, r.id)
                    finish()
                }
            }, top = 10)
        }
    }

    private fun numberChoice(values: List<Int>, current: Int, label: (Int) -> String, onSelect: (Int) -> Unit): View {
        val vs = if (current in values) values else (values + current).sorted()
        return choiceRow(ctx, vs.map(label), vs.indexOf(current)) { onSelect(vs[it]) }
    }

    private fun timeButton(label: String, get: () -> Int, set: (Int) -> Unit): TextView {
        val tv = text(ctx, "", 15f, INK, true)
        tv.gravity = Gravity.CENTER
        tv.background = rounded(ctx, FIELD, 12, LINE)
        tv.setPadding(dp(12), dp(14), dp(12), dp(14))
        fun paint() {
            tv.text = "$label  ${fmtMin(get())}"
        }
        tv.setOnClickListener {
            TimePickerDialog(ctx, { _, h, m ->
                set(h * 60 + m)
                paint()
            }, get() / 60, get() % 60, false).show()
        }
        paint()
        return tv
    }

    // ---------------------------------------------------------------- saved

    private fun showSaved() {
        stepper.visibility = View.GONE
        bar.visibility = View.GONE
        titleView.text = "Rule saved"
        subView.text = ""
        hideKeyboard()

        val p = column(ctx)
        p.gravity = Gravity.CENTER_HORIZONTAL
        p.setPadding(dp(24), dp(16), dp(24), dp(24))
        p.addView(roundedImage(ctx, R.drawable.art_success, 24), LinearLayout.LayoutParams(dp(190), dp(190)))
        p.put(text(ctx, r.name, 22f, INK, true).apply { gravity = Gravity.CENTER }, top = 18)
        p.put(text(ctx, r.describe(), 14f, MUTED).apply { gravity = Gravity.CENTER }, top = 6)
        val chips = r.chips()
        if (chips.isNotEmpty()) {
            val cr = row(ctx)
            cr.gravity = Gravity.CENTER
            chips.forEach {
                cr.putH(chip(ctx, it.first, it.second), 0f, 6)
            }
            p.put(cr, top = 12)
        }

        if (!Perms.coreReady(ctx)) {
            val warn = card(ctx, tint(WARN, 0.10f), WARN)
            warn.addView(text(ctx, "One more step", 15f, WARN, true))
            warn.put(text(ctx, "Guardly still needs SMS and notification permission before this rule can run.", 13f, INK), top = 4)
            warn.put(button(ctx, "Open setup", Btn.PRIMARY) {
                startActivity(
                    Intent(ctx, MainActivity::class.java)
                        .putExtra(MainActivity.EXTRA_TAB, MainActivity.TAB_SETTINGS)
                        .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                )
                finish()
            }, top = 10)
            p.put(warn, top = 20)
        }

        p.put(button(ctx, "Done", Btn.PRIMARY) { finish() }, top = 24)
        p.put(button(ctx, "Send test alert", Btn.GHOST) { sendTest(ctx, r) }, top = 10)

        val sv = ScrollView(ctx)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(p)
        body.removeAllViews()
        body.addView(sv)
    }
}
