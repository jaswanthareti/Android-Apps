package com.example.smssentinel

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import com.example.smssentinel.ui.Chip
import com.example.smssentinel.ui.ChoiceChip
import com.example.smssentinel.ui.Glyph
import com.example.smssentinel.ui.GhostButton
import com.example.smssentinel.ui.GradientButton
import com.example.smssentinel.ui.IconBadge
import com.example.smssentinel.ui.Mascot
import com.example.smssentinel.ui.MascotLoader
import com.example.smssentinel.ui.RoundIconButton
import com.example.smssentinel.ui.Sentinel
import com.example.smssentinel.ui.SentinelBackground
import com.example.smssentinel.ui.SentinelCard
import com.example.smssentinel.ui.SentinelIcon
import com.example.smssentinel.ui.SentinelTheme
import com.example.smssentinel.ui.SwitchRow
import com.example.smssentinel.ui.staggerIn
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class RuleEditActivity : ComponentActivity() {

    private var rule = Rule()

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        val id = intent.getIntExtra("id", 0)
        if (id != 0) RuleStore.load(this).firstOrNull { it.id == id }?.let { rule = it }
        val isNew = rule.id == 0

        setContent {
            SentinelTheme {
                SentinelBackground {
                    RuleEditScreen(
                        initial = rule,
                        isNew = isNew,
                        onCancel = { finish() },
                        onTest = { r ->
                            val t = if (r.id == 0) r.copy(id = 9999) else r
                            Alerts.fire(this, t, "Test alert: this is how the rule will notify you.", true)
                        },
                        onDelete = {
                            Alerts.stopReminder(this, rule.id, "rule deleted")
                            RuleStore.delete(this, rule.id)
                            finish()
                        },
                        onSave = { r -> saveRule(r) }
                    )
                }
            }
        }
    }

    private fun fail(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    /** Returns true if saved. Shared validation, unchanged from the original app. */
    private fun saveRule(r: Rule): Boolean {
        if (r.sender.isBlank() && r.content.isBlank()) {
            fail("Set a sender or some text to match, otherwise the rule would match every SMS.")
            return false
        }
        if (!r.notify && !r.alarm && !r.remind && !r.forward) {
            fail("Choose at least one action.")
            return false
        }
        if (r.forward && r.forwardTo.isBlank()) {
            fail("Enter the number to forward to.")
            return false
        }
        if (r.regex) {
            if (!Matcher.validRegex(r.content) || !Matcher.validRegex(r.stopContent)) {
                fail("The regular expression is not valid.")
                return false
            }
        }
        if (!r.remind) Alerts.stopReminder(this, r.id.takeIf { it != 0 } ?: -1, "reminder turned off")
        RuleStore.upsert(this, r)
        return true
    }
}

@Composable
private fun RuleEditScreen(
    initial: Rule,
    isNew: Boolean,
    onCancel: () -> Unit,
    onTest: (Rule) -> Unit,
    onDelete: () -> Unit,
    onSave: (Rule) -> Boolean
) {
    val p = Sentinel.colors
    var name by remember { mutableStateOf(initial.name) }
    var sender by remember { mutableStateOf(initial.sender) }
    var content by remember { mutableStateOf(initial.content) }
    var regex by remember { mutableStateOf(initial.regex) }
    var notify by remember { mutableStateOf(initial.notify) }
    var alarm by remember { mutableStateOf(initial.alarm) }
    var remind by remember { mutableStateOf(initial.remind) }
    var interval by remember { mutableStateOf(initial.intervalMin.toString()) }
    var quiet by remember { mutableStateOf(initial.quiet) }
    var stopSender by remember { mutableStateOf(initial.stopSender) }
    var stopContent by remember { mutableStateOf(initial.stopContent) }
    var forward by remember { mutableStateOf(initial.forward) }
    var forwardTo by remember { mutableStateOf(initial.forwardTo) }
    var prefix by remember { mutableStateOf(initial.prefix) }

    var showDeleteConfirm by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun currentRule() = initial.copy(
        name = name.trim().ifBlank { "Rule" },
        sender = sender.trim(),
        content = content.trim(),
        regex = regex,
        notify = notify,
        alarm = alarm,
        remind = remind,
        intervalMin = interval.toIntOrNull()?.coerceAtLeast(1) ?: 60,
        quiet = quiet,
        stopSender = stopSender.trim(),
        stopContent = stopContent.trim(),
        forward = forward,
        forwardTo = forwardTo.trim(),
        prefix = prefix.trim()
    )

    if (saving) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            MascotLoader(label = "Saving rule…")
        }
        return
    }

    val regexBad = regex && (!Matcher.validRegex(content) || !Matcher.validRegex(stopContent))
    val intervalValue = interval.toIntOrNull()

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
            // ── Top bar ──
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RoundIconButton(Glyph.Chevron, onCancel, rotate = 180f)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(if (isNew) "New rule" else "Edit rule", style = MaterialTheme.typography.headlineSmall, color = p.ink)
                    Text("Teach Sentinel what to watch for", style = MaterialTheme.typography.labelMedium, color = p.inkSoft)
                }
                GhostButton("Test", { onTest(currentRule()) }, glyph = Glyph.Bolt, tint = p.sky)
            }

            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)
            ) {
                // ── Live preview ──
                PreviewCard(currentRule(), Modifier.staggerIn(0))
                Spacer(Modifier.height(16.dp))

                // ── 1 Match ──
                StepCard(Glyph.Search, "Match", p.sky, Modifier.staggerIn(1)) {
                    SentinelField("Rule name", name, { name = it }, placeholder = "e.g. Low balance")
                    Spacer(Modifier.height(14.dp))
                    SentinelField(
                        "From (name or number). Blank = anyone", sender, { sender = it },
                        placeholder = "e.g. AD-LBA  or  +911234567890"
                    )
                    Hint("A name matches if the sender contains it. Numbers ignore spaces and country-code format.")
                    Spacer(Modifier.height(14.dp))
                    SentinelField(
                        "Message contains. Blank = any text", content, { content = it },
                        placeholder = "e.g. below the threshold",
                        isError = regex && !Matcher.validRegex(content)
                    )
                    SwitchRow("Use a regular expression", regex, hint = "Advanced pattern matching") { regex = it }
                    Hint("Plain text is case-insensitive. Regex example: balance.*below.*rs\\.?\\s*[0-9.]+")
                    if (regexBad) {
                        Text(
                            "That regular expression is not valid.",
                            style = MaterialTheme.typography.labelMedium, color = p.coral,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }

                Spacer(Modifier.height(16.dp))

                // ── 2 React ──
                StepCard(Glyph.Bolt, "React", p.teal, Modifier.staggerIn(2)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ActionTile(Glyph.Bell, "Notify", "Silent banner", notify, p.teal, Modifier.weight(1f)) { notify = !notify }
                        ActionTile(Glyph.Alarm, "Loud alarm", "Until silenced", alarm, p.coral, Modifier.weight(1f)) { alarm = !alarm }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ActionTile(Glyph.Repeat, "Remind", "Repeat until stopped", remind, p.sky, Modifier.weight(1f)) { remind = !remind }
                        ActionTile(Glyph.Send, "Forward", "To another number", forward, p.violet, Modifier.weight(1f)) { forward = !forward }
                    }
                    Spacer(Modifier.height(6.dp))
                    SwitchRow("Quiet hours", quiet, hint = "Pause this rule's alerts 11 PM to 7 AM") { quiet = it }
                }

                // ── 3 Repeat & stop ──
                AnimatedVisibility(visible = remind) {
                    Column {
                        Spacer(Modifier.height(16.dp))
                        StepCard(Glyph.Repeat, "Repeat and stop", p.sky) {
                            Text("Repeat every", style = MaterialTheme.typography.labelLarge, color = p.inkSoft)
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(15, 30, 60, 120).forEach { m ->
                                    ChoiceChip(
                                        if (m < 60) "$m min" else "${m / 60} h",
                                        intervalValue == m, { interval = m.toString() },
                                        Modifier.weight(1f)
                                    )
                                }
                            }
                            Spacer(Modifier.height(12.dp))
                            SentinelField(
                                "Or a custom number of minutes", interval,
                                { interval = it.filter { c -> c.isDigit() } },
                                placeholder = "60", keyboardType = KeyboardType.Number
                            )
                            Spacer(Modifier.height(16.dp))
                            Text("Stop when an SMS arrives…", style = MaterialTheme.typography.labelLarge, color = p.inkSoft)
                            Spacer(Modifier.height(8.dp))
                            SentinelField(
                                "...from (blank = any)", stopSender, { stopSender = it },
                                placeholder = "e.g. AIRTEL-S"
                            )
                            Spacer(Modifier.height(12.dp))
                            SentinelField(
                                "...containing (blank = any)", stopContent, { stopContent = it },
                                placeholder = "e.g. Digital Purchases: Tns",
                                isError = regex && !Matcher.validRegex(stopContent)
                            )
                            Hint("Fill at least one stop box, or stop manually from the notification. Uses the same regex setting as above.")
                        }
                    }
                }

                // ── 4 Forwarding ──
                AnimatedVisibility(visible = forward) {
                    Column {
                        Spacer(Modifier.height(16.dp))
                        StepCard(Glyph.Send, "Forwarding", p.violet) {
                            SentinelField(
                                "Forward to (with country code)", forwardTo, { forwardTo = it },
                                placeholder = "+919876543210", keyboardType = KeyboardType.Phone
                            )
                            Spacer(Modifier.height(12.dp))
                            SentinelField(
                                "Text added before the message (optional)", prefix, { prefix = it },
                                placeholder = "e.g. AIRTEL OTP"
                            )
                            Hint("The forwarded SMS contains only this prefix plus the original message text.")
                        }
                    }
                }

                if (!isNew) {
                    Spacer(Modifier.height(18.dp))
                    GhostButton(
                        "Delete rule", { showDeleteConfirm = true },
                        Modifier.fillMaxWidth(), tint = p.coral
                    )
                }
                Spacer(Modifier.height(130.dp))
            }
        }

        // Sticky save bar over a soft fade.
        Box(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, p.bg.copy(alpha = 0.95f))))
                .navigationBarsPadding().imePadding()
                .padding(horizontal = 20.dp).padding(top = 28.dp, bottom = 16.dp)
        ) {
            GradientButton(
                text = if (isNew) "Create rule" else "Save changes",
                onClick = {
                    val r = currentRule()
                    if (onSave(r)) {
                        scope.launch {
                            saving = true
                            delay(450)
                            onCancel()
                        }
                    }
                },
                glyph = Glyph.Check,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            containerColor = p.surface,
            title = { Text("Delete this rule?", color = p.ink) },
            text = { Text("It stops matching messages immediately.", color = p.inkSoft) },
            confirmButton = {
                TextButton(onClick = { showDeleteConfirm = false; onDelete() }) { Text("Delete", color = p.coral) }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) { Text("Cancel", color = p.sky) }
            }
        )
    }
}

// ════════════════════════════ Pieces ════════════════════════════

private fun joinNatural(parts: List<String>): String = when (parts.size) {
    0 -> ""
    1 -> parts[0]
    else -> parts.dropLast(1).joinToString(", ") + " and " + parts.last()
}

@Composable
private fun PreviewCard(r: Rule, modifier: Modifier = Modifier) {
    val p = Sentinel.colors
    val shape = RoundedCornerShape(24.dp)
    val acts = buildList {
        if (r.notify) add("notify you")
        if (r.alarm) add("ring a loud alarm")
        if (r.remind) add("remind you every ${r.intervalMin} min")
        if (r.forward) add("forward it to " + r.forwardTo.ifBlank { "a number you choose" })
    }
    val bold = SpanStyle(fontWeight = FontWeight.SemiBold, color = p.ink)
    val sentence = buildAnnotatedString {
        append("When a message arrives from ")
        withStyle(bold) { append(r.sender.ifBlank { "anyone" }) }
        if (r.content.isNotBlank()) {
            append(" containing ")
            withStyle(bold) { append("\u201C" + r.content + "\u201D") }
        }
        append(", Sentinel will ")
        withStyle(bold) { append(if (acts.isEmpty()) "do nothing yet" else joinNatural(acts)) }
        append(if (r.quiet) ", except 11 PM to 7 AM." else ".")
    }
    Row(
        modifier.fillMaxWidth().clip(shape).background(p.glass)
            .border(1.5.dp, Brush.linearGradient(p.aurora), shape).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Mascot(size = 64.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text("LIVE PREVIEW", style = MaterialTheme.typography.labelSmall, color = p.teal)
            Spacer(Modifier.height(4.dp))
            Text(sentence, style = MaterialTheme.typography.bodyMedium, color = p.inkSoft)
        }
    }
}

@Composable
private fun StepCard(
    glyph: Glyph,
    title: String,
    tint: Color,
    modifier: Modifier = Modifier,
    content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit
) {
    SentinelCard(modifier) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBadge(glyph, tint, size = 36.dp)
            Spacer(Modifier.width(12.dp))
            Text(title, style = MaterialTheme.typography.titleLarge, color = Sentinel.colors.ink)
        }
        Spacer(Modifier.height(16.dp))
        content()
    }
}

@Composable
private fun ActionTile(
    glyph: Glyph,
    label: String,
    hint: String,
    selected: Boolean,
    tint: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val p = Sentinel.colors
    val shape = RoundedCornerShape(18.dp)
    val bg by animateColorAsState(if (selected) tint.copy(alpha = 0.18f) else Color.Transparent, label = "tileBg")
    val bd by animateColorAsState(if (selected) tint else p.inkSoft.copy(alpha = 0.28f), label = "tileBd")
    Column(
        modifier.clip(shape).background(bg).border(1.5.dp, bd, shape).clickable(onClick = onClick).padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SentinelIcon(glyph, size = 24.dp, tint = if (selected) tint else p.inkSoft)
            Spacer(Modifier.weight(1f))
            if (selected) SentinelIcon(Glyph.Check, size = 18.dp, tint = tint, stroke = 2.4f)
        }
        Spacer(Modifier.height(10.dp))
        Text(label, style = MaterialTheme.typography.titleMedium, color = if (selected) p.ink else p.inkSoft)
        Text(hint, style = MaterialTheme.typography.labelMedium, color = p.inkSoft)
    }
}

@Composable
private fun SentinelField(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    placeholder: String = "",
    keyboardType: KeyboardType = KeyboardType.Text,
    isError: Boolean = false
) {
    val p = Sentinel.colors
    Text(label, style = MaterialTheme.typography.labelLarge, color = p.inkSoft)
    Spacer(Modifier.height(6.dp))
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        placeholder = { Text(placeholder) },
        singleLine = true,
        isError = isError,
        shape = RoundedCornerShape(16.dp),
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = p.sky,
            unfocusedBorderColor = p.inkSoft.copy(alpha = 0.32f),
            errorBorderColor = p.coral,
            focusedTextColor = p.ink,
            unfocusedTextColor = p.ink,
            errorTextColor = p.ink,
            cursorColor = p.sky,
            focusedPlaceholderColor = p.inkSoft.copy(alpha = 0.6f),
            unfocusedPlaceholderColor = p.inkSoft.copy(alpha = 0.6f),
            focusedContainerColor = Color.Transparent,
            unfocusedContainerColor = Color.Transparent,
            errorContainerColor = Color.Transparent
        ),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun Hint(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelMedium,
        color = Sentinel.colors.inkSoft,
        modifier = Modifier.padding(top = 6.dp)
    )
}
