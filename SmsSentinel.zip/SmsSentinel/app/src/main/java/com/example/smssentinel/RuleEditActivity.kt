package com.example.smssentinel

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.smssentinel.ui.PenguinLoader
import com.example.smssentinel.ui.SectionHeading
import com.example.smssentinel.ui.SentinelBackground
import com.example.smssentinel.ui.SentinelCard
import com.example.smssentinel.ui.SentinelTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class RuleEditActivity : ComponentActivity() {

    private var rule = Rule()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getIntExtra("id", 0)
        if (id != 0) RuleStore.load(this).firstOrNull { it.id == id }?.let { rule = it }
        val isNew = rule.id == 0

        setContent {
            SentinelTheme {
                SentinelBackground {
                    RuleEditScreen(
                        initial = rule,
                        isNew = isNew,
                        onCancel = { finish() },
                        onTest = { r ->
                            val t = if (r.id == 0) r.copy(id = 9999) else r
                            Alerts.fire(this, t, "Test alert: this is how the rule will notify you.", true)
                        },
                        onDelete = {
                            Alerts.stopReminder(this, rule.id, "rule deleted")
                            RuleStore.delete(this, rule.id)
                            finish()
                        },
                        onSave = { r -> saveRule(r) }
                    )
                }
            }
        }
    }

    private fun fail(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    /** Returns true if saved. Shared validation, unchanged from the original app. */
    private fun saveRule(r: Rule): Boolean {
        if (r.sender.isBlank() && r.content.isBlank()) {
            fail("Set a sender or some text to match, otherwise the rule would match every SMS.")
            return false
        }
        if (!r.notify && !r.alarm && !r.remind && !r.forward) {
            fail("Choose at least one action.")
            return false
        }
        if (r.forward && r.forwardTo.isBlank()) {
            fail("Enter the number to forward to.")
            return false
        }
        if (r.regex) {
            if (!Matcher.validRegex(r.content) || !Matcher.validRegex(r.stopContent)) {
                fail("The regular expression is not valid.")
                return false
            }
        }
        if (!r.remind) Alerts.stopReminder(this, r.id.takeIf { it != 0 } ?: -1, "reminder turned off")
        RuleStore.upsert(this, r)
        return true
    }
}

@Composable
private fun RuleEditScreen(
    initial: Rule,
    isNew: Boolean,
    onCancel: () -> Unit,
    onTest: (Rule) -> Unit,
    onDelete: () -> Unit,
    onSave: (Rule) -> Boolean
) {
    var name by remember { mutableStateOf(initial.name) }
    var sender by remember { mutableStateOf(initial.sender) }
    var content by remember { mutableStateOf(initial.content) }
    var regex by remember { mutableStateOf(initial.regex) }
    var notify by remember { mutableStateOf(initial.notify) }
    var alarm by remember { mutableStateOf(initial.alarm) }
    var remind by remember { mutableStateOf(initial.remind) }
    var interval by remember { mutableStateOf(initial.intervalMin.toString()) }
    var quiet by remember { mutableStateOf(initial.quiet) }
    var stopSender by remember { mutableStateOf(initial.stopSender) }
    var stopContent by remember { mutableStateOf(initial.stopContent) }
    var forward by remember { mutableStateOf(initial.forward) }
    var forwardTo by remember { mutableStateOf(initial.forwardTo) }
    var prefix by remember { mutableStateOf(initial.prefix) }

    var showDeleteConfirm by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun currentRule() = initial.copy(
        name = name.trim().ifBlank { "Rule" },
        sender = sender.trim(),
        content = content.trim(),
        regex = regex,
        notify = notify,
        alarm = alarm,
        remind = remind,
        intervalMin = interval.toIntOrNull()?.coerceAtLeast(1) ?: 60,
        quiet = quiet,
        stopSender = stopSender.trim(),
        stopContent = stopContent.trim(),
        forward = forward,
        forwardTo = forwardTo.trim(),
        prefix = prefix.trim()
    )

    if (saving) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            PenguinLoader(label = "Saving rule…")
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Text(
            if (isNew) "New rule" else "Edit rule",
            style = MaterialTheme.typography.headlineSmall
        )
        Spacer(Modifier.height(14.dp))

        SentinelCard {
            LabeledField("Rule name", name, { name = it }, placeholder = "e.g. Low balance")
        }

        SectionHeading("When an SMS arrives…")
        SentinelCard {
            LabeledField(
                "Message from (sender name or number). Leave blank for any sender.",
                sender, { sender = it }, placeholder = "e.g. AD-LBA  or  +911234567890"
            )
            HintText("A name matches if the sender contains it. Numbers are matched ignoring spaces and country-code format.")
            Spacer(Modifier.height(12.dp))
            LabeledField(
                "Message contains. Leave blank for any text.",
                content, { content = it }, placeholder = "e.g. below the threshold"
            )
            CheckRow("Treat text as a regular expression (advanced)", regex) { regex = it }
            HintText("Plain text is case-insensitive. Regex example: balance.*below.*rs\\.?\\s*[0-9.]+")
        }

        SectionHeading("Then…")
        SentinelCard {
            CheckRow("Show a notification", notify) { notify = it }
            CheckRow("Ring a loud alarm (repeats until silenced, max 10 min)", alarm) { alarm = it }
            CheckRow("Repeat as a reminder until a stop message arrives", remind) { remind = it }
            Spacer(Modifier.height(8.dp))
            LabeledField(
                "Repeat every (minutes)", interval, { interval = it.filter { c -> c.isDigit() } },
                placeholder = "60", keyboardType = KeyboardType.Number
            )
            CheckRow("Pause this rule's alerts 11 PM to 7 AM", quiet) { quiet = it }
        }

        SectionHeading("Stop the reminder when…")
        SentinelCard {
            LabeledField(
                "...an SMS arrives from (blank = any)", stopSender, { stopSender = it },
                placeholder = "e.g. AIRTEL-S"
            )
            Spacer(Modifier.height(10.dp))
            LabeledField(
                "...and contains (blank = any)", stopContent, { stopContent = it },
                placeholder = "e.g. Digital Purchases: Tns"
            )
            HintText("Fill at least one stop box, or stop manually from the notification. Uses the same regex setting as above.")
        }

        SectionHeading("Forwarding")
        SentinelCard {
            CheckRow("Forward the SMS to another number", forward) { forward = it }
            Spacer(Modifier.height(10.dp))
            LabeledField("Forward to (with country code)", forwardTo, { forwardTo = it }, placeholder = "+919876543210", keyboardType = KeyboardType.Phone)
            Spacer(Modifier.height(10.dp))
            LabeledField("Text added before the forwarded message (optional)", prefix, { prefix = it }, placeholder = "e.g. AIRTEL OTP")
            HintText("The forwarded SMS contains only this prefix plus the original message text.")
        }

        Spacer(Modifier.height(18.dp))
        Button(
            onClick = {
                val r = currentRule()
                if (onSave(r)) {
                    scope.launch {
                        saving = true
                        delay(450)
                        onCancel()
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Save rule") }

        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = { onTest(currentRule()) }, modifier = Modifier.fillMaxWidth()) {
            Text("Test alert now")
        }

        if (!isNew) {
            Spacer(Modifier.height(10.dp))
            TextButton(
                onClick = { showDeleteConfirm = true },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Delete rule", color = MaterialTheme.colorScheme.error) }
        }

        Spacer(Modifier.height(10.dp))
        TextButton(onClick = onCancel, modifier = Modifier.fillMaxWidth()) { Text("Cancel") }
        Spacer(Modifier.height(24.dp))
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Delete this rule?") },
            confirmButton = {
                TextButton(onClick = { showDeleteConfirm = false; onDelete() }) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun LabeledField(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    placeholder: String = "",
    keyboardType: KeyboardType = KeyboardType.Text
) {
    Text(label, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Spacer(Modifier.height(4.dp))
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        placeholder = { Text(placeholder) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun HintText(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(top = 4.dp)
    )
}

@Composable
private fun CheckRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
    ) {
        Checkbox(checked = checked, onCheckedChange = onChange)
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
    }
}
