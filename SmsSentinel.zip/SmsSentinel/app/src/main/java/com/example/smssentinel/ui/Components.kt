package com.example.smssentinel.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

// ───────────────────────────── Background ─────────────────────────────

/** Slowly drifting aurora glows with a faint snowfall on top. */
@Composable
fun SentinelBackground(content: @Composable () -> Unit) {
    val p = Sentinel.colors
    val inf = rememberInfiniteTransition(label = "aurora")
    val a by inf.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(18000, easing = LinearEasing), RepeatMode.Reverse),
        label = "auroraPhase"
    )
    Box(Modifier.fillMaxSize().background(p.bg)) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val k = if (p.isDark) 1f else 0.55f
            drawRect(
                Brush.radialGradient(
                    listOf(p.teal.copy(alpha = 0.24f * k), Color.Transparent),
                    center = Offset(w * (0.10f + 0.30f * a), h * 0.06f), radius = w * 0.95f
                )
            )
            drawRect(
                Brush.radialGradient(
                    listOf(p.violet.copy(alpha = 0.22f * k), Color.Transparent),
                    center = Offset(w * (0.98f - 0.32f * a), h * 0.30f), radius = w * 0.85f
                )
            )
            drawRect(
                Brush.radialGradient(
                    listOf(p.sky.copy(alpha = 0.16f * k), Color.Transparent),
                    center = Offset(w * 0.5f, h * (1.02f - 0.10f * a)), radius = w * 1.05f
                )
            )
        }
        SnowBackground(Modifier.fillMaxSize(), flakeCount = 22)
        content()
    }
}

// ───────────────────────────── Surfaces ─────────────────────────────

@Composable
fun SentinelCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val p = Sentinel.colors
    val shape = RoundedCornerShape(24.dp)
    val sheen = Brush.verticalGradient(
        listOf(if (p.isDark) Color.White.copy(alpha = 0.18f) else Color.White, p.glassBorder)
    )
    var m = modifier.fillMaxWidth().clip(shape).background(p.glass).border(1.dp, sheen, shape)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Column(m.padding(16.dp), content = content)
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier, trailing: String? = null) {
    val p = Sentinel.colors
    Row(
        modifier.fillMaxWidth().padding(top = 28.dp, bottom = 12.dp, start = 4.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text, style = MaterialTheme.typography.titleLarge, color = p.ink, modifier = Modifier.weight(1f))
        if (trailing != null) Chip(trailing, p.inkSoft)
    }
}

@Composable
fun Divider(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().height(1.dp).background(Sentinel.colors.glassBorder))
}

/** Fade + slide-up entrance, staggered by index. */
fun Modifier.staggerIn(index: Int): Modifier = composed {
    val prog = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(index * 70L)
        prog.animateTo(1f, tween(520, easing = FastOutSlowInEasing))
    }
    graphicsLayer {
        alpha = prog.value
        translationY = (1f - prog.value) * 36.dp.toPx()
    }
}

// ───────────────────────────── Controls ─────────────────────────────

/** Gradient pill switch with a springy thumb and a haptic tick. */
@Composable
fun AuroraSwitch(checked: Boolean, onCheckedChange: (Boolean) -> Unit, modifier: Modifier = Modifier) {
    val p = Sentinel.colors
    val haptic = LocalHapticFeedback.current
    val x by animateDpAsState(
        if (checked) 22.dp else 0.dp,
        spring(dampingRatio = 0.62f, stiffness = 520f),
        label = "thumb"
    )
    val c1 by animateColorAsState(if (checked) p.teal else p.inkSoft.copy(alpha = 0.38f), label = "trackA")
    val c2 by animateColorAsState(if (checked) p.sky else p.inkSoft.copy(alpha = 0.26f), label = "trackB")
    Box(
        modifier
            .size(width = 54.dp, height = 32.dp)
            .clip(RoundedCornerShape(50))
            .background(Brush.horizontalGradient(listOf(c1, c2)))
            .toggleable(
                value = checked,
                role = Role.Switch,
                onValueChange = {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onCheckedChange(it)
                }
            )
            .padding(4.dp)
    ) {
        Box(Modifier.offset(x = x).size(24.dp).shadow(3.dp, CircleShape).background(Color.White, CircleShape))
    }
}

/** Full-width labelled switch row. */
@Composable
fun SwitchRow(
    title: String,
    checked: Boolean,
    modifier: Modifier = Modifier,
    hint: String? = null,
    onChange: (Boolean) -> Unit
) {
    val p = Sentinel.colors
    Row(
        modifier.fillMaxWidth().padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, color = p.ink)
            if (hint != null) Text(hint, style = MaterialTheme.typography.labelMedium, color = p.inkSoft)
        }
        AuroraSwitch(checked, onChange)
    }
}

@Composable
fun GradientButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    glyph: Glyph? = null
) {
    val p = Sentinel.colors
    val shape = RoundedCornerShape(20.dp)
    val colors = if (p.isDark) p.aurora else listOf(p.sky, p.violet)
    Box(
        modifier
            .height(56.dp)
            .shadow(14.dp, shape, ambientColor = p.sky, spotColor = p.sky)
            .clip(shape)
            .background(Brush.horizontalGradient(colors))
            .clickable(onClick = onClick)
            .padding(horizontal = 26.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (glyph != null) SentinelIcon(glyph, size = 20.dp, tint = p.onAccent, stroke = 2.2f)
            Text(text, style = MaterialTheme.typography.labelLarge, color = p.onAccent)
        }
    }
}

@Composable
fun GhostButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, glyph: Glyph? = null, tint: Color? = null) {
    val p = Sentinel.colors
    val c = tint ?: p.ink
    val shape = RoundedCornerShape(16.dp)
    Box(
        modifier
            .height(44.dp)
            .clip(shape)
            .border(1.dp, p.inkSoft.copy(alpha = 0.35f), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            if (glyph != null) SentinelIcon(glyph, size = 18.dp, tint = c)
            Text(text, style = MaterialTheme.typography.labelLarge, color = c)
        }
    }
}

@Composable
fun RoundIconButton(glyph: Glyph, onClick: () -> Unit, modifier: Modifier = Modifier, rotate: Float = 0f) {
    val p = Sentinel.colors
    Box(
        modifier.size(44.dp).clip(CircleShape).background(p.glass).border(1.dp, p.glassBorder, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        SentinelIcon(glyph, Modifier.graphicsLayer { rotationZ = rotate }, size = 22.dp, tint = p.ink)
    }
}

@Composable
fun Chip(text: String, tint: Color, modifier: Modifier = Modifier, glyph: Glyph? = null) {
    Row(
        modifier.clip(RoundedCornerShape(50)).background(tint.copy(alpha = 0.14f))
            .padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        if (glyph != null) SentinelIcon(glyph, size = 13.dp, tint = tint, stroke = 2.2f)
        Text(text, style = MaterialTheme.typography.labelMedium, color = tint)
    }
}

@Composable
fun ChoiceChip(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val p = Sentinel.colors
    val shape = RoundedCornerShape(14.dp)
    val bg by animateColorAsState(if (selected) p.sky.copy(alpha = 0.20f) else Color.Transparent, label = "chipBg")
    val bd by animateColorAsState(if (selected) p.sky else p.inkSoft.copy(alpha = 0.30f), label = "chipBd")
    Box(
        modifier.height(40.dp).clip(shape).background(bg).border(1.dp, bd, shape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text, style = MaterialTheme.typography.labelLarge, color = if (selected) p.sky else p.ink)
    }
}

@Composable
fun StatTile(value: String, label: String, tint: Color, modifier: Modifier = Modifier) {
    val p = Sentinel.colors
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier.clip(shape).background(p.glass).border(1.dp, p.glassBorder, shape).padding(vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(value, style = MaterialTheme.typography.headlineSmall, color = tint)
        Text(label, style = MaterialTheme.typography.labelMedium, color = p.inkSoft)
    }
}

@Composable
fun StatusDot(ok: Boolean, modifier: Modifier = Modifier) {
    val p = Sentinel.colors
    val color by animateColorAsState(if (ok) p.teal else p.coral, label = "dot")
    Box(modifier.size(9.dp).clip(CircleShape).background(color))
}

/** Rounded-square icon badge with a soft tinted gradient. */
@Composable
fun IconBadge(glyph: Glyph, tint: Color, modifier: Modifier = Modifier, size: Dp = 46.dp, second: Color = tint) {
    val shape = RoundedCornerShape(size * 0.32f)
    Box(
        modifier.size(size).clip(shape)
            .background(Brush.linearGradient(listOf(tint.copy(alpha = 0.26f), second.copy(alpha = 0.10f))))
            .border(1.dp, tint.copy(alpha = 0.38f), shape),
        contentAlignment = Alignment.Center
    ) {
        SentinelIcon(glyph, size = size * 0.5f, tint = tint)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ChipFlow(content: @Composable () -> Unit) {
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) { content() }
}

@Composable
fun VSpace(h: Int) = Spacer(Modifier.height(h.dp))

@Composable
fun HSpace(w: Int) = Spacer(Modifier.width(w.dp))

// ───────────────────────────── Icons ─────────────────────────────

enum class Glyph { Bell, Alarm, Repeat, Send, Shield, Check, Warning, Plus, Chevron, Battery, Sim, Search, Bolt }

private fun glyphPath(g: Glyph): Path = Path().apply {
    when (g) {
        Glyph.Bell -> {
            moveTo(5f, 17f); cubicTo(7f, 15f, 7f, 13f, 7f, 10f)
            cubicTo(7f, 6.5f, 9f, 5f, 12f, 5f); cubicTo(15f, 5f, 17f, 6.5f, 17f, 10f)
            cubicTo(17f, 13f, 17f, 15f, 19f, 17f); close()
            moveTo(10f, 20f); cubicTo(11f, 21.4f, 13f, 21.4f, 14f, 20f)
        }
        Glyph.Alarm -> {
            addOval(Rect(5f, 6f, 19f, 20f))
            moveTo(12f, 9.5f); lineTo(12f, 13f); lineTo(14.5f, 14.8f)
            moveTo(3.5f, 7f); lineTo(6.5f, 4f); moveTo(20.5f, 7f); lineTo(17.5f, 4f)
        }
        Glyph.Repeat -> {
            moveTo(5f, 10f); cubicTo(5f, 7f, 7f, 5.5f, 10f, 5.5f); lineTo(18f, 5.5f)
            moveTo(15f, 3f); lineTo(18f, 5.5f); lineTo(15f, 8f)
            moveTo(19f, 14f); cubicTo(19f, 17f, 17f, 18.5f, 14f, 18.5f); lineTo(6f, 18.5f)
            moveTo(9f, 16f); lineTo(6f, 18.5f); lineTo(9f, 21f)
        }
        Glyph.Send -> {
            moveTo(4f, 12f); lineTo(20f, 4f); lineTo(15f, 20f); lineTo(12f, 13f); close()
            moveTo(20f, 4f); lineTo(12f, 13f)
        }
        Glyph.Shield -> {
            moveTo(12f, 3f); lineTo(19f, 6f); lineTo(19f, 12f)
            cubicTo(19f, 16.5f, 16f, 19.5f, 12f, 21f); cubicTo(8f, 19.5f, 5f, 16.5f, 5f, 12f)
            lineTo(5f, 6f); close()
        }
        Glyph.Check -> { moveTo(5f, 12.5f); lineTo(10f, 17.5f); lineTo(19f, 7f) }
        Glyph.Warning -> {
            moveTo(12f, 4f); lineTo(21f, 19f); lineTo(3f, 19f); close()
            moveTo(12f, 9.5f); lineTo(12f, 13.5f); moveTo(12f, 16.3f); lineTo(12f, 16.4f)
        }
        Glyph.Plus -> { moveTo(12f, 5f); lineTo(12f, 19f); moveTo(5f, 12f); lineTo(19f, 12f) }
        Glyph.Chevron -> { moveTo(9f, 6f); lineTo(15f, 12f); lineTo(9f, 18f) }
        Glyph.Battery -> {
            addRoundRect(RoundRect(3f, 8f, 19f, 16f, 2f, 2f))
            moveTo(21f, 11f); lineTo(21f, 13f)
        }
        Glyph.Sim -> {
            moveTo(8f, 3f); lineTo(15f, 3f); lineTo(19f, 7f); lineTo(19f, 19f)
            cubicTo(19f, 20.2f, 18.2f, 21f, 17f, 21f); lineTo(8f, 21f)
            cubicTo(6.8f, 21f, 6f, 20.2f, 6f, 19f); lineTo(6f, 5f)
            cubicTo(6f, 3.8f, 6.8f, 3f, 8f, 3f); close()
            addRoundRect(RoundRect(9f, 12f, 16f, 18f, 1f, 1f))
        }
        Glyph.Search -> {
            addOval(Rect(4f, 4f, 16f, 16f)); moveTo(14.5f, 14.5f); lineTo(20f, 20f)
        }
        Glyph.Bolt -> {
            moveTo(13f, 3f); lineTo(5f, 13.5f); lineTo(11.5f, 13.5f); lineTo(10.5f, 21f)
            lineTo(19f, 10f); lineTo(12.5f, 10f); close()
        }
    }
}

@Composable
fun SentinelIcon(
    glyph: Glyph,
    modifier: Modifier = Modifier,
    size: Dp = 22.dp,
    tint: Color = LocalContentColor.current,
    stroke: Float = 1.9f
) {
    val path = remember(glyph) { glyphPath(glyph) }
    Canvas(modifier.size(size)) {
        val s = this.size.minDimension / 24f
        scale(s, pivot = Offset.Zero) {
            drawPath(path, tint, style = Stroke(width = stroke, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
    }
}
