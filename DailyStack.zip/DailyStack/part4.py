from part0 import *

bedrock = T("bedrock", "🧠", "Amazon Bedrock: calling foundation models",
 "Amazon Bedrock gives API access to foundation models from several providers. You call models from code with an IAM role, and you pay mostly per input and output token.",
 "Adding AI features to your own apps is now a normal AWS task. The risks are runaway token costs, over-broad permissions and leaking user data.",
 ["Call models with the Converse API (a consistent interface across models) or InvokeModel, using a role with bedrock:InvokeModel on specific models.",
  "Model availability, quotas and prices vary by Region and model. Check the console and pricing page.",
  "Cap maxTokens, rate-limit users and cache repeated answers to control cost.",
  "Don't log or send user data you don't need. Use Guardrails to filter harmful content and sensitive data."],
 ["AI grants bedrock:* on all resources.", "AI omits token limits and per-user limits.", "AI logs full prompts containing user data."],
 V(fcc="ML, AI and Big Data: Generative AI chapter (overview only).", uq="amazon bedrock", yq="Amazon Bedrock Converse API Lambda tutorial"),
 [("How are most Bedrock on-demand models billed?", ["Per input and output token", "Per instance hour", "Per bucket", "Per route"], 0, "Cost scales with tokens."),
  ("What gives a Lambda permission to call Bedrock?", ["An execution role with bedrock:InvokeModel", "A security group", "A tag", "A route table"], 0, "Permissions come from the role."),
  ("Which setting limits response length and cost?", ["maxTokens", "Region", "Log group", "Subnet"], 0, "It caps output tokens.")],
 ("Permission for the summarizer", r'''
{
  "Effect": "Allow",
  "Action": "bedrock:*",
  "Resource": "*"
}''', 2, "bedrock:* allows every Bedrock action. Limit to bedrock:InvokeModel on the specific model ARN."),
 ("Summarize text with a model from Lambda.", r'''
resp = bedrock.converse(
    modelId=MODEL_ID,
    messages=[{"role": "user", "content": [{"text": text}]}],
    inferenceConfig={"maxTokens": 500},
)''', "correct", "It uses Converse and caps output tokens. Also limit input length and rate-limit callers."),
 ("Add a summarize feature to your API.", [
  ("Call Bedrock with whatever text the user sends.", False, "Unbounded cost and abuse risk."),
  ("Write a Python Lambda that calls Bedrock Converse to summarize input text, caps maxTokens at 500 and input length at 8,000 characters, uses a role limited to bedrock:InvokeModel on one model, and logs token usage but not the user's text.", True, "Limits cost, permissions and data exposure."),
  ("Add AI to my app.", False, "Too vague.")]))

rag = T("rag", "📚", "RAG on AWS: Knowledge Bases & vector search",
 "Retrieval-augmented generation (RAG) finds the passages of your documents relevant to a question and gives them to a model to answer. Bedrock Knowledge Bases manage ingestion (chunk, embed, index) and retrieval.",
 "Chat with your own documents is the most requested AI feature. The hard parts are access control, cost and answer quality, not the API call.",
 ["Documents are split into chunks, converted to embeddings and stored in a vector store. Retrieval finds similar chunks by meaning.",
  "Common vector stores include OpenSearch Serverless and Aurora PostgreSQL with pgvector. Some have minimum hourly charges, so check pricing.",
  "Enforce per-user access: filter retrieval by permissions, and don't index secrets or data users shouldn't see.",
  "Return citations, and evaluate answers on real questions before launch."],
 ["AI indexes everything and ignores who may see what.", "AI picks a vector store without noting its fixed cost.", "AI skips citations and evaluation."],
 V(uq="amazon bedrock knowledge bases rag", yq="Amazon Bedrock Knowledge Bases RAG tutorial"),
 [("What does a vector store do in RAG?", ["Finds chunks similar in meaning to the question", "Stores IAM roles", "Hosts websites", "Runs containers"], 0, "Embeddings enable similarity search."),
  ("What is the key security risk of RAG over company documents?", ["Showing users content they aren't allowed to see", "Slow DNS", "Too many tags", "Wrong Region name"], 0, "Retrieval must respect permissions."),
  ("Why return citations?", ["Users can verify answers", "They reduce cost to zero", "They replace IAM", "They speed up queries"], 0, "Sources enable checking and trust.")],
 ("Chat over company documents", r'''
docs = search_all_documents(query)          # every user's documents
answer = llm(f"Context: {docs}\nQ: {query}")''', 0, "Retrieval ignores who is asking, so users can see content they shouldn't. Filter by the caller's permissions."),
 ("Answer questions from our docs.", r'''
response = agent_rt.retrieve_and_generate(
    input={"text": question},
    retrieveAndGenerateConfiguration={"type": "KNOWLEDGE_BASE",
        "knowledgeBaseConfiguration": {"knowledgeBaseId": KB_ID, "modelArn": MODEL_ARN}},
)''', "subtle", "It works, but it queries the whole knowledge base with no per-user filtering, and nothing here checks answer quality or shows citations to the user."),
 ("Build a document Q&A feature.", [
  ("Index all company files and let anyone ask.", False, "Ignores access control."),
  ("Design a RAG system on AWS for HR policy PDFs: ingestion, Bedrock Knowledge Base, vector store choice with fixed-cost warnings, per-user access filtering, citations in answers, and a small evaluation set of real questions.", True, "Covers security, cost and quality."),
  ("Make a chatbot for our documents.", False, "Too vague.")]))

agents = T("agents", "🤝", "Agents & tool use on AWS, with guardrails",
 "An agent lets a model decide which tools to call, such as APIs or Lambda functions, in a loop until a task is done. Bedrock Agents and Amazon Bedrock AgentCore are AWS options, and product names change quickly, so check current docs.",
 "Agents can take actions, so mistakes cost more than a wrong answer. The skill is limiting what tools can do.",
 ["Give each tool the narrowest possible permissions through its own role.",
  "Require human approval for destructive or costly actions, and set spending limits.",
  "Limit loop counts and tokens, and log every tool call.",
  "Use Guardrails and input validation, and treat model output as untrusted input to your tools."],
 ["AI gives an agent a tool that can run any AWS command.", "AI skips approval for refunds, deletes or purchases.", "AI doesn't limit iterations or cost."],
 V(uq="amazon bedrock agents", yq="Amazon Bedrock Agents AgentCore tutorial tools Lambda"),
 [("What should an agent tool's permissions be?", ["As narrow as possible", "Administrator", "Read-write on everything", "None"], 0, "Least privilege applies to tools too."),
  ("Which actions should need human approval?", ["Deletes, refunds and purchases", "Reading a public FAQ", "Formatting text", "Counting tokens"], 0, "High-impact actions need a human check."),
  ("Model output passed to a tool should be treated as...", ["Untrusted input", "Always safe", "Encrypted", "Verified"], 0, "Validate it like any user input.")],
 ("Tool list for a support agent", r'''
tools = [{"name": "run_aws_cli", "description": "Run any AWS CLI command", "handler": run_cli}]''', 0, "A tool that can run any command gives the model full control of your account. Expose narrow, specific actions."),
 ("Give my support agent a refund tool.", r'''
def refund(order_id, amount):
    if amount > 50:
        return {"status": "needs_human_approval"}
    return payments.refund(order_id, amount)''', "correct", "A threshold sends larger refunds to a human. Also validate order ownership and log every call."),
 ("Let an agent handle support tasks.", [
  ("Give the agent a tool that can call any internal API.", False, "Too much power."),
  ("Design a support agent with three tools: lookup_order, refund (needs human approval over 50), and send_email (templates only). Each tool has its own least-privilege role, an iteration limit of 5, token budget and full call logging.", True, "Narrow tools, approvals and limits."),
  ("Make an agent.", False, "Too vague.")]))

aitools = T("aitools", "🧰", "AI dev tools for AWS: Amazon Q, Kiro & MCP servers",
 "AI assistants can write infrastructure, explain errors and, with command-line access or MCP servers, act directly on your AWS account. Examples include Amazon Q Developer, Kiro and AWS-provided MCP servers; names and features change quickly.",
 "These tools are how you get things done fast. They are also software acting with your credentials, so how you configure them matters.",
 ["Give assistants a sandbox or read-only profile first, and expand access only when needed.",
  "Review every command that changes something. Prefer tools that show a plan before executing.",
  "Use documentation-grounded tools (such as AWS documentation MCP servers) to reduce outdated answers.",
  "Keep secrets out of prompts and project files the tool can read."],
 ["AI tools configured with production admin profiles.", "Auto-approve modes that run commands without review.", "Secrets left in files the assistant reads."],
 V(uq="amazon q developer", yq="Amazon Q Developer Kiro AWS MCP server tutorial"),
 [("Which credentials should you start an AI assistant with?", ["Sandbox or read-only", "Production admin", "Root user", "Shared team keys"], 0, "Start low and expand deliberately."),
  ("Why use a documentation-grounded tool?", ["Fewer outdated or invented answers", "It is free of charge always", "It replaces IAM", "It deletes logs"], 0, "Grounding in current docs improves accuracy."),
  ("What should you do with an auto-approve mode?", ["Avoid it for anything that changes resources", "Always enable it", "Use it in production", "Give it root"], 0, "Human review is the safety net.")],
 ("MCP server configuration", r'''
{
  "env": { "AWS_PROFILE": "prod-admin" }
}''', 1, "The assistant would act with production admin permissions. Use a sandbox or read-only profile."),
 ("Let my AI assistant inspect my AWS account.", r'''
export AWS_PROFILE=sandbox-readonly   # ReadOnlyAccess, budget alarm on''', "correct", "Read-only, in a sandbox, with a budget alarm. A good starting point."),
 ("Set up an AI assistant for AWS safely.", [
  ("Give the assistant my admin profile so it can do anything.", False, "Maximum risk."),
  ("Create a read-only IAM role in a sandbox account for my AI assistant, with a budget alarm, and show how to add a separate, time-limited role with write access only for specific tasks. List the settings that keep human approval on.", True, "Starts read-only and adds access deliberately."),
  ("Connect my AI to AWS.", False, "No safety constraints.")]))

capstone = T("capstone", "🏁", "Capstone: ship a serverless AI app with AI assistance",
 "You combine everything: ask AI to build a small serverless app that summarizes documents with Bedrock, review its output, deploy it from CI, and operate it safely.",
 "This is the real job in the AI era: specify clearly, review rigorously, deploy safely and keep costs and security in check.",
 ["Architecture: S3 upload, Lambda, Bedrock, DynamoDB for results, HTTP API with Cognito, all defined in CDK or SAM.",
  "Process: specify, generate, review the diff with the checklist, deploy to a sandbox, test, add alarms and a budget.",
  "CI/CD: GitHub Actions with OIDC and a scoped deploy role. No stored keys.",
  "Cleanup: cdk destroy or sam delete when finished, and confirm in Cost Explorer."],
 ["AI skips auth, limits or cleanup in a big generated stack.", "Large diffs hide small dangerous changes.", "Nobody tests failure paths."],
 V(uq="aws serverless project", yq="serverless AI app AWS Lambda Bedrock S3 tutorial"),
 [("What is the first thing to do with a large AI-generated stack?", ["Read the diff using the review checklist", "Deploy to production", "Delete tests", "Add admin access"], 0, "Review before deploy."),
  ("How should the pipeline authenticate to AWS?", ["GitHub OIDC with a scoped role", "Long-lived admin keys", "The root password", "Shared SSH keys"], 0, "Short-lived credentials with narrow permissions."),
  ("What ends the project cleanly?", ["Destroy the stack and confirm costs stop", "Close the laptop", "Rename the stack", "Disable MFA"], 0, "Cleanup stops charges.")],
 ("Result table", r'''
const table = new dynamodb.Table(this, "Results", {
  partitionKey: { name: "docId", type: dynamodb.AttributeType.STRING },
  billingMode: dynamodb.BillingMode.PROVISIONED,
  readCapacity: 500, writeCapacity: 500,
});''', 2, "500 provisioned units each is far more than a small app needs and bills continuously. Use on-demand billing."),
 ("Review the generated app.", r'''
[+] Lambda summarize   role: bedrock:* on *
[+] HTTP API           authorizer: none
[+] S3 bucket uploads  public read''', "insecure", "Wildcard Bedrock permissions, an unauthenticated API and a public bucket. Fix all three before deploying."),
 ("Build the capstone with an AI assistant.", [
  ("Build and deploy a document summarizer app.", False, "No constraints or review step."),
  ("Write CDK (TypeScript) for a document summarizer: private S3 uploads, a Lambda calling Bedrock with maxTokens 500, a DynamoDB on-demand results table, an HTTP API with a Cognito JWT authorizer, throttling, alarms, tags, and a budget. Use grant methods, give me the cdk diff review checklist, a GitHub Actions OIDC deploy, and a destroy command.", True, "Specific, secure, reviewable and with cleanup."),
  ("Make me an AI app on AWS.", False, "Too vague.")]))

PART4 = [bedrock, rag, agents, aitools, capstone]
