package com.dailystack.learn.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dailystack.learn.*

private val goals = listOf(
    "🤖" to "Learn AI & Machine Learning", "☁️" to "Become a Cloud Engineer", "♾️" to "Improve DevOps skills",
    "🌐" to "Learn Networking & Linux", "🧭" to "Explore all tracks"
)
private val levels = listOf(
    Triple("Beginner", "I'm new to all this", "🟢"),
    Triple("Intermediate", "I have some experience", "🟡"),
    Triple("Advanced", "I already work with these tools", "🟣")
)

@Composable
fun OnboardingScreen(vm: AppViewModel) {
    val p by vm.progress.collectAsState()
    var goal by remember { mutableStateOf(p.goal) }
    var level by remember { mutableStateOf(p.level) }
    var name by remember { mutableStateOf(if (p.name == "Learner") "" else p.name) }
    val step = vm.onboardStep

    Column(Modifier.fillMaxSize().padding(24.dp)) {
        AnimatedContent(
            targetState = step, modifier = Modifier.weight(1f),
            transitionSpec = { (slideInHorizontally(tween(350)) { it / 4 } + fadeIn(tween(350))) togetherWith fadeOut(tween(150)) },
            label = "onb"
        ) { s ->
            when (s) {
                0 -> Column(
                    Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(18.dp, Alignment.CenterVertically)
                ) {
                    Penguin(220.dp)
                    Text("Your next big skill\nstarts here.", color = TextHi, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center, lineHeight = 38.sp)
                    Text("Short daily lessons, hands-on practice and the skills to direct AI tools with confidence.", color = TextLo, textAlign = TextAlign.Center)
                }
                1 -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("What's your goal?", color = TextHi, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Text("Choose one to get a personalized learning path.", color = TextLo)
                    goals.forEach { (emoji, label) -> ChoiceRow(emoji, label, null, goal == label) { goal = label } }
                }
                2 -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Your current level?", color = TextHi, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Text("This helps us recommend the right lessons.", color = TextLo)
                    levels.forEach { (l, sub, emoji) -> ChoiceRow(emoji, l, sub, level == l) { level = l } }
                }
                else -> Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterVertically), horizontalAlignment = Alignment.CenterHorizontally) {
                    Penguin(150.dp)
                    Text("What should we call you?", color = TextHi, fontSize = 26.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                    OutlinedTextField(name, { name = it.take(24) }, label = { Text("Your name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 14.dp), horizontalArrangement = Arrangement.Center) {
            repeat(4) { i ->
                Box(Modifier.padding(3.dp).size(if (i == step) 22.dp else 8.dp, 8.dp).clip(CircleShape).background(if (i == step) Accent else Surf2))
            }
        }
        val canGo = when (step) { 1 -> goal.isNotBlank(); else -> true }
        BigButton(
            when (step) { 0 -> "Get started  →"; 3 -> "Start learning  →"; else -> "Continue  →" },
            {
                if (step < 3) vm.onboardStep = step + 1
                else { vm.setProfile(name, goal, level); vm.finishOnboarding() }
            },
            enabled = canGo
        )
        if (step == 0) Text(
            "Skip", color = TextLo, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().pressable { vm.finishOnboarding() }.padding(12.dp)
        )
    }
}

@Composable
private fun ChoiceRow(emoji: String, title: String, sub: String?, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Row(
        Modifier.fillMaxWidth().pressable(onClick = onClick).clip(shape)
            .background(if (selected) Surf2 else Color_White)
            .border(2.dp, if (selected) Accent else Surf2, shape).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(emoji, fontSize = 26.sp)
        Column(Modifier.weight(1f)) {
            Text(title, color = TextHi, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
            if (sub != null) Text(sub, color = TextLo, fontSize = 13.sp)
        }
        Text(if (selected) "✔" else "○", color = if (selected) Accent else TextLo, fontSize = 20.sp)
    }
}

private val Color_White = androidx.compose.ui.graphics.Color.White
