package com.dailystack.learn

import kotlinx.serialization.Serializable

@Serializable data class Course(
    val id: String, val title: String, val emoji: String = "📘", val description: String = "",
    val level: String = "Beginner", val builtin: Boolean = true, val weeks: List<Week>
)
@Serializable data class Week(val id: Int, val title: String, val topics: List<Topic> = emptyList())
@Serializable data class Topic(
    val id: String, val title: String, val emoji: String = "📘",
    val what: String = "", val why: String = "",
    val core: List<String> = emptyList(), val aiPitfalls: List<String> = emptyList(),
    val videos: List<Video> = emptyList(),
    val materials: List<Material> = emptyList(),
    val checks: List<Question> = emptyList(),
    val bugs: List<BugHunt> = emptyList(),
    val aiReviews: List<AiReview> = emptyList(),
    val prompts: List<PromptChallenge> = emptyList()
)
@Serializable data class Material(val title: String, val url: String, val kind: String = "doc", val note: String = "")
@Serializable data class Video(
    val title: String, val kind: String = "youtube", val id: String = "", val url: String = "",
    val startSec: Int = 0, val endSec: Int = 0, val note: String = ""
)
@Serializable data class Question(val id: String, val q: String, val options: List<String>, val answer: Int, val why: String)
@Serializable data class BugHunt(val id: String, val title: String, val code: List<String>, val buggyLine: Int, val explanation: String)
@Serializable data class AiReview(val id: String, val prompt: String, val code: List<String>, val verdict: String, val explanation: String)
@Serializable data class PromptChallenge(val id: String, val goal: String, val options: List<PromptOption>)
@Serializable data class PromptOption(val text: String, val good: Boolean, val feedback: String)

@Serializable data class SrsCard(val box: Int = 0, val due: Long = 0)
@Serializable data class Reward(val name: String, val cost: Int, val emoji: String = "🎁")

@Serializable data class Progress(
    val totalXp: Int = 0, val spent: Int = 0,
    val streak: Int = 0, val best: Int = 0, val freezes: Int = 1, val lastActiveDay: Long = -1,
    val xpToday: Int = 0, val xpDay: Long = -1,
    val doneTopics: List<String> = emptyList(),
    val completedOn: Map<String, Long> = emptyMap(),
    val cards: Map<String, SrsCard> = emptyMap(),
    val ratings: Map<String, Int> = emptyMap(),
    val eyeBreaks: Int = 0, val eyeSkips: Int = 0,
    val rewards: List<Reward> = listOf(
        Reward("Coffee break", 500, "☕"),
        Reward("Movie night", 1500, "🎬"),
        Reward("Gift voucher (you buy it)", 3000, "🎁")
    ),
    val redeemed: List<String> = emptyList(),
    val reminderHour: Int = 20, val eyeMinutes: Int = 20,
    val name: String = "Learner", val goal: String = "", val level: String = "Beginner",
    val onboarded: Boolean = false, val activeCourse: String = "aws",
    val history: Map<String, Int> = emptyMap(), val minutes: Int = 0
)

enum class Screen { Onboarding, Main, Session, Hub, Rewards, Progress, Achievements, Certificates, Settings, AddCourse }
enum class Tab { Home, Learn, Practice, Profile }

sealed interface Step {
    data class Review(val qs: List<Question>) : Step
    data class Check(val qs: List<Question>) : Step
    data object Learn : Step
    data object Watch : Step
    data class Bug(val b: BugHunt) : Step
    data class AiRev(val r: AiReview) : Step
    data class Prompt(val p: PromptChallenge) : Step
    data object Done : Step
}

data class Session(val topic: Topic, val steps: List<Step>, val idx: Int = 0, val completed: Boolean = false)
data class Badge(val emoji: String, val title: String, val desc: String, val unlocked: Boolean)
data class DayBar(val label: String, val xp: Int, val today: Boolean)
