package com.dailystack.learn.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dailystack.learn.*

@Composable
fun PracticeScreen(vm: AppViewModel) {
    val p by vm.progress.collectAsState()   // recompose when progress changes
    val counts = vm.poolCounts()
    val items = listOf(
        Triple("quiz", "📝" to Color(0xFFDDF7EC), "Quick Quiz") to "Test your knowledge: ${counts[0]} questions available",
        Triple("lab", "🐞" to Color(0xFFE5E4FF), "Code Lab") to "Spot the bug in real code: ${counts[1]} exercises",
        Triple("scenario", "🎯" to Color(0xFFFFF0D6), "Scenario Challenge") to "Pick the best prompt for real tasks: ${counts[2]} scenarios",
        Triple("exam", "🤖" to Color(0xFFFFE3E8), "Exam Style Questions") to "Is the AI's output right? ${counts[3]} reviews"
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Practice", color = TextHi, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("Practice what you've unlocked in ${vm.activeCourse().title}. Finish a day first to add more.", color = TextLo, fontSize = 13.sp)
        items.forEachIndexed { i, (head, sub) ->
            val (kind, iconBg, title) = head
            Reveal(i * 60) {
                Panel(Modifier.pressable { vm.startPractice(kind) }) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        Box(Modifier.size(52.dp).clip(RoundedCornerShape(16.dp)).background(iconBg.second), contentAlignment = Alignment.Center) {
                            Text(iconBg.first, fontSize = 26.sp)
                        }
                        Column(Modifier.weight(1f)) {
                            Text(title, color = TextHi, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text(sub, color = TextLo, fontSize = 13.sp)
                        }
                        Text("›", color = TextLo, fontSize = 26.sp)
                    }
                }
            }
        }
    }
}
