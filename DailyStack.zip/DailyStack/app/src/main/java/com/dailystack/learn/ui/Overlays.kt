package com.dailystack.learn.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dailystack.learn.*
import kotlinx.coroutines.delay

@Composable
fun EyeBreakOverlay(vm: AppViewModel) {
    AnimatedVisibility(
        visible = vm.eyeBreak,
        enter = fadeIn(tween(400)) + scaleIn(initialScale = 0.9f, animationSpec = tween(400)),
        exit = fadeOut(tween(300))
    ) {
        var left by remember { mutableIntStateOf(20) }
        val haptic = LocalHapticFeedback.current
        LaunchedEffect(Unit) {
            while (left > 0) { delay(1000); left-- }
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            vm.finishEyeBreak(true)
        }
        Box(
            Modifier.fillMaxSize().background(Color(0xF2080A10))
                .pointerInput(Unit) { detectTapGestures(onLongPress = { vm.finishEyeBreak(false) }) },
            contentAlignment = Alignment.Center
        ) {
            Column(
                Modifier.padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                Text("👀", fontSize = 56.sp)
                Text(
                    "Look at something 20 meters away",
                    color = TextHi, fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center
                )
                Ring(left / 20f, 170.dp, 10.dp, Teal) {
                    Text("$left", color = TextHi, fontSize = 46.sp, fontWeight = FontWeight.Bold)
                }
                Text(
                    "Let your eyes relax for 20 seconds.\nPress and hold anywhere to skip.",
                    color = TextLo, textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
fun SettingsDialog(p: Progress, vm: AppViewModel, onClose: () -> Unit) {
    var hour by remember { mutableFloatStateOf(p.reminderHour.toFloat()) }
    var eye by remember { mutableFloatStateOf(p.eyeMinutes.toFloat()) }
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = Surf,
        title = { Text("Settings", color = TextHi) },
        text = {
            Column {
                Text("Daily reminder: ${hour.toInt()}:00", color = TextHi)
                Slider(hour, { hour = it }, valueRange = 6f..23f, steps = 16)
                Spacer(Modifier.height(8.dp))
                Text("Eye break every ${eye.toInt()} min", color = TextHi)
                Slider(eye, { eye = it }, valueRange = 10f..40f, steps = 5)
            }
        },
        confirmButton = { TextButton({ vm.saveSettings(hour.toInt(), eye.toInt()); onClose() }) { Text("Save") } },
        dismissButton = { TextButton(onClose) { Text("Cancel") } }
    )
}
