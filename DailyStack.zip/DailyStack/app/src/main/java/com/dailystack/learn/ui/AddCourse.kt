package com.dailystack.learn.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dailystack.learn.*

@Composable
fun AddCourseScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    var json by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    var qTitle by remember { mutableStateOf("") }
    var qLines by remember { mutableStateOf("") }
    var qErr by remember { mutableStateOf<String?>(null) }
    var confirm by remember { mutableStateOf<Course?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val text = runCatching { ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } }.getOrNull()
            err = if (text.isNullOrBlank()) "Couldn't read that file." else vm.importCourse(text)
            if (err == null) { vm.screen = Screen.Main; vm.tab = Tab.Learn }
        }
    }

    SubScreen("Courses", vm) {
        Text("Add any topic you want to learn. Each day shows its videos, links and quiz, and unlocks one calendar day at a time.", color = TextLo, fontSize = 13.sp)

        Panel {
            Label("1 · Ask your AI to build one")
            Text("Copy this prompt, fill in the [brackets], send it to your AI assistant, then paste its JSON reply in step 2.", color = TextHi, fontSize = 14.sp)
            Chip("📋 Copy the prompt", Modifier.fillMaxWidth(), primary = true) {
                copyText(ctx, CourseImport.AI_PROMPT); vm.toast = "📋 Prompt copied"
            }
        }
        Panel {
            Label("2 · Paste the course JSON")
            OutlinedTextField(
                json, { json = it; err = null }, label = { Text("Course JSON") },
                minLines = 5, maxLines = 10, modifier = Modifier.fillMaxWidth()
            )
            err?.let { Text(it, color = Bad, fontSize = 13.sp) }
            BigButton("Add course", {
                err = vm.importCourse(json)
                if (err == null) { json = ""; vm.screen = Screen.Main; vm.tab = Tab.Learn }
            }, enabled = json.isNotBlank())
        }
        Panel {
            Label("3 · Import a file")
            Text("Pick a .json course file from your phone (for example one a friend or your AI saved).", color = TextHi, fontSize = 14.sp)
            Chip("📂 Choose file", Modifier.fillMaxWidth()) { picker.launch(arrayOf("application/json", "text/plain", "*/*")) }
        }
        Panel {
            Label("4 · Quick add from a list")
            Text("One line per day:  Day title | video link | document link  (the links are optional).", color = TextHi, fontSize = 14.sp)
            OutlinedTextField(qTitle, { qTitle = it; qErr = null }, label = { Text("Course title") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(
                qLines, { qLines = it; qErr = null }, label = { Text("Days") },
                placeholder = { Text("Intro to Terraform | https://www.youtube.com/watch?v=... | https://developer.hashicorp.com/terraform") },
                minLines = 4, maxLines = 10, modifier = Modifier.fillMaxWidth()
            )
            qErr?.let { Text(it, color = Bad, fontSize = 13.sp) }
            BigButton("Create course", {
                qErr = vm.importQuickList(qTitle, qLines)
                if (qErr == null) { qTitle = ""; qLines = ""; vm.screen = Screen.Main; vm.tab = Tab.Learn }
            }, enabled = qTitle.isNotBlank() && qLines.isNotBlank())
        }

        SectionTitle("Your courses")
        vm.courses.forEach { c ->
            val total = vm.courseTopics(c).size
            Panel {
                Text("${c.emoji} ${c.title}", color = TextHi, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text("$total days · ${vm.courseDoneCount(c)} done · ${if (c.builtin) "Built in" else "Added by you"}", color = TextLo, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Chip("Open", Modifier.weight(1f), primary = true) { vm.setActiveCourse(c.id); vm.screen = Screen.Main; vm.tab = Tab.Learn }
                    if (!c.builtin) Chip("Remove", Modifier.weight(1f)) { confirm = c }
                }
            }
        }
    }

    confirm?.let { c ->
        AlertDialog(
            onDismissRequest = { confirm = null }, containerColor = Surf,
            title = { Text("Remove \"${c.title}\"?", color = TextHi) },
            text = { Text("The course is deleted from this device. Your XP and streak stay.", color = TextHi) },
            confirmButton = { TextButton({ vm.removeCourse(c.id); confirm = null }) { Text("Remove", color = Bad) } },
            dismissButton = { TextButton({ confirm = null }) { Text("Cancel") } }
        )
    }
}
