package com.dailystack.learn.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dailystack.learn.*

internal fun copyText(ctx: Context, text: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("text", text))
}

private fun materialIcon(kind: String) = when (kind) {
    "doc" -> "📄"; "lab" -> "🧪"; "community" -> "💬"; "blog" -> "📰"; else -> "🔗"
}

@Composable
internal fun MaterialCard(m: Material) {
    val ctx = LocalContext.current
    Panel {
        Text("${materialIcon(m.kind)} ${m.title}", color = TextHi, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
        if (m.note.isNotBlank()) Text(m.note, color = TextLo, fontSize = 13.sp)
        Chip("↗ Open", Modifier.fillMaxWidth()) { openExternal(ctx, m.url) }
    }
}

@Composable
internal fun NotesPanels(t: Topic) {
    Panel { Label("What it is"); Text(t.what, color = TextHi) }
    Panel { Label("Why it matters when AI writes the code"); Text(t.why, color = TextHi) }
    if (t.core.isNotEmpty()) Panel { Label("The essentials"); t.core.forEach { Text("• $it", color = TextHi) } }
    if (t.aiPitfalls.isNotEmpty()) Panel(color = Color(0x33FFB020)) {
        Label("Where AI usually goes wrong"); t.aiPitfalls.forEach { Text("• $it", color = TextHi) }
    }
}

/** One page per day: everything for that topic, always available once the day is unlocked. */
@Composable
fun HubScreen(vm: AppViewModel) {
    val p by vm.progress.collectAsState()
    val t = vm.hubTopic()
    if (t == null) { LaunchedEffect(Unit) { vm.screen = Screen.Main }; return }
    val ctx = LocalContext.current
    val done = t.id in p.doneTopics
    val day = vm.dayOf(t)
    val todayDone = vm.isTodayDone() && t.id == vm.todayTopic()?.id
    var playing by remember(t.id) { mutableStateOf<Int?>(null) }
    val bestPrompt = t.prompts.flatMap { it.options }.firstOrNull { it.good }?.text

    Column(Modifier.fillMaxSize()) {
        TopBar("Lesson overview") { vm.screen = Screen.Main }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // banner
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFFE5E3FF), Color(0xFFF3F1FF)))).padding(20.dp)
            ) {
                Column(Modifier.fillMaxWidth(0.68f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Label("Week ${vm.weekOf(t)} · Day $day of ${vm.totalDays()}")
                    Text("${t.emoji} ${t.title}", color = TextHi, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Pill("⏱ 60 min", Color.White)
                        Pill("🎬 ${t.videos.size}", Color.White)
                    }
                    Pill(vm.activeCourse().level, Color.White)
                }
                Penguin(104.dp, Modifier.align(Alignment.CenterEnd))
            }

            Panel(color = if (done) Good.copy(alpha = .14f) else Surf) {
                Text(
                    if (done) "✅ Completed. Everything below stays available for review."
                    else "▶️ Today's topic. Work through it at your own pace.",
                    color = TextHi
                )
                if (todayDone) Text("Day ${day + 1} unlocks tomorrow.", color = TextLo, fontSize = 13.sp)
            }

            if (t.core.isNotEmpty()) Panel {
                Text("What you'll learn", color = TextHi, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                t.core.take(4).forEach { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Text("✔", color = Good, fontWeight = FontWeight.Bold); Text(it, color = TextHi, fontSize = 14.sp) } }
            }
            Panel {
                Text("Lesson content", color = TextHi, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                listOf("Quick check-yourself quiz", "Notes and ${t.videos.size} video option${if (t.videos.size == 1) "" else "s"}", "Spot-the-bug, AI review and prompt practice").forEachIndexed { i, s ->
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(Modifier.size(26.dp).clip(androidx.compose.foundation.shape.CircleShape).background(Surf2), contentAlignment = Alignment.Center) {
                            Text("${i + 1}", color = Accent, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Text(s, color = TextHi, fontSize = 14.sp)
                    }
                }
            }
            BigButton(if (done) "Practice again  →" else "Start lesson  →", { vm.startSession(t) })

            SectionTitle("🎬 Videos to watch")
            if (t.videos.isEmpty()) Text("No videos for this day yet.", color = TextLo)
            t.videos.forEachIndexed { i, v ->
                VideoCard(v, playing == i, vm.eyeBreak, vm) { playing = if (playing == i) null else i }
            }

            if (t.materials.isNotEmpty()) {
                SectionTitle("📄 Documents & hands-on practice")
                t.materials.forEach { MaterialCard(it) }
            }

            if (bestPrompt != null) {
                SectionTitle("🤖 Try it with your AI assistant")
                Panel {
                    Text("Paste this into your AI assistant, in a sandbox, and review what it produces.", color = TextLo, fontSize = 13.sp)
                    Text(bestPrompt, color = TextHi, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
                    Chip("📋 Copy prompt", Modifier.fillMaxWidth()) { copyText(ctx, bestPrompt); vm.toast = "📋 Prompt copied" }
                }
            }

            SectionTitle("📝 Lesson notes")
            NotesPanels(t)

            SoftButton("Quiz me on this day", { vm.startSession(t) })
            Spacer(Modifier.height(24.dp))
        }
    }
}
