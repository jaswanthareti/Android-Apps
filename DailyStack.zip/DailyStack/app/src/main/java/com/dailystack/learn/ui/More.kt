package com.dailystack.learn.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dailystack.learn.*
import java.time.LocalDate
import java.time.format.DateTimeFormatter

// ---------------- Profile ----------------
@Composable
fun ProfileScreen(vm: AppViewModel) {
    val p by vm.progress.collectAsState()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Profile", color = TextHi, fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text("⚙️", fontSize = 26.sp, modifier = Modifier.pressable { vm.screen = Screen.Settings }.padding(8.dp))
        }
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Box(Modifier.size(72.dp).clip(CircleShape).background(Surf2), contentAlignment = Alignment.Center) { Penguin(60.dp) }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(p.name, color = TextHi, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Level ${vm.level()} · ${vm.levelName()}  ·  ${p.level}", color = TextLo, fontSize = 13.sp)
                    Bar(vm.levelProgress())
                    Text("${vm.xpInLevel()} / 250 XP", color = TextLo, fontSize = 12.sp)
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Stat("🔥", "${p.streak}", "day streak", Modifier.weight(1f))
            Stat("📖", "${p.doneTopics.size}", "lessons", Modifier.weight(1f))
            Stat("🏅", "${vm.badges().count { it.unlocked }}", "badges", Modifier.weight(1f))
        }
        MenuRow("📈", "My Progress", "Weekly XP and time learned") { vm.screen = Screen.Progress }
        MenuRow("🏅", "Achievements", "Badges you've earned") { vm.screen = Screen.Achievements }
        MenuRow("🎓", "Certificates", "Finish a course to earn one") { vm.screen = Screen.Certificates }
        MenuRow("➕", "Courses", "Add your own or manage courses") { vm.screen = Screen.AddCourse }
        MenuRow("🎁", "Rewards", "Redeem your points") { vm.screen = Screen.Rewards }
        MenuRow("⚙️", "Settings", "Reminders, eye breaks, profile") { vm.screen = Screen.Settings }
    }
}

@Composable
private fun MenuRow(emoji: String, title: String, sub: String, onClick: () -> Unit) {
    Panel(Modifier.pressable(onClick = onClick)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Box(Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(Surf2), contentAlignment = Alignment.Center) { Text(emoji, fontSize = 20.sp) }
            Column(Modifier.weight(1f)) {
                Text(title, color = TextHi, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                Text(sub, color = TextLo, fontSize = 12.sp)
            }
            Text("›", color = TextLo, fontSize = 24.sp)
        }
    }
}

// ---------------- My Progress ----------------
@Composable
fun ProgressContent(vm: AppViewModel) {
    val p by vm.progress.collectAsState()
    val bars = vm.last7()
    val course = vm.activeCourse()
    val total = vm.courseTopics(course).size.coerceAtLeast(1)
    val done = vm.courseDoneCount(course)
    Panel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("XP this week", color = TextHi, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.weight(1f))
            Pill("Last 7 days")
        }
        BarChart(bars)
    }
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Stat("📖", "${p.doneTopics.size}", "lessons completed", Modifier.weight(1f))
        Stat("⏱️", if (p.minutes < 60) "${p.minutes}m" else "${p.minutes / 60}h ${p.minutes % 60}m", "time learned", Modifier.weight(1f))
        Stat("⭐", "${p.totalXp}", "XP earned", Modifier.weight(1f))
    }
    Panel {
        Label("Current learning path")
        Text("${course.emoji} ${course.title}", color = TextHi, fontWeight = FontWeight.Bold)
        Bar(done / total.toFloat())
        Text("$done of $total days completed (${done * 100 / total}%)", color = TextLo, fontSize = 13.sp)
    }
}

@Composable
private fun BarChart(bars: List<DayBar>) {
    val maxV = maxOf(bars.maxOf { it.xp }, 50)
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Canvas(Modifier.fillMaxWidth().height(120.dp)) {
            val n = bars.size
            val gap = 12.dp.toPx()
            val bw = (size.width - gap * (n - 1)) / n
            bars.forEachIndexed { i, b ->
                val h = size.height * (b.xp.toFloat() / maxV).coerceAtLeast(0.04f)
                drawRoundRect(
                    if (b.today) Accent else Accent.copy(alpha = .3f),
                    Offset(i * (bw + gap), size.height - h), Size(bw, h), CornerRadius(bw / 3)
                )
            }
        }
        Row(Modifier.fillMaxWidth()) {
            bars.forEach {
                Text(it.label, Modifier.weight(1f), textAlign = TextAlign.Center, color = if (it.today) Accent else TextLo, fontSize = 11.sp)
            }
        }
    }
}

// ---------------- Achievements ----------------
@Composable
fun AchievementsContent(vm: AppViewModel) {
    val p by vm.progress.collectAsState()
    var filter by remember { mutableIntStateOf(0) }
    val all = vm.badges()
    val shown = when (filter) { 1 -> all.filter { it.unlocked }; 2 -> all.filter { !it.unlocked }; else -> all }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("All", "Unlocked (${all.count { it.unlocked }})", "Locked (${all.count { !it.unlocked }})").forEachIndexed { i, l ->
            Pill(l, if (filter == i) Accent else Surf2, if (filter == i) Color.White else Accent, Modifier.pressable { filter = i })
        }
    }
    if (shown.isEmpty()) Text("Nothing here yet.", color = TextLo)
    shown.chunked(2).forEach { row ->
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            row.forEach { b ->
                Panel(Modifier.weight(1f), color = if (b.unlocked) Color.White else Surf2) {
                    Text(if (b.unlocked) b.emoji else "🔒", fontSize = 34.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
                    Text(b.title, color = if (b.unlocked) TextHi else TextLo, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                    Text(b.desc, color = TextLo, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                }
            }
            if (row.size == 1) Spacer(Modifier.weight(1f))
        }
    }
    Text("Best streak: ${p.best} days", color = TextLo, fontSize = 12.sp)
}

// ---------------- Certificates ----------------
@Composable
fun CertificatesContent(vm: AppViewModel) {
    val p by vm.progress.collectAsState()
    Text("Finish every day of a course to earn its certificate.", color = TextLo, fontSize = 13.sp)
    vm.courses.forEach { c ->
        val total = vm.courseTopics(c).size.coerceAtLeast(1)
        val done = vm.courseDoneCount(c)
        val date = vm.courseDoneDate(c)
        if (date != null) {
            val shape = RoundedCornerShape(20.dp)
            Column(
                Modifier.fillMaxWidth().clip(shape).background(Color(0xFFFFFBF0)).border(2.dp, Gold, shape).padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Penguin(56.dp)
                Label("Certificate of completion")
                Text(c.title, color = TextHi, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
                Text("Presented to", color = TextLo, fontSize = 12.sp)
                Text(p.name, color = TextHi, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("for completing all $total days", color = TextLo, fontSize = 13.sp, textAlign = TextAlign.Center)
                Text(LocalDate.ofEpochDay(date).format(DateTimeFormatter.ofPattern("MMM d, yyyy")), color = TextLo, fontSize = 12.sp)
            }
        } else {
            Panel {
                Text("🔒 ${c.emoji} ${c.title}", color = TextHi, fontWeight = FontWeight.Bold)
                Bar(done / total.toFloat())
                Text("$done of $total days completed", color = TextLo, fontSize = 13.sp)
            }
        }
    }
}

// ---------------- Settings ----------------
@Composable
fun SettingsContent(vm: AppViewModel) {
    val p by vm.progress.collectAsState()
    var reminder by remember { mutableStateOf(false) }
    var nameDlg by remember { mutableStateOf(false) }
    var levelDlg by remember { mutableStateOf(false) }
    var resetDlg by remember { mutableStateOf(false) }

    SettingRow("🙂", "Name", p.name, onClick = { nameDlg = true })
    SettingRow("🎚️", "Level", p.level, onClick = { levelDlg = true })
    SettingRow("🔔", "Reminders & eye breaks", "Reminder ${p.reminderHour}:00 · eye break every ${p.eyeMinutes} min", onClick = { reminder = true })
    SettingRow("➕", "Courses", "Add your own or manage courses", onClick = { vm.screen = Screen.AddCourse })
    SettingRow("📥", "Offline content", "Lessons and quizzes are bundled. Videos need internet.")
    SettingRow("🔒", "Privacy", "Your progress is stored only on this device.")
    SettingRow("ℹ️", "About", "DailyStack v1.0")
    SettingRow("♻️", "Reset progress", "Clears XP, streaks and completed days", onClick = { resetDlg = true }, danger = true)

    if (reminder) SettingsDialog(p, vm) { reminder = false }
    if (nameDlg) {
        var n by remember { mutableStateOf(p.name) }
        AlertDialog(
            onDismissRequest = { nameDlg = false }, containerColor = Surf, title = { Text("Your name", color = TextHi) },
            text = { OutlinedTextField(n, { n = it.take(24) }, singleLine = true) },
            confirmButton = { TextButton({ vm.setProfile(n, p.goal, p.level); nameDlg = false }) { Text("Save") } },
            dismissButton = { TextButton({ nameDlg = false }) { Text("Cancel") } }
        )
    }
    if (levelDlg) AlertDialog(
        onDismissRequest = { levelDlg = false }, containerColor = Surf, title = { Text("Your level", color = TextHi) },
        text = {
            Column {
                listOf("Beginner", "Intermediate", "Advanced").forEach { l ->
                    TextButton({ vm.setProfile(p.name, p.goal, l); levelDlg = false }) { Text(if (l == p.level) "✔ $l" else l) }
                }
            }
        },
        confirmButton = {}, dismissButton = { TextButton({ levelDlg = false }) { Text("Close") } }
    )
    if (resetDlg) AlertDialog(
        onDismissRequest = { resetDlg = false }, containerColor = Surf, title = { Text("Reset progress?", color = TextHi) },
        text = { Text("This clears your XP, streaks, badges and completed days. Your courses stay.", color = TextHi) },
        confirmButton = { TextButton({ vm.resetProgress(); resetDlg = false }) { Text("Reset", color = Bad) } },
        dismissButton = { TextButton({ resetDlg = false }) { Text("Cancel") } }
    )
}

@Composable
private fun SettingRow(emoji: String, title: String, value: String, onClick: (() -> Unit)? = null, danger: Boolean = false) {
    Panel(if (onClick != null) Modifier.pressable(onClick = onClick) else Modifier) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(emoji, fontSize = 22.sp)
            Column(Modifier.weight(1f)) {
                Text(title, color = if (danger) Bad else TextHi, fontWeight = FontWeight.SemiBold)
                Text(value, color = TextLo, fontSize = 12.sp)
            }
            if (onClick != null) Text("›", color = TextLo, fontSize = 22.sp)
        }
    }
}
