package com.dailystack.learn

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

@Serializable data class ImportVideo(val title: String = "", val url: String, val startSec: Int = 0, val endSec: Int = 0, val note: String = "")
@Serializable data class ImportLink(val title: String = "", val url: String, val note: String = "")
@Serializable data class ImportQ(val q: String, val options: List<String>, val answer: Int, val why: String = "")
@Serializable data class ImportDay(
    val title: String, val emoji: String = "📘", val summary: String = "", val why: String = "",
    val keyPoints: List<String> = emptyList(), val pitfalls: List<String> = emptyList(),
    val videos: List<ImportVideo> = emptyList(), val links: List<ImportLink> = emptyList(),
    val quiz: List<ImportQ> = emptyList()
)
@Serializable data class ImportCourse(
    val title: String, val emoji: String = "📘", val description: String = "", val level: String = "Beginner",
    val days: List<ImportDay>
)

/** Turns a simple course description (JSON from an AI, a file, or a quick list) into a Course. */
object CourseImport {
    private val json = Json { ignoreUnknownKeys = true; isLenient = true; coerceInputValues = true }

    val AI_PROMPT = """
I want a self-study course on: [TOPIC]. My level: [beginner / intermediate / advanced]. I can study about 1 hour per day.

Create a plan of [NUMBER OF] days (one topic per day) and reply with ONLY valid JSON, with no explanation and no markdown fences, in exactly this shape:

{
  "title": "Course title",
  "emoji": "📘",
  "description": "One sentence about the course",
  "level": "Beginner",
  "days": [
    {
      "title": "Day topic",
      "emoji": "🧩",
      "summary": "2-3 sentences: what this topic is",
      "why": "1-2 sentences: why it matters when AI does much of the work",
      "keyPoints": ["essential point 1", "essential point 2", "essential point 3"],
      "pitfalls": ["a common mistake AI makes here"],
      "videos": [{"title": "Video title", "url": "https://www.youtube.com/watch?v=..."}],
      "links": [{"title": "Official docs page", "url": "https://..."}],
      "quiz": [{"q": "Question?", "options": ["A", "B", "C", "D"], "answer": 0, "why": "Why that is right"}]
    }
  ]
}

Rules: focus on the essentials needed to direct AI tools and verify their output, not on everything. Give 3 quiz questions per day ("answer" is the zero-based index of the correct option). Only include video and document URLs you are certain exist. If you are not sure, leave that list empty instead of guessing.
""".trimIndent()

    fun parse(text: String, existingIds: Set<String>): Course {
        val start = text.indexOf('{'); val end = text.lastIndexOf('}')
        require(start >= 0 && end > start) { "That doesn't look like JSON. Paste the whole object, starting with {" }
        val ic = try {
            json.decodeFromString<ImportCourse>(text.substring(start, end + 1))
        } catch (e: Exception) {
            throw IllegalArgumentException("Couldn't read the course: " + (e.message ?: "invalid JSON").take(160))
        }
        return convert(ic, existingIds)
    }

    /** One line per day: "Day title | video URL | document URL" (the last two are optional). */
    fun fromQuickList(title: String, lines: String, existingIds: Set<String>): Course {
        val days = lines.lines().map { it.trim() }.filter { it.isNotEmpty() }.map { line ->
            val parts = line.split("|").map { it.trim() }
            ImportDay(
                title = parts[0],
                videos = parts.getOrNull(1)?.takeIf { it.startsWith("http") }?.let { listOf(ImportVideo(url = it)) } ?: emptyList(),
                links = parts.getOrNull(2)?.takeIf { it.startsWith("http") }?.let { listOf(ImportLink(url = it)) } ?: emptyList()
            )
        }
        return convert(ImportCourse(title = title.trim(), days = days), existingIds)
    }

    private fun slug(s: String) =
        s.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').ifBlank { "course" }.take(30)

    private fun youTubeId(url: String): String? {
        if ("youtube.com" !in url && "youtu.be" !in url) return null
        return Regex("(?:v=|youtu\\.be/|embed/|shorts/)([A-Za-z0-9_-]{11})").find(url)?.groupValues?.get(1)
    }

    private fun toVideo(v: ImportVideo): Video {
        val yt = youTubeId(v.url)
        return when {
            yt != null -> Video(v.title.ifBlank { "YouTube video" }, "youtube", id = yt, startSec = v.startSec, endSec = v.endSec, note = v.note)
            "udemy.com" in v.url -> Video(v.title.ifBlank { "Udemy lecture" }, "udemy", url = v.url, note = v.note)
            else -> Video(v.title.ifBlank { v.url }, "link", url = v.url, note = v.note)
        }
    }

    private fun convert(ic: ImportCourse, existingIds: Set<String>): Course {
        require(ic.title.isNotBlank()) { "The course needs a title." }
        require(ic.days.isNotEmpty()) { "The course needs at least one day." }
        require(ic.days.size <= 120) { "That's more than 120 days. Split it into several courses." }
        var id = slug(ic.title); var n = 2
        while (id in existingIds || id == "aws") id = slug(ic.title) + "-" + n++

        val topics = ic.days.mapIndexed { i, d ->
            val label = "Day ${i + 1}"
            require(d.title.isNotBlank()) { "$label needs a title." }
            (d.videos.map { it.url } + d.links.map { it.url }).forEach {
                require(it.startsWith("http://") || it.startsWith("https://")) { "$label: \"$it\" is not a web link (must start with http)." }
            }
            val tid = "$id~d${i + 1}"
            Topic(
                id = tid, title = d.title.trim(), emoji = d.emoji.ifBlank { "📘" },
                what = d.summary.ifBlank { d.title }, why = d.why.ifBlank { "Understanding this lets you direct AI tools and check their work." },
                core = d.keyPoints, aiPitfalls = d.pitfalls,
                videos = d.videos.map { toVideo(it) },
                materials = d.links.map { Material(it.title.ifBlank { it.url }, it.url, "doc", it.note) },
                checks = d.quiz.mapIndexed { qi, q ->
                    require(q.options.size >= 2) { "$label quiz question ${qi + 1} needs at least 2 options." }
                    require(q.answer in q.options.indices) { "$label quiz question ${qi + 1}: \"answer\" must be 0 to ${q.options.size - 1}." }
                    Question("$tid-q${qi + 1}", q.q, q.options, q.answer, q.why.ifBlank { "Review the lesson notes." })
                }
            )
        }
        val weeks = topics.chunked(5).mapIndexed { wi, ts ->
            Week(wi + 1, "Days ${wi * 5 + 1}-${wi * 5 + ts.size}", ts)
        }
        return Course(id, ic.title.trim(), ic.emoji.ifBlank { "📘" }, ic.description, ic.level, builtin = false, weeks = weeks)
    }
}
