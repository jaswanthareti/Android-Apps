package com.dailystack.learn.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dailystack.learn.*

@Composable
fun LearnScreen(vm: AppViewModel) {
    val p by vm.progress.collectAsState()
    var seg by remember { mutableIntStateOf(0) }
    val course = vm.activeCourse()

    Column(Modifier.fillMaxSize().padding(top = 12.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Learning Path", color = TextHi, fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Pill("＋ Add course", Accent, Color.White, Modifier.pressable { vm.screen = Screen.AddCourse })
        }
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            vm.courses.forEach { c ->
                val sel = c.id == course.id
                Box(
                    Modifier.pressable { vm.setActiveCourse(c.id) }.clip(RoundedCornerShape(50))
                        .background(if (sel) Accent else Color.White)
                        .border(1.dp, if (sel) Accent else Surf2, RoundedCornerShape(50))
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) { Text("${c.emoji} ${c.title}", color = if (sel) Color.White else TextHi, fontWeight = FontWeight.SemiBold, fontSize = 14.sp) }
            }
        }
        Row(
            Modifier.padding(horizontal = 20.dp).fillMaxWidth().clip(RoundedCornerShape(50)).background(Surf2).padding(4.dp),
        ) {
            listOf("All Weeks", "My Progress", "Certificates").forEachIndexed { i, label ->
                Box(
                    Modifier.weight(1f).pressable { seg = i }.clip(RoundedCornerShape(50))
                        .background(if (seg == i) Accent else Color.Transparent).padding(vertical = 9.dp),
                    contentAlignment = Alignment.Center
                ) { Text(label, color = if (seg == i) Color.White else TextLo, fontWeight = FontWeight.SemiBold, fontSize = 13.sp) }
            }
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            when (seg) {
                0 -> WeeksList(course, p, vm)
                1 -> ProgressContent(vm)
                else -> CertificatesContent(vm)
            }
        }
    }
}

@Composable
private fun WeeksList(course: Course, p: Progress, vm: AppViewModel) {
    val today = vm.todayTopic()
    var open by remember(course.id) { mutableStateOf(setOf(today?.let { vm.weekOf(it) } ?: 1)) }
    if (course.description.isNotBlank()) Text(course.description, color = TextLo, fontSize = 13.sp)
    course.weeks.forEach { w ->
        val done = w.topics.count { it.id in p.doneTopics }
        val locked = w.topics.none { vm.isUnlocked(it) }
        val isOpen = w.id in open
        Panel(Modifier.pressable { open = if (isOpen) open - w.id else open + w.id }) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(Surf2), contentAlignment = Alignment.Center) {
                    Text(w.topics.firstOrNull()?.emoji ?: "📘", fontSize = 22.sp)
                }
                Column(Modifier.weight(1f)) {
                    Label("Week ${w.id}")
                    Text(w.title, color = TextHi, fontWeight = FontWeight.Bold)
                    Text("${w.topics.size} lessons", color = TextLo, fontSize = 12.sp)
                }
                if (locked) Text("🔒", fontSize = 20.sp) else Text("$done/${w.topics.size}", color = Accent, fontWeight = FontWeight.Bold)
            }
            if (isOpen) {
                w.topics.forEach { t ->
                    val status = if (t.id in p.doneTopics) "✅" else if (t.id == today?.id) "▶️" else "🔒"
                    Row(
                        Modifier.fillMaxWidth().pressable { vm.openHub(t) }.padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(status, fontSize = 17.sp)
                        Text("Day ${vm.dayOf(t)} · ${t.emoji} ${t.title}", color = if (status == "🔒") TextLo else TextHi, fontSize = 15.sp)
                    }
                }
            }
        }
    }
}
