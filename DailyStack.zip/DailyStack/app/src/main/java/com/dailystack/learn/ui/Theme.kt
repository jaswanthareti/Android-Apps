package com.dailystack.learn.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

val Bg = Color(0xFF0E1116)
val Surf = Color(0xFF171C24)
val Surf2 = Color(0xFF212835)
val Accent = Color(0xFF7C5CFF)
val Teal = Color(0xFF2DD4BF)
val Gold = Color(0xFFFFB020)
val Good = Color(0xFF34D399)
val Bad = Color(0xFFFF5C7A)
val TextHi = Color(0xFFF2F4F8)
val TextLo = Color(0xFF9AA5B8)

@Composable
fun DailyTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent, secondary = Teal, background = Bg, surface = Surf,
            onSurface = TextHi, onBackground = TextHi
        ),
        content = content
    )
}

/** Springy press-scale + light haptic on every tap. */
fun Modifier.pressable(enabled: Boolean = true, onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(
        if (pressed && enabled) 0.96f else 1f,
        spring(dampingRatio = 0.5f, stiffness = 500f), label = "press"
    )
    val haptic = LocalHapticFeedback.current
    this
        .graphicsLayer { scaleX = s; scaleY = s }
        .clickable(interactionSource = src, indication = null, enabled = enabled) {
            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            onClick()
        }
}

@Composable
fun Panel(
    modifier: Modifier = Modifier,
    color: Color = Surf,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(color).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        content = content
    )
}

@Composable
fun Label(text: String) =
    Text(text.uppercase(), color = Teal, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)

@Composable
fun BigButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    val a by animateFloatAsState(if (enabled) 1f else 0.4f, tween(250), label = "en")
    Box(
        modifier.fillMaxWidth().height(56.dp)
            .graphicsLayer { alpha = a }
            .pressable(enabled, onClick)
            .clip(RoundedCornerShape(18.dp))
            .background(Brush.horizontalGradient(listOf(Accent, Color(0xFF4F8CFF)))),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp) }
}

@Composable
fun Reveal(delayMs: Int = 0, content: @Composable () -> Unit) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(delayMs.toLong()); shown = true }
    val a by animateFloatAsState(if (shown) 1f else 0f, tween(450, easing = FastOutSlowInEasing), label = "reveal")
    Box(Modifier.graphicsLayer { alpha = a; translationY = (1f - a) * 40f }) { content() }
}

@Composable
fun Ring(progress: Float, size: Dp, stroke: Dp, color: Color = Accent, content: @Composable () -> Unit) {
    val a by animateFloatAsState(progress.coerceIn(0f, 1f), tween(900, easing = FastOutSlowInEasing), label = "ring")
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val st = stroke.toPx()
            val tl = Offset(st / 2, st / 2)
            val sz = Size(this.size.width - st, this.size.height - st)
            drawArc(Surf2, 0f, 360f, false, tl, sz, style = Stroke(st, cap = StrokeCap.Round))
            drawArc(color, -90f, 360f * a, false, tl, sz, style = Stroke(st, cap = StrokeCap.Round))
        }
        content()
    }
}
