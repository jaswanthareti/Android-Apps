package com.dailystack.learn.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

// Light "glacier" palette: lavender-white surfaces, purple primary, mascot-friendly accents.
val Bg = Color(0xFFF4F4FF)
val Surf = Color.White
val Surf2 = Color(0xFFECEBFF)
val Accent = Color(0xFF6C5CE7)
val Teal = Color(0xFF14B8A6)
val Gold = Color(0xFFF5A623)
val Good = Color(0xFF22C55E)
val Bad = Color(0xFFEF4444)
val TextHi = Color(0xFF1F1B4D)
val TextLo = Color(0xFF6B6F8D)
val CodeBg = Color(0xFF14172B)
val CodeText = Color(0xFFE6E8F7)

@Composable
fun DailyTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Accent, secondary = Teal, background = Bg, surface = Surf,
            onSurface = TextHi, onBackground = TextHi
        ),
        content = content
    )
}

/** Springy press-scale + light haptic on every tap. */
fun Modifier.pressable(enabled: Boolean = true, onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(
        if (pressed && enabled) 0.96f else 1f,
        spring(dampingRatio = 0.5f, stiffness = 500f), label = "press"
    )
    val haptic = LocalHapticFeedback.current
    this
        .graphicsLayer { scaleX = s; scaleY = s }
        .clickable(interactionSource = src, indication = null, enabled = enabled) {
            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            onClick()
        }
}

@Composable
fun Panel(
    modifier: Modifier = Modifier,
    color: Color = Surf,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(24.dp)
    Column(
        modifier.fillMaxWidth()
            .shadow(3.dp, shape, ambientColor = Color(0x226C5CE7), spotColor = Color(0x226C5CE7))
            .clip(shape).background(color).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        content = content
    )
}

@Composable
fun Label(text: String) =
    Text(text.uppercase(), color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)

@Composable
fun BigButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    val a by animateFloatAsState(if (enabled) 1f else 0.4f, tween(250), label = "en")
    Box(
        modifier.fillMaxWidth().height(56.dp)
            .graphicsLayer { alpha = a }
            .pressable(enabled, onClick)
            .clip(RoundedCornerShape(18.dp))
            .background(Brush.horizontalGradient(listOf(Accent, Color(0xFF8470F0)))),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp) }
}

@Composable
fun SoftButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier.fillMaxWidth().height(50.dp).pressable(onClick = onClick)
            .clip(RoundedCornerShape(16.dp)).background(Surf2),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Accent, fontWeight = FontWeight.SemiBold, fontSize = 16.sp) }
}

@Composable
fun SectionTitle(text: String) =
    Text(text, color = TextHi, fontSize = 20.sp, fontWeight = FontWeight.Bold)

@Composable
fun Pill(text: String, bg: Color = Surf2, fg: Color = Accent, modifier: Modifier = Modifier) {
    Box(modifier.clip(RoundedCornerShape(50)).background(bg).padding(horizontal = 12.dp, vertical = 6.dp)) {
        Text(text, color = fg, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun Bar(progress: Float, modifier: Modifier = Modifier, color: Color = Accent, track: Color = Surf2, height: Dp = 8.dp) {
    val a by animateFloatAsState(progress.coerceIn(0f, 1f), tween(800, easing = FastOutSlowInEasing), label = "bar")
    Box(modifier.fillMaxWidth().height(height).clip(RoundedCornerShape(50)).background(track)) {
        Box(Modifier.fillMaxHeight().fillMaxWidth(a).clip(RoundedCornerShape(50)).background(color))
    }
}

@Composable
fun TopBar(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("←", color = TextHi, fontSize = 26.sp, modifier = Modifier.pressable(onClick = onBack).padding(10.dp))
        Text(title, color = TextHi, fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
        Spacer(Modifier.width(46.dp))
    }
}

@Composable
fun Reveal(delayMs: Int = 0, content: @Composable () -> Unit) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(delayMs.toLong()); shown = true }
    val a by animateFloatAsState(if (shown) 1f else 0f, tween(450, easing = FastOutSlowInEasing), label = "reveal")
    Box(Modifier.graphicsLayer { alpha = a; translationY = (1f - a) * 40f }) { content() }
}

@Composable
fun Ring(progress: Float, size: Dp, stroke: Dp, color: Color = Accent, content: @Composable () -> Unit) {
    val a by animateFloatAsState(progress.coerceIn(0f, 1f), tween(900, easing = FastOutSlowInEasing), label = "ring")
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val st = stroke.toPx()
            val tl = Offset(st / 2, st / 2)
            val sz = Size(this.size.width - st, this.size.height - st)
            drawArc(Surf2, 0f, 360f, false, tl, sz, style = Stroke(st, cap = StrokeCap.Round))
            drawArc(color, -90f, 360f * a, false, tl, sz, style = Stroke(st, cap = StrokeCap.Round))
        }
        content()
    }
}

/** Simple vector penguin mascot (swap for real artwork by replacing this composable's body with an Image). */
@Composable
fun Penguin(size: Dp, modifier: Modifier = Modifier) {
    val navy = Color(0xFF2B2A4C); val orange = Color(0xFFFFA63D)
    Canvas(modifier.size(size)) {
        val w = this.size.width; val h = this.size.height
        drawOval(orange, Offset(w * 0.20f, h * 0.88f), Size(w * 0.26f, h * 0.09f))
        drawOval(orange, Offset(w * 0.54f, h * 0.88f), Size(w * 0.26f, h * 0.09f))
        drawOval(navy, Offset(w * 0.04f, h * 0.42f), Size(w * 0.20f, h * 0.38f))
        drawOval(navy, Offset(w * 0.76f, h * 0.42f), Size(w * 0.20f, h * 0.38f))
        drawOval(navy, Offset(w * 0.12f, h * 0.08f), Size(w * 0.76f, h * 0.84f))
        drawOval(Color.White, Offset(w * 0.27f, h * 0.40f), Size(w * 0.46f, h * 0.50f))
        drawOval(Color.White, Offset(w * 0.22f, h * 0.22f), Size(w * 0.56f, h * 0.38f))
        drawCircle(TextHi, w * 0.048f, Offset(w * 0.39f, h * 0.38f))
        drawCircle(TextHi, w * 0.048f, Offset(w * 0.61f, h * 0.38f))
        drawCircle(Color.White, w * 0.016f, Offset(w * 0.40f, h * 0.365f))
        drawCircle(Color.White, w * 0.016f, Offset(w * 0.62f, h * 0.365f))
        drawCircle(Color(0x55FF8FA3), w * 0.04f, Offset(w * 0.31f, h * 0.47f))
        drawCircle(Color(0x55FF8FA3), w * 0.04f, Offset(w * 0.69f, h * 0.47f))
        val beak = Path().apply {
            moveTo(w * 0.44f, h * 0.45f); lineTo(w * 0.56f, h * 0.45f); lineTo(w * 0.50f, h * 0.54f); close()
        }
        drawPath(beak, orange)
        drawRoundRect(Accent, Offset(w * 0.22f, h * 0.59f), Size(w * 0.56f, h * 0.09f), CornerRadius(w * 0.05f))
        drawRoundRect(Accent, Offset(w * 0.56f, h * 0.62f), Size(w * 0.10f, h * 0.18f), CornerRadius(w * 0.03f))
    }
}
