package com.dailystack.learn.ui

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.browser.customtabs.CustomTabsIntent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.dailystack.learn.*

private const val EMBED_ORIGIN = "https://dailystack.app"

/**
 * YouTube iframe inside our own WebView. YouTube now rejects embeds that arrive without a valid
 * origin/referrer (errors 152/153), so the page is loaded with an https base URL, the same value is
 * passed as the `origin` parameter, and the iframe sends a referrer.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun YouTubeEmbed(videoId: String, startSec: Int, endSec: Int, paused: Boolean, modifier: Modifier) {
    val ctx = LocalContext.current
    val webView = remember(videoId, startSec, endSec) {
        WebView(ctx).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            setBackgroundColor(android.graphics.Color.BLACK)
            webChromeClient = WebChromeClient()
            webViewClient = WebViewClient()
            val endParam = if (endSec > 0) "&end=$endSec" else ""
            val src = "https://www.youtube.com/embed/$videoId?playsinline=1&rel=0&enablejsapi=1" +
                "&start=$startSec$endParam&origin=$EMBED_ORIGIN"
            val html = """
                <html><head><meta name="viewport" content="width=device-width, initial-scale=1">
                <style>html,body{margin:0;height:100%;background:#000}
                iframe{position:absolute;top:0;left:0;width:100%;height:100%;border:0}</style></head>
                <body><iframe id="p" src="$src"
                  allow="autoplay; encrypted-media; picture-in-picture; fullscreen"
                  referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe></body></html>
            """.trimIndent()
            loadDataWithBaseURL(EMBED_ORIGIN, html, "text/html", "utf-8", null)
        }
    }
    DisposableEffect(webView) { onDispose { webView.stopLoading(); webView.destroy() } }
    LaunchedEffect(paused) {
        if (paused) webView.evaluateJavascript(
            "document.getElementById('p').contentWindow.postMessage(" +
                "'{\"event\":\"command\",\"func\":\"pauseVideo\",\"args\":\"\"}','*')", null
        )
    }
    AndroidView(factory = { webView }, modifier = modifier)
}

/** Opens in the YouTube / Udemy app if installed (so you are already logged in), else the browser. */
internal fun openExternal(ctx: Context, url: String) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        CustomTabsIntent.Builder().build().launchUrl(ctx, Uri.parse(url))
    }
}

internal fun youTubeUrl(v: Video) =
    "https://www.youtube.com/watch?v=${v.id}" + if (v.startSec > 0) "&t=${v.startSec}s" else ""

@Composable
internal fun Chip(text: String, modifier: Modifier = Modifier, primary: Boolean = false, onClick: () -> Unit) {
    Box(
        modifier.pressable(onClick = onClick).clip(RoundedCornerShape(14.dp))
            .background(if (primary) Accent else Surf2).padding(horizontal = 10.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = TextHi, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, textAlign = TextAlign.Center)
    }
}

@Composable
fun VideoCard(v: Video, playing: Boolean, paused: Boolean, vm: AppViewModel, onToggle: () -> Unit) {
    val ctx = LocalContext.current
    Panel {
        Label(if (v.kind == "youtube") "YouTube · free" else if (v.kind == "udemy") "Udemy · log in" else "Link")
        Text(v.title, color = TextHi, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
        if (v.note.isNotBlank()) Text(v.note, color = TextLo, fontSize = 13.sp)
        if (v.kind == "youtube" && playing) {
            key(v.id) {
                Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(16.dp)).background(Surf2)) {
                    YouTubeEmbed(v.id, v.startSec, v.endSec, paused, Modifier.fillMaxSize())
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (v.kind == "youtube") {
                Chip(if (playing) "⏹ Close player" else "▶ Play here", Modifier.weight(1f), primary = true, onClick = onToggle)
                Chip("↗ Open in YouTube", Modifier.weight(1f)) { openExternal(ctx, youTubeUrl(v)) }
            } else {
                Chip(if (v.kind == "udemy") "↗ Open in Udemy" else "↗ Open link", Modifier.fillMaxWidth(), primary = true) {
                    openExternal(ctx, v.url)
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Helpful?", color = TextLo)
            Text("👍", fontSize = 24.sp, modifier = Modifier.pressable { vm.rateVideo(v.title, 1) }.padding(6.dp))
            Text("👎", fontSize = 24.sp, modifier = Modifier.pressable { vm.rateVideo(v.title, -1) }.padding(6.dp))
        }
    }
}

@Composable
fun WatchStep(t: Topic, paused: Boolean, vm: AppViewModel, onNext: () -> Unit) {
    var playing by remember(t.id) { mutableStateOf<Int?>(null) }
    var tab by remember(t.id) { mutableIntStateOf(0) }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("${t.emoji} ${t.title}", color = TextHi, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
        Row(Modifier.fillMaxWidth()) {
            listOf("Video", "Notes", "Materials").forEachIndexed { i, label ->
                Column(Modifier.weight(1f).pressable { tab = i }, horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(label, color = if (tab == i) Accent else TextLo, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 6.dp))
                    Box(Modifier.fillMaxWidth().height(3.dp).clip(RoundedCornerShape(2.dp)).background(if (tab == i) Accent else Surf2))
                }
            }
        }
        when (tab) {
            0 -> {
                Text("Pick any option. If a video won't play here, open it in the YouTube or Udemy app.", color = TextLo, fontSize = 13.sp)
                if (t.videos.isEmpty()) Panel { Text("No video for this topic yet. Read the notes and materials, then take the quiz.", color = TextHi) }
                t.videos.forEachIndexed { i, v -> VideoCard(v, playing == i, paused, vm) { playing = if (playing == i) null else i } }
            }
            1 -> NotesPanels(t)
            else -> {
                if (t.materials.isEmpty()) Text("No extra materials for this day.", color = TextLo)
                t.materials.forEach { MaterialCard(it) }
            }
        }
        BigButton("Next: Practice  →", onNext)
    }
}
