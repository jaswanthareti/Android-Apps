package com.dailystack.learn.ui

import android.net.Uri
import androidx.browser.customtabs.CustomTabsIntent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.dailystack.learn.*
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.options.IFramePlayerOptions
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView

@Composable
fun YouTubeEmbed(videoId: String, startSec: Int, endSec: Int, paused: Boolean, modifier: Modifier) {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    var player by remember { mutableStateOf<YouTubePlayer?>(null) }
    val view = remember(videoId) {
        YouTubePlayerView(ctx).apply {
            enableAutomaticInitialization = false
            initialize(object : AbstractYouTubePlayerListener() {
                override fun onReady(youTubePlayer: YouTubePlayer) {
                    player = youTubePlayer
                    youTubePlayer.cueVideo(videoId, startSec.toFloat())
                }
                override fun onCurrentSecond(youTubePlayer: YouTubePlayer, second: Float) {
                    if (endSec > 0 && second >= endSec) youTubePlayer.pause()
                }
            }, IFramePlayerOptions.Builder().controls(1).build())
        }
    }
    DisposableEffect(owner, view) {
        owner.lifecycle.addObserver(view)
        onDispose { owner.lifecycle.removeObserver(view); view.release() }
    }
    LaunchedEffect(paused, player) { if (paused) player?.pause() }
    AndroidView(factory = { view }, modifier = modifier)
}

@Composable
fun WatchStep(t: Topic, paused: Boolean, vm: AppViewModel, onNext: () -> Unit) {
    val ctx = LocalContext.current
    var which by remember(t.id) { mutableIntStateOf(0) }
    val v = t.videos.getOrNull(which)
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Reveal(0) { Text("🎬 Watch the essentials", color = TextHi, fontSize = 24.sp, fontWeight = FontWeight.Bold) }
        if (v == null) {
            Panel {
                Text(
                    "No video for this topic yet. Add one to the topic's \"videos\" list in content.json. For now, jump into practice.",
                    color = TextHi
                )
            }
        } else {
            Text(v.title, color = TextHi, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
            if (v.note.isNotBlank()) Text(v.note, color = TextLo, fontSize = 13.sp)
            if (v.kind == "youtube") {
                key(v.id) {
                    Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(20.dp)).background(Surf)) {
                        YouTubeEmbed(v.id, v.startSec, v.endSec, paused, Modifier.fillMaxSize())
                    }
                }
            } else {
                BigButton("Open lecture ↗", {
                    CustomTabsIntent.Builder().build().launchUrl(ctx, Uri.parse(v.url))
                })
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Helpful?", color = TextLo)
                Text("👍", fontSize = 26.sp, modifier = Modifier.pressable { vm.rateVideo(v.title, 1) }.padding(6.dp))
                Text("👎", fontSize = 26.sp, modifier = Modifier.pressable { vm.rateVideo(v.title, -1) }.padding(6.dp))
                if (t.videos.size > 1) {
                    Spacer(Modifier.weight(1f))
                    Text("Try another explanation", color = Teal, fontWeight = FontWeight.Bold,
                        modifier = Modifier.pressable { which = (which + 1) % t.videos.size }.padding(6.dp))
                }
            }
        }
        BigButton("I'm done, quiz me", onNext)
    }
}
