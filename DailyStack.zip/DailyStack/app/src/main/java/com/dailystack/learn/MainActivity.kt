package com.dailystack.learn

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.dailystack.learn.ui.*
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val clear = android.graphics.Color.TRANSPARENT
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(clear, clear),
            navigationBarStyle = SystemBarStyle.light(clear, clear)
        )
        setContent { DailyTheme { App() } }
    }
}

@Composable
fun App(vm: AppViewModel = viewModel()) {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        Reminders.schedule(ctx, vm.progress.value.reminderHour)
        if (Build.VERSION.SDK_INT >= 33) launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    LaunchedEffect(lifecycle) {
        lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            while (true) { delay(1000); vm.tick() }
        }
    }
    BackHandler(vm.screen == Screen.Onboarding && vm.onboardStep > 0) { vm.onboardStep-- }
    BackHandler(vm.screen != Screen.Main && vm.screen != Screen.Onboarding) {
        if (vm.screen == Screen.Session) vm.exitSession() else vm.screen = Screen.Main
    }
    BackHandler(vm.screen == Screen.Main && vm.tab != Tab.Home) { vm.tab = Tab.Home }
    LaunchedEffect(vm.toast) { if (vm.toast != null) { delay(2200); vm.toast = null } }

    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFFE9E7FF), Bg)))
            .systemBarsPadding()
    ) {
        AnimatedContent(
            targetState = vm.screen,
            transitionSpec = {
                (fadeIn(tween(380)) + scaleIn(initialScale = 0.97f, animationSpec = tween(380))) togetherWith
                    fadeOut(tween(220))
            },
            label = "screen"
        ) { s ->
            when (s) {
                Screen.Onboarding -> OnboardingScreen(vm)
                Screen.Main -> MainShell(vm)
                Screen.Session -> SessionScreen(vm)
                Screen.Hub -> HubScreen(vm)
                Screen.Rewards -> RewardsScreen(vm)
                Screen.Progress -> SubScreen("My Progress", vm) { ProgressContent(vm) }
                Screen.Achievements -> SubScreen("Achievements", vm) { AchievementsContent(vm) }
                Screen.Certificates -> SubScreen("Certificates", vm) { CertificatesContent(vm) }
                Screen.Settings -> SubScreen("Settings", vm) { SettingsContent(vm) }
                Screen.AddCourse -> AddCourseScreen(vm)
            }
        }
        val t = vm.toast
        AnimatedVisibility(
            visible = t != null,
            modifier = Modifier.align(Alignment.TopCenter).padding(top = 12.dp),
            enter = slideInVertically { -it } + fadeIn(),
            exit = slideOutVertically { -it } + fadeOut()
        ) {
            Panel(color = Surf) { Text(t ?: "", color = TextHi) }
        }
        EyeBreakOverlay(vm)
    }
}
