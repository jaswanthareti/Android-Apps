package com.dailystack.learn.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dailystack.learn.*

@Composable
fun SessionScreen(vm: AppViewModel) {
    val s = vm.session ?: return
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("✕", color = TextLo, fontSize = 22.sp, modifier = Modifier.pressable { vm.exitSession() }.padding(8.dp))
            val prog by animateFloatAsState(
                s.idx.toFloat() / (s.steps.size - 1).coerceAtLeast(1),
                spring(stiffness = Spring.StiffnessLow), label = "prog"
            )
            LinearProgressIndicator(
                progress = { prog },
                modifier = Modifier.weight(1f).height(8.dp).clip(RoundedCornerShape(4.dp)),
                color = Accent, trackColor = Surf2
            )
            Text(s.topic.emoji, fontSize = 22.sp)
        }
        AnimatedContent(
            targetState = s.idx,
            transitionSpec = {
                (slideInHorizontally(spring(stiffness = Spring.StiffnessMediumLow)) { it / 3 } + fadeIn(tween(300))) togetherWith
                    (slideOutHorizontally(tween(250)) { -it / 3 } + fadeOut(tween(200)))
            },
            label = "step"
        ) { idx ->
            when (val st = s.steps.getOrNull(idx)) {
                is Step.Review -> QuizList("Review", st.qs, vm::recordAnswer) { vm.advance() }
                is Step.Check -> QuizList("Check yourself", st.qs, vm::recordAnswer) { all -> vm.onCheckFinished(all) }
                Step.Learn -> LessonStep(s.topic) { vm.advance() }
                Step.Watch -> WatchStep(s.topic, vm.eyeBreak, vm) { vm.advance() }
                is Step.Bug -> BugStep(st.b, vm::recordPractice) { vm.advance() }
                is Step.AiRev -> AiReviewStep(st.r, vm::recordPractice) { vm.advance() }
                is Step.Prompt -> PromptStep(st.p, vm::recordPractice) { vm.advance() }
                Step.Done -> DoneStep(vm)
                null -> Unit
            }
        }
    }
}

@Composable
private fun Scroll(content: @Composable ColumnScope.() -> Unit) =
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp), content = content
    )

@Composable
private fun OptionRow(text: String, state: Int, enabled: Boolean, onClick: () -> Unit) {
    // state: 0 neutral, 1 correct, 2 wrong pick, 3 dimmed
    val bg by animateColorAsState(
        when (state) { 1 -> Good.copy(alpha = .22f); 2 -> Bad.copy(alpha = .22f); else -> Surf }, tween(300), label = "opt"
    )
    Row(
        Modifier.fillMaxWidth().pressable(enabled, onClick).clip(RoundedCornerShape(18.dp)).background(bg).padding(16.dp)
    ) { Text(text, color = if (state == 3) TextLo else TextHi, fontSize = 16.sp) }
}

@Composable
private fun Explain(ok: Boolean, text: String, onNext: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Panel(color = Surf2) { Text((if (ok) "✅ Correct. " else "❌ Not quite. ") + text, color = TextHi) }
        BigButton("Continue", onNext)
    }
}

// ---------- quiz (review + check) ----------
@Composable
fun QuizList(title: String, qs: List<Question>, onResult: (Question, Boolean) -> Unit, onFinished: (Boolean) -> Unit) {
    if (qs.isEmpty()) { LaunchedEffect(Unit) { onFinished(true) }; return }
    var i by remember(qs) { mutableIntStateOf(0) }
    var correct by remember(qs) { mutableIntStateOf(0) }
    AnimatedContent(
        i,
        transitionSpec = { (slideInHorizontally { it / 3 } + fadeIn()) togetherWith (slideOutHorizontally { -it / 3 } + fadeOut()) },
        label = "q"
    ) { idx ->
        val q = qs[idx]
        var sel by remember(q.id) { mutableStateOf<Int?>(null) }
        Scroll {
            Text("$title · ${idx + 1}/${qs.size}", color = TextLo, fontSize = 13.sp)
            Text(q.q, color = TextHi, fontSize = 22.sp, fontWeight = FontWeight.Bold, lineHeight = 30.sp)
            q.options.forEachIndexed { oi, opt ->
                val st = when { sel == null -> 0; oi == q.answer -> 1; oi == sel -> 2; else -> 3 }
                OptionRow(opt, st, sel == null) {
                    sel = oi
                    val ok = oi == q.answer
                    if (ok) correct++
                    onResult(q, ok)
                }
            }
            AnimatedVisibility(sel != null, enter = fadeIn() + expandVertically()) {
                Explain(sel == q.answer, q.why) {
                    if (idx + 1 < qs.size) i = idx + 1 else onFinished(correct == qs.size)
                }
            }
        }
    }
}

// ---------- lesson ----------
@Composable
private fun LessonStep(t: Topic, onNext: () -> Unit) = Scroll {
    Reveal(0) { Text("${t.emoji} ${t.title}", color = TextHi, fontSize = 26.sp, fontWeight = FontWeight.Bold) }
    Reveal(100) { Panel { Label("What it is"); Text(t.what, color = TextHi) } }
    Reveal(200) { Panel { Label("Why it matters when AI writes the code"); Text(t.why, color = TextHi) } }
    Reveal(300) {
        Panel { Label("The essentials"); t.core.forEach { Text("• $it", color = TextHi) } }
    }
    Reveal(400) {
        Panel(color = Color(0x33FFB020)) {
            Label("Where AI usually goes wrong"); t.aiPitfalls.forEach { Text("• $it", color = TextHi) }
        }
    }
    Reveal(500) { BigButton("Next: watch  ▶", onNext) }
}

// ---------- spot the bug ----------
@Composable
private fun BugStep(b: BugHunt, onAnswered: (Boolean) -> Unit, onNext: () -> Unit) {
    var sel by remember(b.id) { mutableStateOf<Int?>(null) }
    var revealed by remember(b.id) { mutableStateOf(false) }
    Scroll {
        Text("🐞 Spot the bug", color = TextHi, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text(b.title, color = TextLo)
        Panel(color = Color(0xFF0B0E13)) {
            b.code.forEachIndexed { i, line ->
                val bg by animateColorAsState(
                    when {
                        revealed && i == b.buggyLine -> Good.copy(alpha = .25f)
                        revealed && i == sel -> Bad.copy(alpha = .25f)
                        i == sel -> Accent.copy(alpha = .25f)
                        else -> Color.Transparent
                    }, tween(250), label = "line"
                )
                Text(
                    line, fontFamily = FontFamily.Monospace, fontSize = 14.sp, color = TextHi,
                    modifier = Modifier.fillMaxWidth().pressable(!revealed) { sel = i }
                        .clip(RoundedCornerShape(8.dp)).background(bg).padding(horizontal = 8.dp, vertical = 6.dp)
                )
            }
        }
        AnimatedVisibility(!revealed) {
            BigButton("Check", { revealed = true; onAnswered(sel == b.buggyLine) }, enabled = sel != null)
        }
        AnimatedVisibility(revealed, enter = fadeIn() + expandVertically()) {
            Explain(sel == b.buggyLine, b.explanation, onNext)
        }
    }
}

// ---------- review AI output ----------
@Composable
private fun AiReviewStep(r: AiReview, onAnswered: (Boolean) -> Unit, onNext: () -> Unit) {
    var sel by remember(r.id) { mutableStateOf<String?>(null) }
    val opts = listOf("correct" to "✅ Looks right", "subtle" to "⚠️ Subtly wrong", "insecure" to "🔓 Insecure")
    Scroll {
        Text("🤖 Review the AI's work", color = TextHi, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Panel { Label("Your prompt"); Text(r.prompt, color = TextHi) }
        Panel(color = Color(0xFF0B0E13)) {
            r.code.forEach { Text(it, fontFamily = FontFamily.Monospace, fontSize = 14.sp, color = TextHi) }
        }
        Text("What's your verdict?", color = TextLo)
        opts.forEach { (key, label) ->
            val st = when { sel == null -> 0; key == r.verdict -> 1; key == sel -> 2; else -> 3 }
            OptionRow(label, st, sel == null) { sel = key; onAnswered(key == r.verdict) }
        }
        AnimatedVisibility(sel != null, enter = fadeIn() + expandVertically()) {
            Explain(sel == r.verdict, r.explanation, onNext)
        }
    }
}

// ---------- write the prompt ----------
@Composable
private fun PromptStep(p: PromptChallenge, onAnswered: (Boolean) -> Unit, onNext: () -> Unit) {
    var sel by remember(p.id) { mutableStateOf<Int?>(null) }
    Scroll {
        Text("✍️ Pick the best prompt", color = TextHi, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Panel { Label("Goal"); Text(p.goal, color = TextHi) }
        p.options.forEachIndexed { i, o ->
            val st = when { sel == null -> 0; o.good -> 1; i == sel -> 2; else -> 3 }
            OptionRow("“${o.text}”", st, sel == null) { sel = i; onAnswered(o.good) }
        }
        AnimatedVisibility(sel != null, enter = fadeIn() + expandVertically()) {
            val o = p.options[sel ?: 0]
            Explain(o.good, o.feedback, onNext)
        }
    }
}

// ---------- done ----------
@Composable
private fun DoneStep(vm: AppViewModel) {
    val p by vm.progress.collectAsState()
    LaunchedEffect(Unit) { vm.completeSession() }
    var pop by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { pop = true }
    val sc by animateFloatAsState(if (pop) 1f else 0f, spring(dampingRatio = 0.4f, stiffness = 200f), label = "pop")
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(18.dp, Alignment.CenterVertically)
    ) {
        Text("🎉", fontSize = 84.sp, modifier = Modifier.graphicsLayerScale(sc))
        Text("Session complete", color = TextHi, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text(
            "🔥 ${p.streak}-day streak   ·   ⭐ ${p.xpToday} XP today",
            color = TextLo, fontSize = 16.sp, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(12.dp))
        BigButton("Back home", { vm.exitSession() })
    }
}

private fun Modifier.graphicsLayerScale(s: Float): Modifier =
    this.then(Modifier.graphicsLayer { scaleX = s; scaleY = s })
