package com.dailystack.learn.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dailystack.learn.*

@Composable
fun HomeScreen(vm: AppViewModel) {
    val p by vm.progress.collectAsState()
    val next = vm.nextTopic()
    var settings by remember { mutableStateOf(false) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Reveal(0) { Header(p, vm, onSettings = { settings = true }) } }
        item { Reveal(80) { TodayCard(p, next, vm) } }
        item { Reveal(160) { StatsRow(p) } }
        item { Text("Your path", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = TextHi) }
        vm.content.weeks.forEachIndexed { i, w ->
            item(key = "week${w.id}") { Reveal(200 + i * 70) { WeekBlock(w, p, next) } }
        }
        item { Spacer(Modifier.height(40.dp)) }
    }
    if (settings) SettingsDialog(p, vm) { settings = false }
}

@Composable
private fun Header(p: Progress, vm: AppViewModel, onSettings: () -> Unit) {
    val lp by animateFloatAsState(vm.levelProgress(), tween(900, easing = FastOutSlowInEasing), label = "xp")
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Level ${vm.level()}", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = TextHi)
            LinearProgressIndicator(
                progress = { lp },
                modifier = Modifier.fillMaxWidth(0.8f).height(8.dp).clip(RoundedCornerShape(4.dp)),
                color = Accent, trackColor = Surf2
            )
            Text("${p.totalXp} XP total", color = TextLo, fontSize = 13.sp)
        }
        Text("🎁", fontSize = 26.sp, modifier = Modifier.pressable { vm.screen = Screen.Rewards }.padding(10.dp))
        Text("⚙️", fontSize = 26.sp, modifier = Modifier.pressable(onClick = onSettings).padding(10.dp))
    }
}

@Composable
private fun TodayCard(p: Progress, next: Topic?, vm: AppViewModel) {
    val due = vm.dueQuestions().size
    Panel {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Ring(p.xpToday / 100f, 84.dp, 9.dp, Teal) {
                Text("${p.xpToday}", color = TextHi, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            }
            Column(Modifier.weight(1f)) {
                Label("Today · Day ${vm.dayNumber()} of ${vm.totalDays()}")
                if (next != null) {
                    Text("${next.emoji} ${next.title}", color = TextHi, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(
                        if (due > 0) "$due review card${if (due > 1) "s" else ""} due first" else "Daily goal: 100 XP",
                        color = TextLo, fontSize = 13.sp
                    )
                } else Text("All current content finished 🎉", color = TextHi, fontSize = 18.sp)
            }
        }
        if (next != null) BigButton("Start today's session  ▶", { vm.startSession() })
    }
}

@Composable
private fun StatsRow(p: Progress) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Stat("🔥", "${p.streak}", "day streak", Modifier.weight(1f))
        Stat("❄️", "${p.freezes}", "freezes", Modifier.weight(1f))
        Stat("👀", "${p.eyeBreaks}", "eye breaks", Modifier.weight(1f))
    }
}

@Composable
private fun Stat(icon: String, big: String, small: String, modifier: Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(20.dp)).background(Surf).padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(icon, fontSize = 22.sp)
        Text(big, color = TextHi, fontWeight = FontWeight.Bold, fontSize = 22.sp)
        Text(small, color = TextLo, fontSize = 12.sp)
    }
}

@Composable
private fun WeekBlock(w: Week, p: Progress, next: Topic?) {
    Panel {
        Label("Week ${w.id}")
        Text(w.title, color = TextHi, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        if (w.topics.isEmpty()) Text("Coming soon", color = TextLo)
        w.topics.forEach { t ->
            val status = when {
                t.id in p.doneTopics -> "✅"
                t.id == next?.id -> "▶️"
                else -> "🔒"
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(status, fontSize = 18.sp)
                Text("${t.emoji} ${t.title}", color = if (status == "🔒") TextLo else TextHi, fontSize = 16.sp)
            }
        }
    }
}
