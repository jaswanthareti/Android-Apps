package com.dailystack.learn.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dailystack.learn.*
import java.time.LocalTime

@Composable
fun HomeScreen(vm: AppViewModel) {
    val p by vm.progress.collectAsState()
    val course = vm.activeCourse()
    val today = vm.todayTopic()

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Reveal(0) { Greeting(p) } }
        item { Reveal(60) { LevelCard(p, vm) } }
        item { Reveal(120) { ContinueCard(course, today, vm) } }
        item { Reveal(180) { StatsRow(p) } }
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Your learning path", color = TextHi, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text("View all", color = Accent, fontWeight = FontWeight.SemiBold, modifier = Modifier.pressable { vm.tab = Tab.Learn }.padding(6.dp))
            }
        }
        item { Reveal(240) { CurrentWeekCard(course, p, today, vm) } }
    }
}

@Composable
private fun Greeting(p: Progress) {
    val h = LocalTime.now().hour
    val hello = if (h < 12) "Good morning" else if (h < 18) "Good afternoon" else "Good evening"
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(Modifier.size(56.dp).clip(CircleShape).background(Surf2), contentAlignment = Alignment.Center) { Penguin(46.dp) }
        Column(Modifier.weight(1f)) {
            Text("$hello, ${p.name}! 👋", color = TextHi, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(if (p.goal.isNotBlank()) "Goal: ${p.goal}" else "Ready to grow today?", color = TextLo, fontSize = 13.sp)
        }
    }
}

@Composable
private fun LevelCard(p: Progress, vm: AppViewModel) {
    Panel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("👑 Level ${vm.level()} · ${vm.levelName()}", color = TextHi, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text("${vm.xpInLevel()} / 250 XP", color = TextLo, fontSize = 13.sp)
        }
        Bar(vm.levelProgress())
        Text("${250 - vm.xpInLevel()} XP to reach Level ${vm.level() + 1}", color = TextLo, fontSize = 12.sp)
    }
}

@Composable
private fun ContinueCard(course: Course, today: Topic?, vm: AppViewModel) {
    val total = vm.courseTopics(course).size.coerceAtLeast(1)
    val done = vm.courseDoneCount(course)
    val doneToday = vm.isTodayDone()
    val shape = RoundedCornerShape(28.dp)
    Box(
        Modifier.fillMaxWidth().shadow(6.dp, shape, ambientColor = Color(0x446C5CE7), spotColor = Color(0x446C5CE7))
            .clip(shape).background(Brush.linearGradient(listOf(Color(0xFF6C5CE7), Color(0xFF9A8BF5)))).padding(20.dp)
    ) {
        Column(Modifier.fillMaxWidth(0.66f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Continue learning", color = Color.White.copy(alpha = .8f), fontSize = 12.sp)
            Text("${course.emoji} ${course.title}", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            if (today != null) Text("Week ${vm.weekOf(today)} · Day ${vm.dayOf(today)} of ${vm.totalDays()}", color = Color.White.copy(alpha = .9f), fontSize = 13.sp)
            else Text("All days complete 🎉", color = Color.White, fontSize = 13.sp)
            Bar(done / total.toFloat(), color = Color.White, track = Color.White.copy(alpha = .3f))
            Text("${done * 100 / total}% complete", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            if (today != null) {
                Box(
                    Modifier.pressable { vm.openHub(today) }.clip(RoundedCornerShape(50)).background(Color.White)
                        .padding(horizontal = 18.dp, vertical = 10.dp)
                ) { Text(if (doneToday) "Review today's lesson" else "▶ Open today's lesson", color = Accent, fontWeight = FontWeight.Bold) }
                if (doneToday) Text("Day ${vm.dayOf(today) + 1} unlocks tomorrow", color = Color.White.copy(alpha = .85f), fontSize = 12.sp)
            }
        }
        Penguin(118.dp, Modifier.align(Alignment.CenterEnd))
    }
}

@Composable
private fun StatsRow(p: Progress) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Stat("🔥", "${p.streak}", "day streak", Modifier.weight(1f))
        Stat("📖", "${p.doneTopics.size}", "lessons done", Modifier.weight(1f))
        Stat("⭐", "${p.totalXp}", "total XP", Modifier.weight(1f))
    }
}

@Composable
fun Stat(icon: String, big: String, small: String, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier.shadow(2.dp, shape, ambientColor = Color(0x226C5CE7), spotColor = Color(0x226C5CE7)).clip(shape).background(Color.White).padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(icon, fontSize = 22.sp)
        Text(big, color = TextHi, fontWeight = FontWeight.Bold, fontSize = 22.sp)
        Text(small, color = TextLo, fontSize = 12.sp)
    }
}

@Composable
private fun CurrentWeekCard(course: Course, p: Progress, today: Topic?, vm: AppViewModel) {
    val week = course.weeks.firstOrNull { w -> today != null && w.topics.any { it.id == today.id } } ?: course.weeks.lastOrNull() ?: return
    val done = week.topics.count { it.id in p.doneTopics }
    Panel(Modifier.pressable { vm.tab = Tab.Learn }) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Box(Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(Surf2), contentAlignment = Alignment.Center) {
                Text(week.topics.firstOrNull()?.emoji ?: "📘", fontSize = 24.sp)
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Label("Week ${week.id}")
                Text(week.title, color = TextHi, fontWeight = FontWeight.Bold)
                Text("$done of ${week.topics.size} lessons", color = TextLo, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    week.topics.forEach { t ->
                        Box(Modifier.size(8.dp).clip(CircleShape).background(if (t.id in p.doneTopics) Good else Surf2))
                    }
                }
            }
            Box(Modifier.size(36.dp).clip(CircleShape).background(Accent), contentAlignment = Alignment.Center) {
                Text("›", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
