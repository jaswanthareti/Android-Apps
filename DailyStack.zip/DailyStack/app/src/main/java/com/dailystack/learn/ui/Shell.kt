package com.dailystack.learn.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dailystack.learn.*

@Composable
fun MainShell(vm: AppViewModel) {
    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f)) {
            AnimatedContent(
                targetState = vm.tab,
                transitionSpec = { fadeIn(tween(280)) togetherWith fadeOut(tween(180)) },
                label = "tab"
            ) { tb ->
                when (tb) {
                    Tab.Home -> HomeScreen(vm)
                    Tab.Learn -> LearnScreen(vm)
                    Tab.Practice -> PracticeScreen(vm)
                    Tab.Profile -> ProfileScreen(vm)
                }
            }
        }
        BottomBar(vm)
    }
}

@Composable
private fun BottomBar(vm: AppViewModel) {
    val items = listOf(Tab.Home to ("🏠" to "Home"), Tab.Learn to ("📚" to "Learn"), Tab.Practice to ("🧪" to "Practice"), Tab.Profile to ("👤" to "Profile"))
    Row(
        Modifier.fillMaxWidth().shadow(12.dp, RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
            .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)).background(Color.White)
            .padding(horizontal = 8.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceAround
    ) {
        items.forEach { (tb, il) ->
            val sel = vm.tab == tb
            Column(
                Modifier.weight(1f).pressable { vm.tab = tb }.clip(RoundedCornerShape(16.dp))
                    .background(if (sel) Surf2 else Color.Transparent).padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(il.first, fontSize = 22.sp)
                Text(il.second, fontSize = 12.sp, color = if (sel) Accent else TextLo, fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal)
            }
        }
    }
}

/** Full-screen page with a back arrow, used by Progress, Achievements, Certificates and Settings. */
@Composable
fun SubScreen(title: String, vm: AppViewModel, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize()) {
        TopBar(title) { vm.screen = Screen.Main }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            content()
            Spacer(Modifier.height(24.dp))
        }
    }
}
