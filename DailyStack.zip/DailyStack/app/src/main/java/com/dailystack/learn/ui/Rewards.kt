package com.dailystack.learn.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dailystack.learn.*

@Composable
fun RewardsScreen(vm: AppViewModel) {
    val p by vm.progress.collectAsState()
    var adding by remember { mutableStateOf(false) }
    val bal = p.totalXp - p.spent

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("←", color = TextHi, fontSize = 26.sp,
                    modifier = Modifier.pressable { vm.screen = Screen.Main }.padding(end = 14.dp, top = 8.dp, bottom = 8.dp))
                Text("Rewards", color = TextHi, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            }
        }
        item {
            Reveal(0) {
                Panel {
                    Label("Balance")
                    Text("$bal pts", color = Gold, fontSize = 38.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "Every XP you earn is a point. Rewards are self-funded: when you redeem one, treat yourself or buy the voucher yourself.",
                        color = TextLo, fontSize = 13.sp
                    )
                }
            }
        }
        items(p.rewards) { r ->
            val can = bal >= r.cost
            Panel {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text(r.emoji, fontSize = 30.sp)
                    Column(Modifier.weight(1f)) {
                        Text(r.name, color = TextHi, fontWeight = FontWeight.Bold)
                        Text("${r.cost} pts", color = Gold, fontSize = 13.sp)
                    }
                    Text(
                        "Redeem",
                        color = if (can) Color0 else TextLo, fontWeight = FontWeight.Bold,
                        modifier = Modifier.pressable(can) { vm.redeem(r) }
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (can) Accent else Surf2)
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                    )
                }
            }
        }
        item { BigButton("＋ Add a reward", { adding = true }) }
        if (p.redeemed.isNotEmpty()) {
            item { Label("Redeemed") }
            items(p.redeemed.reversed()) { Text("• $it", color = TextHi) }
        }
    }
    if (adding) AddRewardDialog(vm) { adding = false }
}

private val Color0 = androidx.compose.ui.graphics.Color.White

@Composable
private fun AddRewardDialog(vm: AppViewModel, onClose: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var cost by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = Surf,
        title = { Text("New reward", color = TextHi) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Reward") }, singleLine = true)
                OutlinedTextField(
                    cost, { cost = it.filter(Char::isDigit) }, label = { Text("Cost in points") },
                    singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
            }
        },
        confirmButton = { TextButton({ vm.addReward(name, cost.toIntOrNull() ?: 0); onClose() }) { Text("Add") } },
        dismissButton = { TextButton(onClose) { Text("Cancel") } }
    )
}
