package com.dailystack.learn

import android.content.Context
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("dailystack", Context.MODE_PRIVATE)
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    fun load(): Progress =
        sp.getString("p", null)?.let { runCatching { json.decodeFromString<Progress>(it) }.getOrNull() } ?: Progress()

    fun save(p: Progress) {
        sp.edit().putString("p", json.encodeToString(p)).apply()
    }
}

fun loadContent(ctx: Context): Content {
    val s = ctx.assets.open("content.json").bufferedReader().use { it.readText() }
    return Json { ignoreUnknownKeys = true }.decodeFromString(s)
}
