package com.dailystack.learn

import android.content.Context
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("dailystack", Context.MODE_PRIVATE)
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    fun load(): Progress =
        sp.getString("p", null)?.let { runCatching { json.decodeFromString<Progress>(it) }.getOrNull() } ?: Progress()

    fun save(p: Progress) {
        sp.edit().putString("p", json.encodeToString(p)).apply()
    }
}

private val courseJson = Json { ignoreUnknownKeys = true; encodeDefaults = true }

// Built-in courses come from the assets/courses folder; courses the user added live in files/courses.
fun loadAllCourses(ctx: Context): List<Course> {
    val bundled = (ctx.assets.list("courses") ?: emptyArray()).filter { it.endsWith(".json") }.sorted().mapNotNull {
        runCatching {
            courseJson.decodeFromString<Course>(ctx.assets.open("courses/$it").bufferedReader().use { r -> r.readText() })
        }.getOrNull()
    }
    val dir = File(ctx.filesDir, "courses")
    val user = dir.listFiles { f -> f.extension == "json" }?.sortedBy { it.name }?.mapNotNull {
        runCatching { courseJson.decodeFromString<Course>(it.readText()).copy(builtin = false) }.getOrNull()
    } ?: emptyList()
    return bundled + user
}

fun saveUserCourse(ctx: Context, c: Course) {
    val dir = File(ctx.filesDir, "courses").apply { mkdirs() }
    File(dir, "${c.id}.json").writeText(courseJson.encodeToString(c.copy(builtin = false)))
}

fun deleteUserCourse(ctx: Context, id: String) {
    File(File(ctx.filesDir, "courses"), "$id.json").delete()
}
