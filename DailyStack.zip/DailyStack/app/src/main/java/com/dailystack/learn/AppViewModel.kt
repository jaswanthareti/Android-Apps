package com.dailystack.learn

import android.app.Application
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale
import kotlin.random.Random

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)
    var courses by mutableStateOf(loadAllCourses(app))
        private set
    private val _p = MutableStateFlow(store.load())
    val progress: StateFlow<Progress> = _p

    var screen by mutableStateOf(Screen.Main)
    var tab by mutableStateOf(Tab.Home)
    var session by mutableStateOf<Session?>(null)
    var eyeBreak by mutableStateOf(false)
    var toast by mutableStateOf<String?>(null)
    var hubTopicId by mutableStateOf<String?>(null)
    var onboardStep by mutableIntStateOf(0)
    var lastGain by mutableIntStateOf(0)
    private var activeSec = 0
    private var secInMinute = 0

    private val intervals = intArrayOf(1, 3, 7, 14, 30)
    private val dailyCap = 300

    private fun today() = LocalDate.now().toEpochDay()
    private fun update(f: (Progress) -> Progress) {
        val n = f(_p.value); _p.value = n; store.save(n)
    }

    // ---------- courses ----------
    fun activeCourse(): Course = courses.firstOrNull { it.id == _p.value.activeCourse } ?: courses.first()
    fun courseTopics(c: Course) = c.weeks.flatMap { it.topics }
    private fun allTopics() = courseTopics(activeCourse())
    private fun everyTopic() = courses.flatMap { courseTopics(it) }
    fun courseDoneCount(c: Course) = courseTopics(c).count { it.id in _p.value.doneTopics }
    fun courseDone(c: Course) = courseTopics(c).isNotEmpty() && courseDoneCount(c) == courseTopics(c).size
    fun courseDoneDate(c: Course): Long? =
        if (!courseDone(c)) null
        else courseTopics(c).maxOf { _p.value.completedOn[it.id] ?: 0L }.takeIf { it > 0 } ?: _p.value.lastActiveDay

    fun setActiveCourse(id: String) {
        update { it.copy(activeCourse = id) }
        toast = "Switched to ${activeCourse().title}"
    }

    /** Returns an error message, or null when the course was added. */
    fun importCourse(text: String): String? = addCourse { CourseImport.parse(text, courses.map { it.id }.toSet()) }

    fun importQuickList(title: String, lines: String): String? =
        addCourse { CourseImport.fromQuickList(title, lines, courses.map { it.id }.toSet()) }

    private fun addCourse(build: () -> Course): String? = try {
        val c = build()
        saveUserCourse(getApplication(), c)
        courses = courses + c
        update { it.copy(activeCourse = c.id) }
        toast = "✅ Added \"${c.title}\" (${courseTopics(c).size} days)"
        null
    } catch (e: Exception) {
        e.message ?: "Could not add that course."
    }

    fun removeCourse(id: String) {
        val c = courses.firstOrNull { it.id == id } ?: return
        if (c.builtin) return
        deleteUserCourse(getApplication(), id)
        courses = courses.filter { it.id != id }
        if (_p.value.activeCourse == id) update { it.copy(activeCourse = courses.first().id) }
        toast = "Removed \"${c.title}\""
    }

    // ---------- level / profile ----------
    fun balance() = _p.value.totalXp - _p.value.spent
    fun level() = _p.value.totalXp / 250 + 1
    fun xpInLevel() = _p.value.totalXp % 250
    fun levelProgress() = xpInLevel() / 250f
    fun levelName() = listOf("Explorer", "Builder", "Navigator", "Architect", "Expert")[(level() - 1).coerceAtMost(4)]

    fun setProfile(name: String, goal: String, level: String) =
        update { it.copy(name = name.trim().ifBlank { "Learner" }, goal = goal, level = level) }

    fun finishOnboarding() { update { it.copy(onboarded = true) }; screen = Screen.Main }

    fun resetProgress() {
        update { Progress(name = it.name, goal = it.goal, level = it.level, onboarded = true, activeCourse = it.activeCourse, rewards = it.rewards) }
        session = null; screen = Screen.Main; tab = Tab.Home; toast = "Progress reset"
    }

    // ---------- days: one new day per calendar day ----------
    fun totalDays() = allTopics().size
    fun dayOf(t: Topic) = allTopics().indexOfFirst { it.id == t.id } + 1
    fun weekOf(t: Topic) = activeCourse().weeks.firstOrNull { w -> w.topics.any { it.id == t.id } }?.id ?: 1

    /** Today's topic: the one finished today (so the day does not advance), else the next unfinished topic. */
    fun todayTopic(): Topic? {
        val p = _p.value; val t = today()
        val all = allTopics()
        return all.lastOrNull { p.completedOn[it.id] == t } ?: all.firstOrNull { it.id !in p.doneTopics }
    }
    fun isTodayDone(): Boolean {
        val tt = todayTopic() ?: return false
        return _p.value.completedOn[tt.id] == today()
    }
    fun dayNumber(): Int = todayTopic()?.let { dayOf(it) } ?: totalDays()
    fun isUnlocked(t: Topic) = t.id in _p.value.doneTopics || t.id == todayTopic()?.id
    fun hubTopic(): Topic? = allTopics().firstOrNull { it.id == hubTopicId }
    fun openHub(t: Topic) {
        if (!isUnlocked(t)) { toast = "🔒 Day ${dayOf(t)} unlocks after the days before it, one per calendar day"; return }
        hubTopicId = t.id; screen = Screen.Hub
    }

    private fun allQuestions(): Map<String, Question> = everyTopic().flatMap { it.checks }.associateBy { it.id }

    fun dueQuestions(): List<Question> {
        val all = allQuestions(); val t = today()
        return _p.value.cards.filter { it.value.due <= t }.keys.mapNotNull { all[it] }.take(5)
    }

    // ---------- progress views ----------
    fun last7(): List<DayBar> {
        val t = today(); val h = _p.value.history
        return (6 downTo 0).map { off ->
            val d = t - off
            DayBar(LocalDate.ofEpochDay(d).dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault()).take(3), h[d.toString()] ?: 0, off == 0)
        }
    }

    fun badges(): List<Badge> {
        val p = _p.value; val lessons = p.doneTopics.size
        return listOf(
            Badge("🌱", "First Lesson", "Complete your first day", lessons >= 1),
            Badge("🔥", "3 Day Streak", "Learn 3 days in a row", p.best >= 3),
            Badge("⚡", "7 Day Streak", "Keep going for a week", p.best >= 7),
            Badge("📚", "Five Days In", "Complete 5 days", lessons >= 5),
            Badge("🏔️", "Ten Days Strong", "Complete 10 days", lessons >= 10),
            Badge("👀", "Eye Guardian", "Take 10 eye breaks", p.eyeBreaks >= 10),
            Badge("⭐", "1,000 XP", "Earn 1,000 XP", p.totalXp >= 1000),
            Badge("🎓", "Course Complete", "Finish a whole course", courses.any { courseDone(it) }),
            Badge("🏆", "30 Day Streak", "A month of learning", p.best >= 30)
        )
    }

    // ---------- streak / xp ----------
    private fun markActive() {
        val t = today()
        if (_p.value.lastActiveDay == t) return
        update { q ->
            var streak = q.streak; var freezes = q.freezes
            if (q.lastActiveDay < 0) streak = 1
            else {
                val gap = (t - q.lastActiveDay).toInt()
                if (gap == 1) streak += 1
                else {
                    val missed = gap - 1
                    if (missed <= freezes) { freezes -= missed; streak += 1 } else streak = 1
                }
            }
            q.copy(streak = streak, best = maxOf(q.best, streak), freezes = freezes, lastActiveDay = t)
        }
    }

    private fun awardXp(base: Int, bonusChance: Boolean = false) {
        val t = today()
        update { p ->
            val q = if (p.xpDay != t) p.copy(xpDay = t, xpToday = 0) else p
            val room = (dailyCap - q.xpToday).coerceAtLeast(0)
            var gain = minOf(base, room)
            if (bonusChance && gain > 0 && Random.nextFloat() < 0.15f) {
                gain = minOf(gain + 5, room); toast = "⚡ Bonus +5 XP!"
            }
            val key = t.toString()
            q.copy(
                totalXp = q.totalXp + gain, xpToday = q.xpToday + gain,
                history = (q.history + (key to ((q.history[key] ?: 0) + gain))).filterKeys { (it.toLongOrNull() ?: 0L) >= t - 60 }
            )
        }
    }

    fun recordAnswer(q: Question, correct: Boolean) {
        markActive()
        val t = today()
        update { p ->
            val c = p.cards[q.id] ?: SrsCard()
            val nb = if (correct) (c.box + 1).coerceAtMost(4) else 0
            p.copy(cards = p.cards + (q.id to SrsCard(nb, t + intervals[nb])))
        }
        awardXp(if (correct) 10 else 2, correct)
    }

    fun recordPractice(correct: Boolean) {
        markActive(); awardXp(if (correct) 15 else 3, correct)
    }

    // ---------- sessions ----------
    fun startSession(topic: Topic? = null) {
        val t = topic ?: todayTopic() ?: run { toast = "You've finished all current content 🎉"; return }
        if (!isUnlocked(t)) { toast = "🔒 Not unlocked yet"; return }
        val due = dueQuestions()
        val steps = buildList<Step> {
            if (due.isNotEmpty()) add(Step.Review(due))
            add(Step.Check(t.checks)); add(Step.Done)
        }
        session = Session(t, steps, 0); screen = Screen.Session; activeSec = 0
    }

    /** kind: quiz | lab | scenario | exam. Draws from the days you have unlocked in the active course. */
    fun poolCounts(): List<Int> {
        val pool = allTopics().filter { isUnlocked(it) }
        return listOf(pool.sumOf { it.checks.size }, pool.sumOf { it.bugs.size }, pool.sumOf { it.prompts.size }, pool.sumOf { it.aiReviews.size })
    }

    fun startPractice(kind: String) {
        val pool = allTopics().filter { isUnlocked(it) }
        val steps: List<Step> = when (kind) {
            "quiz" -> pool.flatMap { it.checks }.shuffled().take(5).let { if (it.isEmpty()) emptyList() else listOf(Step.Review(it)) }
            "lab" -> pool.flatMap { it.bugs }.shuffled().take(3).map { Step.Bug(it) }
            "scenario" -> pool.flatMap { it.prompts }.shuffled().take(3).map { Step.Prompt(it) }
            else -> pool.flatMap { it.aiReviews }.shuffled().take(3).map { Step.AiRev(it) }
        }
        if (steps.isEmpty()) { toast = "Open a day first, then practice it here"; return }
        val (emoji, title) = when (kind) {
            "quiz" -> "📝" to "Quick Quiz"; "lab" -> "🐞" to "Code Lab"
            "scenario" -> "🎯" to "Scenario Challenge"; else -> "🤖" to "Exam Style Questions"
        }
        session = Session(Topic(id = "practice:$kind", title = title, emoji = emoji), steps + Step.Done, 0)
        screen = Screen.Session; activeSec = 0
    }

    fun advance() {
        val s = session ?: return
        if (s.idx < s.steps.lastIndex) session = s.copy(idx = s.idx + 1)
    }

    fun onCheckFinished(allCorrect: Boolean) {
        val s = session ?: return
        val t = s.topic
        val skip = allCorrect && t.checks.isNotEmpty()
        if (skip) toast = "🎯 You already know this. Jumping to practice!"
        val mid = buildList<Step> {
            if (!skip) { add(Step.Learn); add(Step.Watch) }
            t.bugs.take(2).forEach { add(Step.Bug(it)) }
            t.aiReviews.take(2).forEach { add(Step.AiRev(it)) }
            t.prompts.take(1).forEach { add(Step.Prompt(it)) }
        }
        session = s.copy(steps = s.steps.take(s.idx + 1) + mid + s.steps.drop(s.idx + 1), idx = s.idx + 1)
    }

    fun completeSession() {
        val s = session ?: return
        if (s.completed) return
        session = s.copy(completed = true)
        if (s.topic.id.startsWith("practice:")) { lastGain = 15; awardXp(15); return }
        val first = s.topic.id !in _p.value.doneTopics
        val t = today()
        update { p ->
            var f = p.freezes
            if (first && p.streak > 0 && p.streak % 7 == 0 && f < 2) f++
            p.copy(
                doneTopics = (p.doneTopics + s.topic.id).distinct(),
                completedOn = if (first) p.completedOn + (s.topic.id to t) else p.completedOn,
                freezes = f
            )
        }
        lastGain = if (first) 50 else 10
        awardXp(lastGain)
    }

    fun exitSession() { session = null; screen = Screen.Main; eyeBreak = false }

    // ---------- eye breaks + learning time ----------
    fun tick() {
        val s = session ?: return
        if (eyeBreak || s.steps.getOrNull(s.idx) == Step.Done) return
        activeSec++
        secInMinute++
        if (secInMinute >= 60) { secInMinute = 0; update { it.copy(minutes = it.minutes + 1) } }
        if (activeSec >= _p.value.eyeMinutes * 60) { activeSec = 0; eyeBreak = true }
    }

    fun finishEyeBreak(completed: Boolean) {
        eyeBreak = false
        update { if (completed) it.copy(eyeBreaks = it.eyeBreaks + 1) else it.copy(eyeSkips = it.eyeSkips + 1) }
        if (completed) { awardXp(5); toast = "👀 Eyes rested +5 XP" }
    }

    // ---------- misc ----------
    fun rateVideo(key: String, v: Int) = update { it.copy(ratings = it.ratings + (key to v)) }

    fun redeem(r: Reward) {
        if (balance() < r.cost) return
        update { it.copy(spent = it.spent + r.cost, redeemed = it.redeemed + "${r.emoji} ${r.name}") }
        toast = "🎉 Enjoy: ${r.name}"
    }

    fun addReward(name: String, cost: Int) {
        if (name.isBlank() || cost <= 0) return
        update { it.copy(rewards = it.rewards + Reward(name.trim(), cost)) }
    }

    fun saveSettings(hour: Int, eyeMin: Int) {
        update { it.copy(reminderHour = hour, eyeMinutes = eyeMin) }
        Reminders.schedule(getApplication(), hour)
    }

    init {
        val p = _p.value
        // Older saves: the last finished topic counts as finished on the last active day.
        if (p.completedOn.isEmpty() && p.doneTopics.isNotEmpty()) {
            val last = everyTopic().lastOrNull { it.id in p.doneTopics }
            if (last != null) update { it.copy(completedOn = mapOf(last.id to (if (p.lastActiveDay >= 0) p.lastActiveDay else today()))) }
        }
        // Existing learners skip onboarding.
        if (!_p.value.onboarded && (_p.value.doneTopics.isNotEmpty() || _p.value.lastActiveDay >= 0)) update { it.copy(onboarded = true) }
        screen = if (_p.value.onboarded) Screen.Main else Screen.Onboarding
    }
}
