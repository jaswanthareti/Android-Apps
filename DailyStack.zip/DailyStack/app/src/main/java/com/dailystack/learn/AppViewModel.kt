package com.dailystack.learn

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.time.LocalDate
import kotlin.random.Random

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)
    val content: Content = loadContent(app)
    private val _p = MutableStateFlow(store.load())
    val progress: StateFlow<Progress> = _p

    var screen by mutableStateOf(Screen.Home)
    var session by mutableStateOf<Session?>(null)
    var eyeBreak by mutableStateOf(false)
    var toast by mutableStateOf<String?>(null)
    private var activeSec = 0

    private val intervals = intArrayOf(1, 3, 7, 14, 30)
    private val dailyCap = 300

    private fun today() = LocalDate.now().toEpochDay()
    private fun update(f: (Progress) -> Progress) {
        val n = f(_p.value); _p.value = n; store.save(n)
    }

    fun balance() = _p.value.totalXp - _p.value.spent
    fun level() = _p.value.totalXp / 250 + 1
    fun levelProgress() = (_p.value.totalXp % 250) / 250f

    fun nextTopic(): Topic? =
        content.weeks.flatMap { it.topics }.firstOrNull { it.id !in _p.value.doneTopics }

    private fun allQuestions(): Map<String, Question> =
        content.weeks.flatMap { it.topics }.flatMap { it.checks }.associateBy { it.id }

    fun dueQuestions(): List<Question> {
        val all = allQuestions(); val t = today()
        return _p.value.cards.filter { it.value.due <= t }.keys.mapNotNull { all[it] }.take(5)
    }

    // ---- streak / xp ----
    private fun markActive() {
        val t = today()
        if (_p.value.lastActiveDay == t) return
        update { q ->
            var streak = q.streak; var freezes = q.freezes
            if (q.lastActiveDay < 0) streak = 1
            else {
                val gap = (t - q.lastActiveDay).toInt()
                if (gap == 1) streak += 1
                else {
                    val missed = gap - 1
                    if (missed <= freezes) { freezes -= missed; streak += 1 } else streak = 1
                }
            }
            q.copy(streak = streak, best = maxOf(q.best, streak), freezes = freezes, lastActiveDay = t)
        }
    }

    private fun awardXp(base: Int, bonusChance: Boolean = false) {
        val t = today()
        update { p ->
            val q = if (p.xpDay != t) p.copy(xpDay = t, xpToday = 0) else p
            val room = (dailyCap - q.xpToday).coerceAtLeast(0)
            var gain = minOf(base, room)
            if (bonusChance && gain > 0 && Random.nextFloat() < 0.15f) {
                gain = minOf(gain + 5, room); toast = "⚡ Bonus +5 XP!"
            }
            q.copy(totalXp = q.totalXp + gain, xpToday = q.xpToday + gain)
        }
    }

    fun recordAnswer(q: Question, correct: Boolean) {
        markActive()
        val t = today()
        update { p ->
            val c = p.cards[q.id] ?: SrsCard()
            val nb = if (correct) (c.box + 1).coerceAtMost(4) else 0
            p.copy(cards = p.cards + (q.id to SrsCard(nb, t + intervals[nb])))
        }
        awardXp(if (correct) 10 else 2, correct)
    }

    fun recordPractice(correct: Boolean) {
        markActive(); awardXp(if (correct) 15 else 3, correct)
    }

    // ---- session flow ----
    fun startSession() {
        val t = nextTopic() ?: run { toast = "You've finished all current content 🎉"; return }
        val due = dueQuestions()
        val steps = buildList<Step> {
            if (due.isNotEmpty()) add(Step.Review(due))
            add(Step.Check(t.checks)); add(Step.Done)
        }
        session = Session(t, steps, 0); screen = Screen.Session; activeSec = 0
    }

    fun advance() {
        val s = session ?: return
        if (s.idx < s.steps.lastIndex) session = s.copy(idx = s.idx + 1)
    }

    fun onCheckFinished(allCorrect: Boolean) {
        val s = session ?: return
        val t = s.topic
        val skip = allCorrect && t.checks.isNotEmpty()
        if (skip) toast = "🎯 You already know this. Jumping to practice!"
        val mid = buildList<Step> {
            if (!skip) { add(Step.Learn); add(Step.Watch) }
            t.bugs.take(2).forEach { add(Step.Bug(it)) }
            t.aiReviews.take(2).forEach { add(Step.AiRev(it)) }
            t.prompts.take(1).forEach { add(Step.Prompt(it)) }
        }
        session = s.copy(steps = s.steps.take(s.idx + 1) + mid + s.steps.drop(s.idx + 1), idx = s.idx + 1)
    }

    fun completeSession() {
        val s = session ?: return
        if (s.completed) return
        session = s.copy(completed = true)
        update { p ->
            var f = p.freezes
            if (p.streak > 0 && p.streak % 7 == 0 && f < 2) f++
            p.copy(doneTopics = (p.doneTopics + s.topic.id).distinct(), freezes = f)
        }
        awardXp(50)
    }

    fun exitSession() { session = null; screen = Screen.Home; eyeBreak = false }

    // ---- eye breaks ----
    fun tick() {
        val s = session ?: return
        if (eyeBreak || s.steps.getOrNull(s.idx) == Step.Done) return
        activeSec++
        if (activeSec >= _p.value.eyeMinutes * 60) { activeSec = 0; eyeBreak = true }
    }

    fun finishEyeBreak(completed: Boolean) {
        eyeBreak = false
        update { if (completed) it.copy(eyeBreaks = it.eyeBreaks + 1) else it.copy(eyeSkips = it.eyeSkips + 1) }
        if (completed) { awardXp(5); toast = "👀 Eyes rested +5 XP" }
    }

    // ---- misc ----
    fun rateVideo(key: String, v: Int) = update { it.copy(ratings = it.ratings + (key to v)) }

    fun redeem(r: Reward) {
        if (balance() < r.cost) return
        update { it.copy(spent = it.spent + r.cost, redeemed = it.redeemed + "${r.emoji} ${r.name}") }
        toast = "🎉 Enjoy: ${r.name}"
    }

    fun addReward(name: String, cost: Int) {
        if (name.isBlank() || cost <= 0) return
        update { it.copy(rewards = it.rewards + Reward(name.trim(), cost)) }
    }

    fun saveSettings(hour: Int, eyeMin: Int) {
        update { it.copy(reminderHour = hour, eyeMinutes = eyeMin) }
        Reminders.schedule(getApplication(), hour)
    }
}
