from part0 import *

cfn = T("cfn", "🧱", "CloudFormation: stacks, change sets & drift",
 "CloudFormation creates AWS resources from a template. A stack is the set of resources created from one template, and deleting the stack deletes them.",
 "Almost every AI infrastructure tool ends up as CloudFormation underneath. Reading a change set is how you catch a destructive update.",
 ["Use change sets to preview updates. Watch for Replacement: True, which deletes and recreates a resource (data loss for databases).",
  "Renaming a logical ID makes CloudFormation create a new resource and delete the old one.",
  "Use DeletionPolicy: Retain or Snapshot for stateful resources.",
  "Drift detection finds manual console changes that differ from the template."],
 ["AI renames resources to 'tidy up', causing replacement.", "AI omits DeletionPolicy on databases.", "AI suggests console edits that cause drift."],
 V(fcc="Management and Developer Tools: Infrastructure as Code, CloudFormation and its Follow Along.", uq="aws cloudformation", yq="CloudFormation change set drift detection tutorial"),
 [("What previews a CloudFormation update?", ["A change set", "A console refresh", "CloudTrail", "A tag"], 0, "Change sets list what will be added, modified or replaced."),
  ("Which change-set result is a danger sign for a database?", ["Modify with no replacement", "Replacement", "Tag change", "Description change"], 1, "Replacement deletes the old resource and its data."),
  ("What does drift detection find?", ["Cost overruns", "Differences between live resources and the template", "Syntax errors", "Slow Lambdas"], 1, "It compares live state with the template.")],
 ("Production database", r'''
Database:
  Type: AWS::RDS::DBInstance
  DeletionPolicy: Delete''', 2, "Deleting the stack would delete the production database with no snapshot. Use Snapshot or Retain."),
 ("Rename the table resource to make the template tidier.", r'''
-  OrdersTable:
+  OrderTable:
     Type: AWS::DynamoDB::Table''', "subtle", "Changing the logical ID creates a new table and deletes the old one, along with its data."),
 ("You want a safe update of a stack.", [
  ("Update the stack directly.", False, "No preview of destructive changes."),
  ("Create a change set for this template update, summarize it, flag every resource with Replacement: True, and add DeletionPolicy: Snapshot to the database before I execute it.", True, "Previews the change and protects stateful data."),
  ("Just apply it, it is probably fine.", False, "Never assume.")]))

cdk = T("cdk", "🛠️", "CDK: infrastructure in TypeScript or Python",
 "The AWS CDK lets you define infrastructure in a programming language and synthesizes it to CloudFormation. Constructs bundle sensible defaults and helpers.",
 "CDK is a common target for AI-generated infrastructure. Helper methods like grantRead make least privilege easy, if you insist on them.",
 ["cdk synth, cdk diff, cdk deploy and cdk destroy are the core commands. Run cdk bootstrap once per account and Region.",
  "Prefer grant methods (bucket.grantRead(fn)) over hand-written policies.",
  "Read cdk diff, especially IAM statement and security group changes.",
  "RemovalPolicy.DESTROY on a data store means deleting the stack deletes your data."],
 ["AI writes iam.PolicyStatement with actions '*'.", "AI uses RemovalPolicy.DESTROY on production data.", "AI hard-codes account and Region."],
 V(fcc="Management and Developer Tools: CDK, CDK Follow Along and AWS Toolkit for VSCode.", uq="aws cdk typescript", yq="AWS CDK tutorial TypeScript Lambda API Gateway"),
 [("Which command shows what will change?", ["cdk diff", "cdk ls", "cdk doctor", "cdk init"], 0, "cdk diff compares your code with the deployed stack."),
  ("What does bucket.grantRead(fn) do?", ["Makes the bucket public", "Adds a least-privilege read policy for the function", "Deletes the bucket", "Disables encryption"], 1, "It generates a scoped policy."),
  ("When do you run cdk bootstrap?", ["Every deploy", "Once per account and Region", "Never", "Only for Python"], 1, "It creates the resources CDK needs to deploy.")],
 ("Production orders table", r'''
const table = new dynamodb.Table(this, "Orders", {
  partitionKey: { name: "id", type: dynamodb.AttributeType.STRING },
  removalPolicy: cdk.RemovalPolicy.DESTROY,
});''', 2, "DESTROY deletes the table and data when the stack is deleted. Use RETAIN for production."),
 ("Let the function read from the uploads bucket.", r'''
fn.addToRolePolicy(new iam.PolicyStatement({
  actions: ["s3:*"],
  resources: ["*"],
}));''', "insecure", "That grants every S3 action on every bucket. Use uploadsBucket.grantRead(fn)."),
 ("Write CDK for an uploads pipeline.", [
  ("Write CDK with iam.PolicyStatement allowing s3:* so it works.", False, "Over-broad permissions."),
  ("Write CDK (TypeScript) for an uploads bucket and a processing Lambda. Use grant methods instead of hand-written policies, RETAIN on the bucket, and finish with cdk diff and cdk destroy instructions.", True, "Least privilege and explicit data protection."),
  ("Make some CDK.", False, "Too vague.")]))

terraform = T("terraform", "🌱", "Terraform on AWS: state & plans",
 "Terraform describes infrastructure in HCL. terraform plan shows changes and terraform apply performs them. State maps your code to the real resources.",
 "Terraform is very common in real teams. AI is good at writing it, and bad at warning you about state and destructive plans.",
 ["Read terraform plan before apply, especially anything marked for replacement or destroy.",
  "Store state remotely (S3 with locking) and never commit it. It can contain secrets.",
  "Pin provider and module versions to avoid surprise changes.",
  "Use default_tags and separate state per environment."],
 ["AI suggests -auto-approve and destroy casually.", "AI commits terraform.tfstate or secret .tfvars files.", "AI leaves providers unpinned."],
 V(uq="terraform aws", yq="Terraform AWS tutorial remote state S3 plan apply"),
 [("What should you do before apply?", ["Read terraform plan", "Delete state", "Disable locking", "Use root credentials"], 0, "The plan shows what will change."),
  ("Where should shared state live?", ["In git", "A remote backend such as S3 with locking", "A laptop", "Email"], 1, "Remote state with locking prevents conflicts."),
  ("Why avoid committing state files?", ["Slow clones", "They may contain secrets", "Plan breaks", "They are not JSON"], 1, "State can include sensitive values.")],
 ("Provider setup", r'''
terraform {
  required_providers {
    aws = { source = "hashicorp/aws" }
  }
}''', 2, "No version constraint, so a new major provider version can change behavior unexpectedly. Pin it."),
 ("Apply this plan. The AI says it's just a rename.", r'''
# aws_db_instance.app must be replaced
-/+ resource "aws_db_instance" "app" {
      ~ identifier = "app-db" -> "app-db-v2" # forces replacement
    }''', "subtle", "The AI's summary is wrong. Forces replacement means the database is destroyed and recreated, with data loss unless snapshotted."),
 ("Set up Terraform for a team.", [
  ("Keep the state file in the repo for simplicity.", False, "State can hold secrets and conflicts without locking."),
  ("Write Terraform with remote state in S3 with locking enabled, pinned provider versions, default_tags, and separate folders for dev and prod. Explain how to read the plan before applying.", True, "Safe state, repeatable versions and review."),
  ("Write some Terraform.", False, "Too vague.")]))

cicd = T("cicd", "🚀", "CI/CD to AWS with GitHub Actions & OIDC",
 "OIDC lets a GitHub Actions workflow assume an IAM role and get short-lived AWS credentials, so you never store long-lived access keys in GitHub.",
 "AI often tells you to paste access keys into repository secrets. Role-based, short-lived access is safer and not harder.",
 ["Use an IAM role with a trust policy for GitHub's OIDC provider instead of access keys.",
  "Restrict the trust policy by the sub claim to your repo and branch.",
  "Give the deploy role only the permissions needed, and use separate roles for dev and prod.",
  "The workflow needs permissions: id-token: write and a step such as aws-actions/configure-aws-credentials."],
 ["AI suggests AWS_ACCESS_KEY_ID in repo secrets.", "AI uses wildcard sub conditions.", "AI gives the deploy role administrator access."],
 V(uq="github actions aws oidc deploy", yq="GitHub Actions AWS OIDC role no access keys"),
 [("What is the best way for GitHub Actions to authenticate to AWS?", ["Long-lived keys in secrets", "OIDC role assumption", "The root password", "A public S3 file"], 1, "OIDC gives short-lived credentials."),
  ("What limits which repo can assume the role?", ["Trust policy conditions on the OIDC sub claim", "The repo's name only", "The Region", "A tag"], 0, "The sub claim identifies repo and branch."),
  ("Which workflow permission is needed for OIDC?", ["id-token: write", "contents: delete", "packages: none", "actions: read"], 0, "It lets the job request an OIDC token.")],
 ("Role trust policy", r'''
"Condition": {
  "StringLike": { "token.actions.githubusercontent.com:sub": "repo:*" }
}''', 1, "repo:* lets any GitHub repository assume the role. Limit it to repo:myorg/myrepo:ref:refs/heads/main."),
 ("Deploy to AWS from GitHub Actions.", r'''
permissions:
  id-token: write
  contents: read
steps:
  - uses: aws-actions/configure-aws-credentials@v4
    with:
      role-to-assume: arn:aws:iam::123456789012:role/gha-deploy
      aws-region: eu-west-1''', "correct", "OIDC with a role and no stored keys. Make sure the role's trust policy is limited to your repo and branch."),
 ("Deploy your app from GitHub to AWS.", [
  ("Create an IAM user with admin access and store its keys in repo secrets.", False, "Long-lived admin keys are a major risk."),
  ("Write Terraform for a GitHub OIDC provider and a deploy role trusted only by repo myorg/myrepo on main, limited to this stack's permissions, plus a workflow using id-token: write and no stored keys.", True, "Short-lived, scoped and branch-restricted."),
  ("Set up deployments.", False, "Too vague.")]))

review = T("review", "🔍", "Reviewing AI-generated infrastructure",
 "Whatever tool wrote it, you review infrastructure changes the same way: identities, network exposure, data safety, cost and reliability. This checklist is the core skill of working with AI on AWS.",
 "You will not write most infrastructure by hand anymore. You will approve it, so this is the day to practice that.",
 ["Identities: any wildcard actions or resources, administrator policies, hard-coded keys.",
  "Network: 0.0.0.0/0 rules, public subnets, publicly accessible databases and buckets.",
  "Data: encryption, backups, deletion or replacement of stateful resources.",
  "Cost and reliability: instance sizes, NAT gateways, provisioned capacity, Multi-AZ, DLQs, and a cleanup plan. Policy tools (cfn-guard, Checkov, cdk-nag, IAM Access Analyzer) can automate some of this."],
 ["AI summaries skip the risky lines.", "Large diffs hide a single dangerous change.", "AI says 'looks good' without checking."],
 V(uq="aws security best practices infrastructure review", yq="review Terraform plan security checkov tfsec AWS"),
 [("Which diff line is most urgent to question?", ["A tag change", "An IAM statement allowing * on *", "A description edit", "A log retention of 30 days"], 1, "Wildcard permissions give broad access."),
  ("A plan shows 'must be replaced' on a database. What should you do?", ["Apply it", "Check for data loss and add a snapshot or retain policy first", "Ignore it", "Change the Region"], 1, "Replacement destroys the old database."),
  ("Which tools can automatically flag insecure IaC?", ["Checkov or cfn-guard", "Route 53", "CloudFront", "Cost Explorer"], 0, "Policy-as-code scanners check templates before deploy.")],
 ("Database access", r'''
resource "aws_security_group_rule" "db" {
  type        = "ingress"
  from_port   = 5432
  to_port     = 5432
  protocol    = "tcp"
  cidr_blocks = ["0.0.0.0/0"]
}''', 5, "A database open to the internet. Restrict the source to the app's security group."),
 ("Review this change for me.", r'''
[+] IAM Statement   Allow  s3:*  *
[+] SecurityGroup   ingress tcp 22 0.0.0.0/0
[~] InstanceType    t3.micro -> m5.8xlarge''', "insecure", "Three problems: wildcard S3 access, SSH open to the world, and an expensive instance upgrade."),
 ("Get an AI to do a useful review.", [
  ("Review this diff and tell me if it's fine.", False, "Invites a vague 'looks good'."),
  ("Review this cdk diff. List every IAM wildcard, every 0.0.0.0/0 rule, every replacement of a stateful resource, and every size or capacity increase with a rough cost impact. Reply with a table and a recommendation to apply or not.", True, "Specific checks and a structured result."),
  ("Is this secure?", False, "Too open-ended.")]))

compute = T("compute", "🧮", "Choosing compute: Lambda vs containers vs EC2",
 "Lambda runs short event-driven code. ECS or EKS with Fargate runs containers without managing servers. EC2 gives full control of virtual machines.",
 "AI often over-engineers (EKS for a todo app) or under-fits. Choosing the right level of management saves money and effort.",
 ["Lambda: event-driven, tasks up to 15 minutes, scales to zero, pay per use.",
  "Fargate containers: long-running services, consistent environments, no servers to patch.",
  "EC2: special hardware, full OS control, steady heavy workloads, licensing needs.",
  "Start with the most managed option that fits, and move down only for a reason."],
 ["AI proposes Kubernetes for small apps.", "AI picks EC2 by default.", "AI ignores Lambda limits like the 15-minute maximum."],
 V(fcc="Compute: VMs, Containers and Serverless, and the Containers chapter.", uq="aws compute lambda vs fargate vs ec2", yq="Lambda vs Fargate vs EC2 when to use"),
 [("A 20-minute batch job cannot run directly on...", ["EC2", "Fargate", "Lambda", "AWS Batch"], 2, "Lambda tops out at 15 minutes."),
  ("Which runs containers without servers to patch?", ["Fargate", "Self-managed EC2", "Bare metal", "Outposts"], 0, "Fargate manages the underlying hosts."),
  ("A tiny, spiky API with long idle periods fits best on...", ["Lambda", "A large EC2 instance", "A dedicated host", "A Kubernetes cluster"], 0, "Lambda scales to zero and bills per use.")],
 ("Nightly report function", r'''
Resources:
  Report:
    Type: AWS::Serverless::Function
    Properties:
      Timeout: 1200''', 4, "Lambda's maximum timeout is 900 seconds. A 20-minute job needs Fargate, AWS Batch or Step Functions."),
 ("Host my small todo API.", r'''
eksctl create cluster --name todo --nodes 3 --node-type m5.xlarge''', "subtle", "A Kubernetes cluster is overkill: it has a control plane charge plus three nodes. Lambda with an HTTP API or Fargate would be simpler and cheaper."),
 ("Pick the simplest compute for a small API.", [
  ("Use Kubernetes to be future-proof.", False, "Adds cost and ops work without a stated need."),
  ("Recommend the simplest AWS compute for a small REST API with spiky traffic and a two-person team. Compare Lambda, Fargate and EC2 on cost, operations effort and cold starts, then give a Lambda-based design.", True, "States constraints and requests a comparison."),
  ("Which AWS compute is best?", False, "No context.")]))

ecs = T("ecs", "🐳", "ECR & ECS Fargate: running containers",
 "ECR stores container images. ECS runs them, and Fargate runs the tasks without servers. A task definition describes the container, and a service keeps a number of tasks running behind a load balancer.",
 "Containers are the escape hatch when Lambda doesn't fit. AI templates commonly use :latest, public IPs and plain-text secrets.",
 ["The task role gives your app permissions. The execution role pulls images and writes logs.",
  "Use versioned or digest-pinned images, not :latest.",
  "Run tasks in private subnets behind an ALB, and reference secrets from Secrets Manager instead of plain environment values.",
  "Set log retention and scan images for vulnerabilities."],
 ["AI uses :latest and public IPs.", "AI uses one role for everything.", "AI puts secrets in environment variables."],
 V(fcc="Containers: Docker and Container Services.", uq="aws ecs fargate", yq="AWS ECS Fargate tutorial ALB ECR"),
 [("Which role lets the app code call AWS services?", ["The task role", "The execution role", "Root", "None"], 0, "The task role is for application permissions."),
  ("What does the execution role do?", ["Pulls images and writes logs", "Runs SQL", "Edits DNS", "Rotates keys"], 0, "It lets ECS pull and log on your behalf."),
  ("Why avoid the :latest tag?", ["Deployments become unpredictable", "It costs more", "It is blocked", "It is slower"], 0, "You can't tell which version is running.")],
 ("Container definition", r'''
{
  "name": "api",
  "image": "myorg/api:latest",
  "environment": [{ "name": "DB_PASSWORD", "value": "hunter2" }]
}''', 3, "A plain-text password in the task definition. Use a secrets reference to Secrets Manager."),
 ("Run my container on Fargate.", r'''
aws ecs run-task --cluster app --launch-type FARGATE --task-definition api:3 \
  --network-configuration "awsvpcConfiguration={subnets=[subnet-pub1],securityGroups=[sg-open],assignPublicIp=ENABLED}"''', "subtle", "It works, but it uses a public subnet, public IP and open security group. Prefer private subnets behind an ALB."),
 ("Run a container service safely.", [
  ("Run the latest image in public subnets with a public IP.", False, "Unpinned and exposed."),
  ("Write CDK for an ECS Fargate service with an ALB: image from ECR pinned to a version, 0.5 vCPU and 1 GB, tasks in private subnets, secrets from Secrets Manager, a task role limited to one S3 bucket, and 14-day log retention.", True, "Specific, private and least-privilege."),
  ("Deploy my container.", False, "Too vague.")]))

alb = T("alb", "⚖️", "Load balancers & Auto Scaling",
 "An Application Load Balancer routes HTTP and HTTPS traffic by path or host and health-checks targets. Auto Scaling adds and removes instances or tasks based on metrics.",
 "Availability and cost both depend on correct health checks and scaling rules, which AI often gets subtly wrong.",
 ["ALB routes by URL path or host and removes unhealthy targets. NLB handles TCP/UDP at very high throughput.",
  "Target tracking scaling keeps a metric (such as average CPU) near a target value.",
  "A health check must point at an endpoint that returns a 200. A redirect or auth page marks targets unhealthy.",
  "Put the ALB in public subnets, targets in private subnets, and terminate TLS at the ALB with ACM."],
 ["AI sets the health check to '/' even when it redirects.", "AI sets min and max capacity to one.", "AI opens targets to the whole internet."],
 V(fcc="EC2: Launch an ASG, Launch an ALB.", uq="aws application load balancer auto scaling", yq="ALB Auto Scaling group target tracking health check"),
 [("Which load balancer routes by URL path?", ["ALB", "NLB", "Classic only", "Gateway only"], 0, "Application Load Balancers do layer-7 routing."),
  ("Target tracking scaling...", ["Holds a metric near a target value", "Deletes old AMIs", "Lowers IAM needs", "Blocks traffic"], 0, "It adjusts capacity to maintain the target."),
  ("Targets should accept traffic from...", ["The ALB's security group", "0.0.0.0/0", "Any VPC", "Nothing"], 0, "Restricting to the ALB keeps targets private.")],
 ("Target group health check", r'''
HealthCheckPath: /
HealthCheckIntervalSeconds: 30
# "/" returns a 302 redirect to /login''', 0, "Health checks expect a 200 by default. A 302 makes every target look unhealthy. Use a dedicated /health endpoint."),
 ("Scale my web tier by load.", r'''
aws autoscaling put-scaling-policy --auto-scaling-group-name web \
  --policy-name cpu50 --policy-type TargetTrackingScaling \
  --target-tracking-configuration file://cpu50.json''', "correct", "Target tracking is the simplest sound policy. Check the JSON sets a 50% CPU target and sensible min and max sizes."),
 ("Add a load balancer and scaling.", [
  ("Add one big instance and a load balancer.", False, "One instance is still a single point of failure."),
  ("Write Terraform for an ALB in public subnets and an Auto Scaling group in private subnets across two AZs, a /health check, target tracking at 50% CPU, min 2 and max 4, and targets that accept traffic only from the ALB security group.", True, "Availability, scaling and network rules are explicit."),
  ("Make it scale.", False, "Too vague.")]))

amplify = T("amplify", "⚡", "Amplify Hosting: ship a front end fast",
 "Amplify Hosting deploys front ends from a Git branch with build settings, environment variables, branch previews and custom domains. Amplify can also define backends in code.",
 "For a full stack developer this is the quickest route from repo to live site. You still own the secrets, IAM and costs it creates.",
 ["Connect a repo branch and Amplify builds and hosts on every push, with preview environments per branch.",
  "Backends can be defined in code (Amplify Gen 2 builds on CDK), so you can review what it creates.",
  "Anything created is a real AWS resource billing in your account. Check what it made.",
  "Variables exposed to browser code (for example VITE_ or NEXT_PUBLIC_) are public. Never put secrets there."],
 ["AI puts secret keys in client-side environment variables.", "AI forgets branch protection for production.", "AI lets preview branches use the production backend."],
 V(uq="aws amplify hosting", yq="AWS Amplify Gen 2 tutorial deploy React app"),
 [("Which variables are visible to browser users?", ["VITE_-prefixed variables", "Server-only secrets", "IAM role credentials", "KMS keys"], 0, "Prefixed client variables are bundled into the site."),
  ("Amplify Gen 2 backends are defined...", ["In code, built on CDK", "Only in the console", "In Excel", "Not at all"], 0, "Code-first, so they can be reviewed."),
  ("What does a branch preview give you?", ["A separate test deployment per branch", "Free production traffic", "A DNS record", "A WAF rule"], 0, "It lets you test changes before merging.")],
 ("Production environment file", r'''
VITE_API_URL=https://api.example.com
VITE_STRIPE_SECRET_KEY=sk_live_abc123''', 1, "A secret key in a client-side variable ships to every visitor's browser."),
 ("Add my API URL for production.", r'''
VITE_API_URL=https://api.example.com''', "correct", "A public API URL is fine in client config. Keep secrets on the server side."),
 ("Deploy a React app with a backend.", [
  ("Put all keys in environment variables so the frontend can use them.", False, "Client variables are public."),
  ("Set up Amplify Hosting for my React repo with branch previews, a custom domain, and a backend defined in code. Keep secrets server-side only, and list every AWS resource the backend creates.", True, "Safe secrets handling and visibility into resources."),
  ("Deploy my app.", False, "Too vague.")]))

storage = T("storage", "💾", "Storage beyond S3: EBS, EFS & choosing",
 "S3 stores objects. EBS provides block volumes attached to one instance in one AZ. EFS provides a shared file system for many instances across AZs.",
 "Picking the wrong storage causes data loss, slow apps or large bills. AI often mixes them up.",
 ["Use S3 for objects, backups and static assets. Use EBS for an instance's disk. Use EFS for a shared file system.",
  "A standard EBS volume attaches to one instance at a time and lives in one AZ. Take snapshots for backup.",
  "EBS volumes keep billing after instances stop. Delete or snapshot what you don't need.",
  "Choose gp3 for most workloads. Provisioned IOPS types cost much more and are rarely needed."],
 ["AI attaches one EBS volume to two servers.", "AI picks very high IOPS volumes for tests.", "AI forgets encryption and snapshots."],
 V(fcc="Storage Services: EBS, EFS and their Follow Alongs.", uq="aws ebs efs s3 storage", yq="EBS vs EFS vs S3 explained"),
 [("Which storage is a shared file system across instances?", ["EFS", "EBS", "Instance store", "Glacier"], 0, "EFS is a managed NFS file system."),
  ("A standard EBS volume can be attached to...", ["Many instances at once", "One instance at a time in its AZ", "Any Region", "Lambda"], 1, "EBS is single-instance, single-AZ."),
  ("A sensible default EBS type for most workloads is...", ["gp3", "io2 Block Express", "st1 only", "Magnetic only"], 0, "gp3 balances cost and performance.")],
 ("Test volume", r'''
aws ec2 create-volume --availability-zone eu-west-1a --size 500 \
  --volume-type io2 --iops 64000''', 1, "A large, high-IOPS volume costs far more than a test needs. gp3 is enough."),
 ("Share files between my web servers.", r'''
aws ec2 attach-volume --volume-id vol-0aaa --instance-id i-0web1 --device /dev/sdf
aws ec2 attach-volume --volume-id vol-0aaa --instance-id i-0web2 --device /dev/sdf''', "subtle", "A standard EBS volume attaches to one instance, so the second command fails. Use EFS for a shared file system, or S3 for objects."),
 ("Pick storage for a multi-server web app.", [
  ("Attach one volume to every server.", False, "EBS doesn't work that way."),
  ("Recommend storage for a web app running on three EC2 instances across two AZs that needs shared uploads. Compare S3, EFS and EBS on cost, durability and complexity, then pick one and give the CDK.", True, "Gives constraints and asks for a reasoned comparison."),
  ("Add storage.", False, "Too vague.")]))

PART2 = [cfn, cdk, terraform, cicd, review, compute, ecs, alb, amplify, storage]
