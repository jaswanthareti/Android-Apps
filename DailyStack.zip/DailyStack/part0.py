import json

def Q(id, q, options, answer, why):
    return dict(id=id, q=q, options=options, answer=answer, why=why)

def B(id, title, code, line, expl):
    return dict(id=id, title=title, code=code.strip("\n").split("\n"), buggyLine=line, explanation=expl)

def R(id, prompt, code, verdict, expl):
    return dict(id=id, prompt=prompt, code=code.strip("\n").split("\n"), verdict=verdict, explanation=expl)

def P(id, goal, opts):
    return dict(id=id, goal=goal, options=[dict(text=t, good=g, feedback=f) for t, g, f in opts])

FCC = "7HKot-brXFE"   # freeCodeCamp: AWS Certified Cloud Practitioner CLF-C02 (Andrew Brown), 14h
UDEMY = "https://www.udemy.com/course/aws-certified-cloud-practitioner-new/"  # Stephane Maarek, CLF-C02

def vids(fcc_note, udemy_note):
    return [
        dict(title="AWS Certified Cloud Practitioner CLF-C02 (Andrew Brown, freeCodeCamp)", kind="youtube", id=FCC,
             note="About 14 hours, so jump using the chapter list in the video description. " + fcc_note),
        dict(title="Ultimate AWS Certified Cloud Practitioner CLF-C02 (Stephane Maarek)", kind="udemy", url=UDEMY,
             note="Log in to Udemy, then open the matching section. " + udemy_note),
    ]

basics = dict(
    id="aws-basics", emoji="☁️", title="AWS foundations: regions, AZs & billing safety",
    what="AWS rents cloud services by usage. Resources live in Regions (geographic areas), and each Region has several Availability Zones (isolated data centers). Under the shared responsibility model, AWS secures the cloud itself and you secure what you put in it.",
    why="AI-written commands and infrastructure code quietly choose regions, create billable resources and leave them running. Knowing the basics tells you what to check before you run anything.",
    core=[
        "A Region is a geographic area. Most services are regional, a few (IAM, Route 53, CloudFront) are global. Pick the Region for latency, price, service availability and data-residency rules.",
        "Availability Zones are isolated data centers inside a Region. Use two or more for high availability.",
        "Shared responsibility: AWS secures hardware and facilities. You secure your data, access, configuration and OS patches on EC2.",
        "Set a budget and billing alarm on day one. Running resources keep billing until you stop or delete them.",
    ],
    aiPitfalls=[
        "AI scripts silently use the default region, so resources land in the wrong place.",
        "AI creates costly resources (big instances, NAT gateways, load balancers) without saying what they cost.",
        "AI leaves demo resources running. Nothing cleans up automatically.",
    ],
    videos=vids("Watch: Cloud Concepts, Getting Started (Create IAM User, AWS Budgets, Billing Alarm, Turning on MFA), Global Infrastructure (Regions, Availability Zones), Shared Responsibility Model.",
                "Look for the sections on cloud computing, global infrastructure, and the shared responsibility model."),
    checks=[
        Q("basics-c1", "What is an Availability Zone?", ["A billing tier", "One or more isolated data centers within a Region", "A global edge location", "A type of IAM user"], 1, "AZs are separate data centers in a Region. Spreading across them protects you from a single-site failure."),
        Q("basics-c2", "Under the shared responsibility model, who patches the operating system on your EC2 instances?", ["AWS", "You", "Both, automatically", "Nobody"], 1, "For EC2, the guest OS and everything above it are the customer's responsibility."),
        Q("basics-c3", "Which service warns you when spending passes a limit you set?", ["AWS Budgets", "AWS Config", "Amazon Inspector", "AWS Shield"], 0, "AWS Budgets tracks cost and usage and sends alerts against thresholds."),
        Q("basics-c4", "Which of these is a global service, not tied to one Region?", ["EC2", "RDS", "IAM", "Lambda"], 2, "IAM is global. EC2, RDS and Lambda resources live in a specific Region."),
    ],
    bugs=[
        B("basics-b1", "Launch a quick demo server", '''
aws ec2 run-instances --image-id ami-0abc1234 \\
  --instance-type p4d.24xlarge --count 1
echo "Demo server started"''', 1, "p4d.24xlarge is a very large GPU instance that costs tens of dollars per hour. A demo needs something like t3.micro."),
        B("basics-b2", "Store EU customer data", '''
REGION="us-east-1"
# Requirement: EU customer data must stay in Ireland
aws s3 mb s3://eu-customer-data --region $REGION''', 0, "Ireland is eu-west-1. Setting us-east-1 breaks the data-residency requirement."),
    ],
    aiReviews=[
        R("basics-r1", "Spin up a small web server for my test.", '''
aws ec2 run-instances \\
  --image-id ami-0abc1234 \\
  --instance-type t3.micro \\
  --count 1 \\
  --region us-east-1''', "subtle", "It runs, but it uses the default network and security group, has no tags, no access method, and no plan to stop it. That leads to forgotten, untracked resources."),
        R("basics-r2", "Make my web tier survive a data center failure.", '''
aws autoscaling create-auto-scaling-group \\
  --auto-scaling-group-name web \\
  --min-size 2 --max-size 4 \\
  --availability-zones us-east-1a us-east-1b \\
  --launch-template LaunchTemplateName=web''', "correct", "Two or more instances across two AZs is a sound baseline. In production you would add a load balancer and health checks."),
    ],
    prompts=[
        P("basics-p1", "You want AI to write a script that launches a test server without surprise costs.", [
            ("Write a script to launch an EC2 server.", False, "Too vague. The AI will choose region, size and cleanup for you."),
            ("Write an AWS CLI script that launches one t3.micro in eu-west-1 tagged Project=demo, plus a second script that terminates everything with that tag. Print the approximate hourly cost.", True, "Fixes the size and region, makes cleanup part of the deliverable, and asks for cost visibility."),
            ("Launch the best server for my app.", False, "'Best' is undefined, so you may get an expensive instance."),
        ]),
    ],
)

iam = dict(
    id="iam", emoji="🔐", title="IAM: users, roles & policies",
    what="IAM controls who can do what in your AWS account. Identities (users, roles) get permissions through policies, which are JSON documents listing allowed or denied actions on resources. Roles give temporary credentials to services and people.",
    why="Over-broad policies and leaked access keys are among the most common AWS security failures, and AI-generated code makes both mistakes often.",
    core=[
        "Least privilege: allow only the actions and resources needed. Avoid \"Action\": \"*\" and \"Resource\": \"*\".",
        "Use roles (EC2 instance profiles, Lambda execution roles) so code gets temporary credentials. Never hard-code access keys.",
        "Protect the root user: enable MFA, don't use it day to day, and don't create access keys for it.",
        "Evaluation: an explicit Deny always wins. Otherwise access needs an explicit Allow.",
    ],
    aiPitfalls=[
        "AI grants AdministratorAccess or wildcard policies to make AccessDenied disappear.",
        "AI puts access keys in code, config files that get committed, or example snippets.",
        "AI attaches permissions to individual users instead of using roles or groups.",
    ],
    videos=vids("Watch: Identity (AWS IAM, Anatomy of an IAM Policy, IAM Policies Follow Along, Principle of Least Privilege, AWS Account Root User) and Access Keys under Management and Developer Tools.",
                "Open the IAM section, then the lectures on policies, roles and MFA."),
    checks=[
        Q("iam-c1", "Which statement about IAM policy evaluation is correct?", ["An Allow always beats a Deny", "An explicit Deny always wins", "Policies are evaluated alphabetically", "The root user is limited by IAM policies"], 1, "An explicit Deny overrides any Allow."),
        Q("iam-c2", "A Lambda function must read one S3 bucket. What is the best approach?", ["Hard-code an IAM user's keys in the function", "Give the function an execution role scoped to that bucket", "Use the root user's keys", "Make the bucket public"], 1, "Roles provide temporary credentials and can be scoped tightly."),
        Q("iam-c3", "What should you do with the root user?", ["Use it for daily work", "Enable MFA and avoid everyday use", "Share it with the team", "Delete it"], 1, "Root has unrestricted access. Protect it with MFA and use it only for tasks that require it."),
        Q("iam-c4", "What does the principle of least privilege mean?", ["Give everyone admin to avoid errors", "Grant only the permissions needed for the task", "Use the cheapest services", "Rotate keys hourly"], 1, "Smaller permissions limit the damage from mistakes or stolen credentials."),
    ],
    bugs=[
        B("iam-b1", "Policy for a function that only reads reports from one bucket", '''
{
  "Effect": "Allow",
  "Action": "s3:*",
  "Resource": "arn:aws:s3:::reports-bucket/*"
}''', 2, "s3:* also allows deleting and overwriting. A read-only function needs s3:GetObject."),
        B("iam-b2", "List buckets from an app", '''
import boto3
s3 = boto3.client("s3", aws_access_key_id="AKIAIOSFODNN7EXAMPLE", aws_secret_access_key="wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY")
print(s3.list_buckets())''', 1, "Hard-coded keys end up in git history and logs. Use an attached role or the default credential chain."),
    ],
    aiReviews=[
        R("iam-r1", "My Lambda gets AccessDenied reading S3. Fix the policy.", '''
{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Action": "*",
    "Resource": "*"
  }]
}''', "insecure", "This makes AccessDenied go away by granting full admin. Grant only the specific S3 action on the specific bucket."),
        R("iam-r2", "Give my Lambda read access to the uploads bucket.", '''
{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Action": ["s3:GetObject"],
    "Resource": "arn:aws:s3:::uploads-bucket/*"
  }]
}''', "correct", "Read-only, one bucket's objects. If the function also needs to list the bucket, s3:ListBucket on the bucket ARN would be added."),
    ],
    prompts=[
        P("iam-p1", "Your app on EC2 needs to upload files to one S3 bucket.", [
            ("Make an IAM user with full S3 access and put its keys in the code so it works.", False, "Long-lived keys in code plus full access is the opposite of least privilege."),
            ("Create an IAM role for EC2 that allows only s3:PutObject on arn:aws:s3:::my-uploads/*, attach it through an instance profile, and show code that uses the default credential chain with no hard-coded keys.", True, "Role-based, tightly scoped, and says how the code should authenticate."),
            ("Fix S3 permissions for my app.", False, "Too vague. The AI is likely to over-grant."),
        ]),
    ],
)

s3 = dict(
    id="s3", emoji="🪣", title="S3: buckets, access & storage classes",
    what="S3 stores objects (files) in buckets. Buckets live in a Region, names are globally unique, new buckets are private, and each object has a storage class that trades cost against access speed.",
    why="Public buckets and the wrong storage choices cause data leaks and surprise bills. AI often 'fixes' AccessDenied by making things public.",
    core=[
        "Keep Block Public Access on unless you intentionally serve public content (and then prefer CloudFront in front).",
        "Grant access with IAM policies and bucket policies. Share temporarily with pre-signed URLs.",
        "Enable versioning for important data, and use lifecycle rules to move or expire old objects.",
        "Pick storage classes by access pattern: Standard for frequent access, Standard-IA or Glacier classes for rarely used data.",
    ],
    aiPitfalls=[
        "AI adds a bucket policy with Principal \"*\" to get past AccessDenied.",
        "AI turns off Block Public Access instead of fixing the role.",
        "AI skips encryption, versioning and lifecycle rules.",
    ],
    videos=vids("Watch: Storage Services (Types of Storage Services, Introduction to S3, S3 Storage Classes, S3 Follow Along).",
                "Open the S3 section on buckets, security and storage classes."),
    checks=[
        Q("s3-c1", "By default, who can read objects in a newly created bucket?", ["Everyone", "Only identities that have been granted access", "Anyone who knows the bucket name", "Every AWS customer"], 1, "New buckets are private. Access needs an explicit grant."),
        Q("s3-c2", "Best way to give a customer a temporary download of one private object?", ["Make the bucket public", "A pre-signed URL", "Share your access keys", "Email the bucket policy"], 1, "A pre-signed URL grants time-limited access to a single object."),
        Q("s3-c3", "Which option suits data you rarely access but must keep?", ["S3 Standard", "S3 Standard-IA or a Glacier class", "An EBS volume", "Instance store"], 1, "Infrequent-access and archive classes cost less per GB for rarely read data."),
        Q("s3-c4", "What does S3 versioning help protect against?", ["Slow downloads", "Accidental overwrites and deletes", "Region outages only", "Large bills"], 1, "Versioning keeps prior versions so you can recover from overwrites and deletes."),
    ],
    bugs=[
        B("s3-b1", "Policy for a bucket of customer invoices", '''
{
  "Effect": "Allow",
  "Principal": "*",
  "Action": "s3:GetObject",
  "Resource": "arn:aws:s3:::customer-invoices/*"
}''', 2, "Principal \"*\" makes every invoice readable by anyone on the internet."),
        B("s3-b2", "Lock down the invoices bucket", '''
aws s3api put-public-access-block \\
  --bucket customer-invoices \\
  --public-access-block-configuration \\
  BlockPublicAcls=false,IgnorePublicAcls=false,BlockPublicPolicy=false,RestrictPublicBuckets=false''', 3, "Setting every Block Public Access flag to false removes the safety net. They should be true."),
    ],
    aiReviews=[
        R("s3-r1", "Let users download their invoice from my private bucket for 10 minutes.", '''
url = s3.generate_presigned_url(
    "get_object",
    Params={"Bucket": "customer-invoices", "Key": key},
    ExpiresIn=600,
)''', "correct", "A 10-minute pre-signed URL on a private bucket is the right pattern. Your app must still check that the user owns that key before generating it."),
        R("s3-r2", "Fix AccessDenied when my site loads images from S3.", '''
aws s3api put-bucket-acl --bucket site-assets --acl public-read-write''', "insecure", "public-read-write lets anyone read and also upload or overwrite objects. Fix the actual permission, or serve public assets through CloudFront with read-only access."),
    ],
    prompts=[
        P("s3-p1", "You want a private bucket for user uploads that stays cheap over time.", [
            ("Make a bucket that anyone can use so nothing breaks.", False, "Public write access is a security and cost risk."),
            ("Write Terraform for a private S3 bucket with Block Public Access on, default encryption, versioning enabled, and a lifecycle rule that moves objects to Standard-IA after 30 days. No public policies.", True, "Covers privacy, encryption, recovery and cost in one specific request."),
            ("Create an S3 bucket for uploads.", False, "Leaves security and cost settings to chance."),
        ]),
    ],
)

ec2 = dict(
    id="ec2", emoji="🖥️", title="EC2 & security groups",
    what="EC2 rents virtual servers (instances) in a Region and AZ. You choose an AMI (OS image), an instance type (CPU and memory), storage (EBS volumes), how to log in (key pair or Session Manager), and security groups, which act as a stateful firewall.",
    why="Servers are where cost, security and availability mistakes show up. AI launch commands often open SSH to the world or oversize the instance.",
    core=[
        "Security groups: allow only needed ports from needed sources. Never open SSH (22) or RDP (3389) to 0.0.0.0/0.",
        "Prefer Session Manager or a single trusted IP over open SSH, and keep private keys out of repos.",
        "Choose the smallest instance that works. A stopped instance stops compute billing, but its EBS volumes still bill.",
        "For availability, use Auto Scaling across multiple AZs behind a load balancer. One instance is a single point of failure.",
    ],
    aiPitfalls=[
        "AI opens port 22 to 0.0.0.0/0 to make SSH work.",
        "AI picks large instance types or forgets to terminate them.",
        "AI puts everything on one instance in one AZ.",
    ],
    videos=vids("Watch the EC2 chapter: Introduction to EC2, Instance Families and Types, Launch an EC2 (SSH and Sessions Manager), AMI and Launch Template, Launch an ASG, Launch an ALB, Cleanup. Also Security Groups vs NACLs under Networking.",
                "Open the EC2 sections, then security groups and Auto Scaling or load balancing."),
    checks=[
        Q("ec2-c1", "Which security group rule is the biggest red flag?", ["HTTPS (443) from anywhere for a public website", "SSH (22) from 0.0.0.0/0", "SSH (22) from one office IP", "Port 5432 from the app's security group"], 1, "SSH open to the whole internet invites constant brute-force attempts."),
        Q("ec2-c2", "You stop an EC2 instance. What can still cost money?", ["Nothing", "Its attached EBS volumes", "The CPU time", "The AMI's Region"], 1, "Stopped instances don't bill for compute, but EBS storage keeps billing."),
        Q("ec2-c3", "How do you keep a web app up if one data center fails?", ["Use a bigger instance", "Run instances in multiple AZs behind a load balancer", "Use a static IP", "Turn on detailed monitoring"], 1, "Spreading across AZs removes the single point of failure."),
        Q("ec2-c4", "A security group is...", ["A stateless subnet-level firewall", "A stateful instance-level firewall", "An IAM policy", "A VPN"], 1, "Security groups are stateful and attach to instances' network interfaces."),
    ],
    bugs=[
        B("ec2-b1", "Make SSH work", '''
aws ec2 authorize-security-group-ingress \\
  --group-id sg-0123456789abcdef0 \\
  --protocol tcp --port 22 \\
  --cidr 0.0.0.0/0''', 3, "0.0.0.0/0 exposes SSH to the entire internet. Restrict it to your IP or use Session Manager."),
        B("ec2-b2", "Host a tiny test website", '''
aws ec2 run-instances \\
  --image-id ami-0abc1234 \\
  --instance-type m5.24xlarge \\
  --count 1''', 2, "m5.24xlarge is far larger than a test site needs and costs several dollars an hour. Try t3.micro or t3.small."),
    ],
    aiReviews=[
        R("ec2-r1", "Open my web server to the internet and let me SSH in.", '''
aws ec2 authorize-security-group-ingress --group-id sg-0123 --protocol tcp --port 80 --cidr 0.0.0.0/0
aws ec2 authorize-security-group-ingress --group-id sg-0123 --protocol tcp --port 22 --cidr 0.0.0.0/0''', "insecure", "Port 80 open to the world is normal for a web server. Port 22 open to the world is not. Restrict it to your IP or use Session Manager."),
        R("ec2-r2", "Allow SSH only from my IP.", '''
aws ec2 authorize-security-group-ingress --group-id sg-0123 --protocol tcp --port 22 --cidr 203.0.113.25/32''', "correct", "A /32 allows exactly one address. Your IP may change, and Session Manager avoids exposing port 22 at all."),
    ],
    prompts=[
        P("ec2-p1", "You want a small web app that stays up if one data center fails.", [
            ("Make it highly available using the biggest instances.", False, "Bigger doesn't mean available, and it raises cost."),
            ("Write Terraform for an Auto Scaling group of t3.small instances across two AZs behind an Application Load Balancer. Security groups should allow HTTP only from the ALB and no SSH from the internet.", True, "Specifies size, multi-AZ design, load balancing and least-open network rules."),
            ("Set up EC2 for my web app.", False, "Leaves size, availability and security undecided."),
        ]),
    ],
)


def V(fcc=None, maarek=None, uq=None, yq=None):
    out = []
    if fcc:
        out.append(dict(title="AWS Certified Cloud Practitioner CLF-C02 (Andrew Brown, freeCodeCamp)", kind="youtube", id=FCC,
                        note="About 14 hours, so jump with the chapter list in the video description. Watch: " + fcc))
    if maarek:
        out.append(dict(title="Ultimate AWS Certified Cloud Practitioner CLF-C02 (Stephane Maarek)", kind="udemy", url=UDEMY,
                        note="Log in to Udemy, then open the matching section. " + maarek))
    if uq:
        out.append(dict(title="Search Udemy: " + uq, kind="udemy",
                        url="https://www.udemy.com/courses/search/?q=" + uq.replace(" ", "+"),
                        note="Pick a highly rated, recent course you have access to and open the lecture on this topic."))
    if yq:
        out.append(dict(title="Search YouTube: " + yq, kind="link",
                        url="https://www.youtube.com/results?search_query=" + yq.replace(" ", "+"),
                        note="Prefer videos from 2025 or later by AWS, freeCodeCamp or well-known instructors."))
    return out

def T(id, emoji, title, what, why, core, pit, videos, checks, bug, review, prompt):
    return dict(
        id=id, emoji=emoji, title=title, what=what, why=why, core=core, aiPitfalls=pit, videos=videos,
        checks=[Q(f"{id}-c{i+1}", *c) for i, c in enumerate(checks)],
        bugs=[B(f"{id}-b1", *bug)],
        aiReviews=[R(f"{id}-r1", *review)],
        prompts=[P(f"{id}-p1", prompt[0], prompt[1])],
    )
