import json

def Q(id, q, options, answer, why):
    return dict(id=id, q=q, options=options, answer=answer, why=why)

def B(id, title, code, line, expl):
    return dict(id=id, title=title, code=code.strip("\n").split("\n"), buggyLine=line, explanation=expl)

def R(id, prompt, code, verdict, expl):
    return dict(id=id, prompt=prompt, code=code.strip("\n").split("\n"), verdict=verdict, explanation=expl)

def P(id, goal, opts):
    return dict(id=id, goal=goal, options=[dict(text=t, good=g, feedback=f) for t, g, f in opts])

http = dict(
    id="http", emoji="🌐", title="How the web works (HTTP)",
    what="HTTP is the request/response conversation between a browser (client) and a server. The client sends a method and URL, plus headers and sometimes a body. The server answers with a status code, headers and a body.",
    why="Every API you ask AI to build is HTTP. If you know methods and status codes, you can spot a wrong endpoint or sloppy error handling in seconds.",
    core=[
        "GET reads data, POST creates, PUT/PATCH update, DELETE removes. GET must never change data.",
        "Status codes: 2xx success, 3xx redirect, 4xx client error (400 bad input, 401 not logged in, 403 not allowed, 404 not found), 5xx server error.",
        "Headers carry metadata (Content-Type, Authorization, Cookie). The body carries the data, usually JSON.",
        "HTTPS encrypts traffic. Never put secrets in URLs or send them over plain HTTP.",
    ],
    aiPitfalls=[
        "AI often returns 200 for errors, which hides failures.",
        "AI may use GET for actions that change data, like /delete?id=3.",
        "AI skips input validation, so bad data causes a 500 instead of a clear 400.",
    ],
    videos=[],
    checks=[
        Q("http-c1", "Which method should create a new user?", ["GET", "POST", "DELETE", "HEAD"], 1, "POST creates a resource. GET is for reading and must not change data."),
        Q("http-c2", "A logged-out user requests a private page. Which status fits best?", ["200", "401", "404", "500"], 1, "401 means the request lacks valid authentication."),
        Q("http-c3", "What does a 5xx status mean?", ["The client sent bad input", "The server failed", "A redirect", "Success"], 1, "5xx codes mean the server hit an error handling a valid request."),
        Q("http-c4", "Where should an API key never be placed?", ["An Authorization header over HTTPS", "The URL query string", "A server environment variable", "Server-side config"], 1, "URLs get logged and cached in browsers, proxies and servers, so secrets in them leak."),
    ],
    bugs=[
        B("http-b1", "Express route for deleting a user", '''
app.get("/users/delete", (req, res) => {
  db.deleteUser(req.query.id);
  res.send("deleted");
});''', 0, "A destructive action is behind GET. Crawlers, prefetching and links can trigger it. Use DELETE /users/:id."),
        B("http-b2", "Login endpoint", '''
app.post("/login", (req, res) => {
  const user = findUser(req.body.email);
  if (!user) {
    return res.status(200).json({ error: "User not found" });
  }
  res.json({ ok: true });
});''', 3, "It returns 200 for a failure. Clients and monitoring treat 200 as success. Use a 4xx code such as 401."),
    ],
    aiReviews=[
        R("http-r1", "Create an endpoint to fetch a user by id.", '''
app.get("/users/:id", (req, res) => {
  const user = db.find(req.params.id);
  res.json(user);
});''', "subtle", "It works for the happy path, but a missing user returns 200 with null. It should return 404 when the user is not found."),
        R("http-r2", "Call the weather API from my website.", '''
const KEY = "sk_live_9f8a7b6c";
fetch(`https://api.weather.com/data?key=${KEY}`)
  .then(r => r.json())''', "insecure", "Browser code is public, so the secret key is exposed, and it also sits in the URL. Call the API from your server instead."),
    ],
    prompts=[
        P("http-p1", "You need an endpoint that lets a logged-in user update their email.", [
            ("Make an update email endpoint.", False, "Too vague. The AI will guess the method, auth and validation."),
            ("Add PATCH /me/email to my Express app. Require the logged-in user, validate the email format, return 400 on bad input and 401 if not logged in, and return the updated user as JSON.", True, "Specific method, auth, validation, error codes and response shape. This leaves little to guess."),
            ("Write the best possible secure endpoint for emails with everything.", False, "Sounds thorough but gives no concrete requirements to check the result against."),
        ]),
    ],
)

html = dict(
    id="html", emoji="🧱", title="HTML essentials",
    what="HTML describes the structure and meaning of a page with nested elements: headings, paragraphs, links, lists, images and forms.",
    why="Semantic, accessible markup is where AI is often sloppy. Good structure makes styling, SEO and screen readers work.",
    core=[
        "Use semantic tags (header, nav, main, section, article, footer) instead of a pile of divs.",
        "Every img needs alt text and every form input needs a label.",
        "Links (a with href) navigate. Buttons perform actions. Don't swap them.",
        "One h1 per page, and keep headings in order (h1, h2, h3).",
    ],
    aiPitfalls=[
        "AI uses clickable divs instead of real buttons or links.",
        "AI skips alt text and form labels.",
        "AI breaks heading order or nests elements incorrectly.",
    ],
    videos=[
        dict(title="HTML full course for beginners (Dave Gray, freeCodeCamp)", kind="youtube", id="kUMe1FH4CHE",
             note="About 4 hours. Focus on: Text Basics, Add Links, Add Images, Semantic Tags, Forms & Inputs. Use the chapter list in the video description to jump."),
        dict(title="HTML & CSS full course (Per Borgen, freeCodeCamp)", kind="youtube", id="a_iQb1lnAEQ",
             note="About 5 hours, project-based. A different style if the first one doesn't click."),
    ],
    checks=[
        Q("html-c1", "Which tag best wraps the main navigation links?", ["div", "nav", "section", "span"], 1, "nav marks navigation landmarks, which helps screen readers and search engines."),
        Q("html-c2", "What is alt text for?", ["A hover tooltip", "Describing the image for screen readers and when it fails to load", "Keyword stuffing for SEO", "Resizing the image"], 1, "Alt text describes the image to people who can't see it and appears if loading fails."),
        Q("html-c3", "Which element should perform an action like Save without navigating?", ["a", "div", "button", "span"], 2, "button is keyboard-focusable and announced correctly by default."),
        Q("html-c4", "Why connect a label to an input?", ["Only for styling", "Clicking the label focuses the input and screen readers announce it", "Browsers require it to submit", "It validates the data"], 1, "Labels make inputs accessible and give a bigger click target."),
    ],
    bugs=[
        B("html-b1", "Newsletter signup form", '''
<form>
  <label for="email">Email</label>
  <input id="email" type="email">
  <div class="btn" onclick="submitForm()">Subscribe</div>
</form>''', 3, "A div is not keyboard-focusable and has no button semantics. Use <button type=\"submit\">."),
        B("html-b2", "Shop home page", '''
<main>
  <h1>My Shop</h1>
  <img src="/hero.jpg">
  <p>Welcome</p>
</main>''', 2, "The image has no alt attribute. Screen readers get nothing useful."),
    ],
    aiReviews=[
        R("html-r1", "Make a header with a logo and navigation.", '''
<header>
  <img src="logo.png" alt="Acme logo">
  <nav>
    <a href="/">Home</a>
    <a href="/pricing">Pricing</a>
  </nav>
</header>''', "correct", "Semantic header and nav, real links, and alt text on the logo. Nothing to fix."),
        R("html-r2", "Make a clickable product card.", '''
<div class="card" onclick="location.href='/p/1'">
  <img src="p1.jpg">
  <h3>Shoes</h3>
</div>''', "subtle", "It looks fine but isn't a real link: no keyboard access, no right-click or open-in-new-tab, and the image lacks alt text."),
    ],
    prompts=[
        P("html-p1", "You want an accessible signup form.", [
            ("Make a pretty signup form with animations.", False, "Focuses on looks and leaves accessibility to chance."),
            ("Build a signup form in semantic HTML with labeled inputs for name and email, a real submit button, and appropriate type and required attributes. No JavaScript yet.", True, "Names structure, labels, a real button and validation attributes, and keeps scope tight."),
            ("Make a signup form that works well.", False, "Too vague to verify."),
        ]),
    ],
)

css = dict(
    id="css", emoji="🎨", title="CSS: box model & flexbox",
    what="CSS controls how elements look and are laid out. The box model (content, padding, border, margin) decides size and spacing, and flexbox arranges items in a row or column.",
    why="Most layout bugs in AI-written UI come from box model or flex mistakes. Knowing both lets you fix them in seconds.",
    core=[
        "Box model: content + padding + border + margin. Set box-sizing: border-box so width includes padding and border.",
        "Flexbox: display: flex on the parent. justify-content aligns on the main axis, align-items on the cross axis, flex-direction picks the axis.",
        "Prefer rem, %, fr and max-width over fixed pixel widths, and use media queries for small screens.",
        "Specificity: id beats class beats element. Avoid !important.",
    ],
    aiPitfalls=[
        "AI hard-codes pixel widths that break on phones.",
        "AI reaches for !important to win specificity fights.",
        "AI uses margin hacks where gap and flex-wrap belong.",
    ],
    videos=[
        dict(title="HTML & CSS full course (Per Borgen, freeCodeCamp)", kind="youtube", id="a_iQb1lnAEQ",
             note="About 5 hours. It covers the box model, margin and padding, and flexbox. Watch those modules and skim the rest."),
    ],
    checks=[
        Q("css-c1", "With box-sizing: border-box, a box with width 200px, 20px padding and a 5px border is rendered how wide?", ["250px", "200px", "240px", "220px"], 1, "border-box includes padding and border in the stated width."),
        Q("css-c2", "Which property aligns flex items along the main axis?", ["align-items", "justify-content", "text-align", "float"], 1, "justify-content works on the main axis. align-items works on the cross axis."),
        Q("css-c3", "What is the default flex-direction?", ["column", "row", "row-reverse", "none"], 1, "Flex containers lay items out in a row by default."),
        Q("css-c4", "Which selector wins: .btn or #save?", [".btn", "#save", "element selectors", "They tie"], 1, "An id selector has higher specificity than a class selector."),
    ],
    bugs=[
        B("css-b1", "Button row", '''
.row {
  display: flex;
  justify-content: center;
  width: 600px;
}''', 3, "A fixed pixel width overflows small screens. Use max-width: 100% or a relative width."),
        B("css-b2", "Button style", '''
.btn {
  color: white !important;
  background: blue;
}''', 1, "!important makes later overrides painful. Fix specificity instead."),
    ],
    aiReviews=[
        R("css-r1", "Center a card on the page.", '''
body {
  display: grid;
  place-items: center;
  min-height: 100vh;
}''', "correct", "A standard, robust way to center content both ways."),
        R("css-r2", "Put three cards in a row with spacing.", '''
.cards { display: flex; }
.card { width: 300px; margin-right: 20px; }''', "subtle", "Fixed widths overflow on phones, items can't wrap, and the last card gets a trailing margin. Use gap, flex-wrap and flexible widths."),
    ],
    prompts=[
        P("css-p1", "You want a responsive three-column card layout.", [
            ("Make the cards look good everywhere.", False, "Vague. You can't tell whether the result meets it."),
            ("Create a responsive card grid: three columns on desktop, one on mobile, using CSS grid with gap and relative units. No fixed pixel widths.", True, "Gives layout behavior, technique and a constraint to verify."),
            ("Use whatever CSS works for three cards.", False, "Leaves every decision to the AI."),
        ]),
    ],
)

content = dict(weeks=[
    dict(id=1, title="How the web works, HTML & CSS", topics=[http, html, css]),
    dict(id=2, title="Git & the command line", topics=[]),
    dict(id=3, title="JavaScript essentials", topics=[]),
    dict(id=4, title="Async, JSON & the DOM", topics=[]),
])
json.dump(content, open("app/src/main/assets/content.json", "w", encoding="utf-8"), ensure_ascii=False, indent=2)
print("topics:", sum(len(w["topics"]) for w in content["weeks"]))
