import json
from urllib.parse import quote_plus
from part0 import basics, iam, s3, ec2, T, V
from part1 import ai_workflow, vpc, rds, dynamodb, secrets, edge, lambda_, apigw, messaging, stepfn, sam
from part2 import cfn, cdk, terraform, cicd, review, compute, ecs, alb, amplify, storage
from part3 import cloudwatch, audit, debug, backup, cost, secbase, analyzer, orgs, cognito, waf
from part4 import bedrock, rag, agents, aitools, capstone

weeks = [
    (1, "AWS foundations & working with AI", [basics, iam, s3, ec2, ai_workflow]),
    (2, "Networking, data & edge", [vpc, rds, dynamodb, secrets, edge]),
    (3, "Serverless & messaging", [lambda_, apigw, messaging, stepfn, sam]),
    (4, "Infrastructure as code & CI/CD", [cfn, cdk, terraform, cicd, review]),
    (5, "Compute, containers & storage", [compute, ecs, alb, amplify, storage]),
    (6, "Operations, debugging & cost", [cloudwatch, audit, debug, backup, cost]),
    (7, "Security & identity at scale", [secbase, analyzer, orgs, cognito, waf]),
    (8, "AI on AWS & capstone", [bedrock, rag, agents, aitools, capstone]),
]
content = dict(weeks=[dict(id=i, title=t, topics=ts) for i, t, ts in weeks])


def materials(t):
    q = t["title"].split(":")[0].replace("&", "and").strip()
    docs = "https://www.google.com/search?q=" + quote_plus("site:docs.aws.amazon.com " + q)
    blog = "https://www.google.com/search?q=" + quote_plus("site:aws.amazon.com/blogs " + q)
    return [
        dict(title="AWS documentation: " + q, kind="doc", url=docs,
             note="Official user guides. Read the 'best practices' and 'security' pages first."),
        dict(title="AWS Workshops: hands-on labs", kind="lab", url="https://workshops.aws/",
             note="Guided labs. Search for this topic and do one in your sandbox account."),
        dict(title="AWS Getting Started Resource Center", kind="doc", url="https://aws.amazon.com/getting-started/",
             note="Tutorials and hands-on guides from AWS."),
        dict(title="AWS Well-Architected Framework", kind="doc", url="https://aws.amazon.com/architecture/well-architected/",
             note="Security, reliability, cost and other pillars. Use them as your review lens."),
        dict(title="AWS blog: " + q, kind="blog", url=blog, note="Recent patterns and announcements."),
        dict(title="AWS re:Post community Q&A", kind="community", url="https://repost.aws/",
             note="Official community answers when you get stuck."),
    ]

for w in content["weeks"]:
    for t in w["topics"]:
        t["materials"] = materials(t)

ids = set()
for w in content["weeks"]:
    for t in w["topics"]:
        assert t["id"] not in ids, t["id"]; ids.add(t["id"])
        assert t["what"] and t["why"] and len(t["core"]) >= 3 and t["aiPitfalls"], t["id"]
        assert len(t["checks"]) >= 3 and t["videos"], t["id"]
        for b in t["bugs"]:
            assert 0 <= b["buggyLine"] < len(b["code"]), b["id"]
        for c in t["checks"]:
            assert 0 <= c["answer"] < len(c["options"]), c["id"]
        for r in t["aiReviews"]:
            assert r["verdict"] in ("correct", "subtle", "insecure"), r["id"]
        for p in t["prompts"]:
            assert sum(o["good"] for o in p["options"]) == 1, t["id"]
        # every bug must point at a line that is not a pure comment/brace
        for b in t["bugs"]:
            line = b["code"][b["buggyLine"]].strip()
            assert line not in ("{", "}", "") and not line.startswith("#"), (b["id"], line)

import os
os.makedirs("app/src/main/assets/courses", exist_ok=True)
course = dict(id="aws", title="AWS in the AI era", emoji="☁️", level="Beginner", builtin=True,
              description="40 days of AWS focused on directing AI tools and verifying their work.",
              weeks=content["weeks"])
json.dump(course, open("app/src/main/assets/courses/aws.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
if os.path.exists("app/src/main/assets/content.json"):
    os.remove("app/src/main/assets/content.json")
print("days:", len(ids), "weeks:", len(weeks))
