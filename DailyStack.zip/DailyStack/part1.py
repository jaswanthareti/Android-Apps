from part0 import *

ai_workflow = T("ai-workflow", "🤖", "Working with AI on AWS: the safe loop",
 "The loop is: describe the task precisely, let AI generate infrastructure code, review the plan or diff, deploy to a sandbox, verify, then clean up. AI does the typing and you own the review.",
 "AI can produce a working stack in seconds and a very expensive or insecure mistake just as fast. A repeatable loop keeps the speed and limits the damage.",
 ["Do AI-driven work in a sandbox account (or at least a separate profile) with a budget alarm and limited permissions.",
  "Ask for infrastructure as code (CDK, Terraform, CloudFormation or SAM) instead of console clicks or one-off CLI commands, so changes can be reviewed and repeated.",
  "Read the plan or diff before applying: cdk diff, terraform plan or a CloudFormation change set.",
  "State constraints up front: region, size limits, tags, no public access, least-privilege IAM and a cleanup step."],
 ["AI deploys without showing what will change.", "AI tools running with your admin credentials can delete or expose real resources.", "AI forgets teardown, tags and cost limits unless you ask."],
 V(uq="aws infrastructure as code with ai", yq="AWS Amazon Q Developer infrastructure as code walkthrough"),
 [("What should you read before approving an AI-generated deployment?", ["Only the README", "The plan or diff of what will change", "The AI's confidence statement", "Nothing; tests will catch it"], 1, "The plan or diff shows exactly which resources will be created, changed or destroyed."),
  ("Where is it safest to let AI tools experiment?", ["Production with admin keys", "A sandbox account with a budget alarm and limited permissions", "The root user", "A shared team account"], 1, "A sandbox limits blast radius and cost."),
  ("Why prefer infrastructure as code over console clicks when working with AI?", ["It is always cheaper", "Changes can be reviewed, versioned and repeated", "The console is deprecated", "AWS requires it"], 1, "Code can be diffed, reviewed and re-run, which makes AI output checkable.")],
 ("Deploy command from an AI assistant", r'''
export AWS_PROFILE=sandbox
cdk synth
cdk deploy --all --require-approval never''', 2, "--require-approval never auto-approves IAM and security-group changes. Keep the default prompt and read the diff."),
 ("Deploy my stack.", r'''
terraform apply -auto-approve''', "subtle", "It works, but -auto-approve skips the review. Run terraform plan, read it, then apply."),
 ("You want AI to create a small API stack safely.", [
  ("Deploy an API to my account now.", False, "No constraints, no review step and no cleanup."),
  ("Write CDK in TypeScript for a Lambda behind an HTTP API in eu-west-1. Tag everything Project=demo, use a least-privilege role, keep everything private except the API, and tell me how to run cdk diff and cdk destroy.", True, "Specifies region, tags, security, and the review and cleanup commands."),
  ("Make me an AWS backend.", False, "Too vague to review against.")]))

vpc = T("vpc", "🕸️", "VPC: subnets, routes & what is public",
 "A VPC is your private network in a Region. Each subnet lives in one AZ. A subnet is public if its route table sends internet traffic to an internet gateway. Private subnets reach the internet only through a NAT gateway, if at all.",
 "Network design decides what is exposed and what costs money. AI often creates NAT gateways (billed hourly plus per GB) or puts databases in public subnets.",
 ["Public subnet = route to an internet gateway. Private subnet = no direct route in from the internet.",
  "Put load balancers in public subnets and app servers and databases in private ones.",
  "NAT gateways bill hourly plus per GB. Gateway endpoints for S3 and DynamoDB avoid that traffic cost.",
  "Security groups are stateful and attach to resources. NACLs are stateless and attach to subnets."],
 ["AI puts databases in public subnets so they 'just connect'.", "AI adds a NAT gateway per AZ for a demo.", "AI leaves default security groups wide open."],
 V(fcc="Networking: Virtual Private Cloud VPC Subnets, Security Groups vs NACLs and its Follow Along.", maarek="Open the VPC section.", yq="AWS VPC subnets route tables NAT gateway explained"),
 [("What makes a subnet public?", ["Its name", "A route to an internet gateway", "A public security group", "Being in us-east-1"], 1, "The route table entry to an internet gateway is what makes it public."),
  ("What lets instances in a private subnet reach the internet outbound?", ["An internet gateway attached to the subnet", "A NAT gateway in a public subnet", "A security group", "A NACL"], 1, "A NAT gateway forwards outbound traffic without allowing inbound connections."),
  ("NACLs are...", ["Stateful and attached to instances", "Stateless and attached to subnets", "The same as IAM policies", "Only used for S3"], 1, "NACLs are stateless subnet-level filters. Security groups are stateful.")],
 ("Route for the database subnets", r'''
# rtb-0aaa belongs to the PRIVATE database subnets
aws ec2 create-route --route-table-id rtb-0aaa --destination-cidr-block 0.0.0.0/0 --gateway-id igw-0bbb''', 1, "A default route to an internet gateway makes those subnets public. Database subnets should not have one."),
 ("Let my private servers download updates.", r'''
aws ec2 create-nat-gateway --subnet-id subnet-public-a --allocation-id eipalloc-0123''', "correct", "A NAT gateway belongs in a public subnet with an Elastic IP. It bills hourly plus per GB, and the private route table still needs a 0.0.0.0/0 route to it."),
 ("Design a VPC for a web app plus database.", [
  ("Put everything in public subnets so it works.", False, "This exposes the database and app servers directly."),
  ("Write Terraform for a VPC with two public subnets (load balancer only) and two private subnets (app and database) across two AZs, one NAT gateway for the demo, an S3 gateway endpoint, and a database security group that accepts traffic only from the app's security group.", True, "Public and private tiers, cost-aware NAT, and least-open security groups."),
  ("Create a VPC.", False, "Leaves every important decision to the AI.")]))

rds = T("rds", "🗄️", "RDS & Aurora: managed relational databases",
 "RDS runs managed relational databases such as PostgreSQL and MySQL. AWS handles patching, backups and failover while you choose engine, size, storage and network placement. Aurora is AWS's cloud-built MySQL- and PostgreSQL-compatible engine.",
 "Databases hold your data, so exposure, missing backups and weak credentials are costly. AI templates often make them public with a hard-coded password.",
 ["Place RDS in private subnets with public access off, and allow connections only from the app's security group.",
  "Multi-AZ gives automatic failover. Read replicas scale reads. Automated backups give point-in-time recovery.",
  "Keep credentials in Secrets Manager (RDS can manage the master password) instead of code or env files.",
  "Choose the smallest instance class that works, and stop or snapshot dev databases."],
 ["AI sets public access and 0.0.0.0/0 on port 5432 to connect from a laptop.", "AI hard-codes the master password.", "AI skips backups and Multi-AZ for production."],
 V(fcc="Databases: Relational Database Services, RDS Follow Along.", maarek="Open the RDS and Aurora section.", yq="AWS RDS Multi-AZ read replica backups tutorial"),
 [("What does Multi-AZ provide?", ["Cheaper storage", "Automatic failover to a standby in another AZ", "Faster reads", "Cross-Region backups"], 1, "Multi-AZ keeps a standby copy and fails over automatically."),
  ("Where should the database password live?", ["In the source code", "Secrets Manager", "A public S3 file", "Instance tags"], 1, "Secrets Manager stores and can rotate credentials."),
  ("To scale a read-heavy workload you add...", ["A NAT gateway", "Read replicas", "More NACLs", "A bigger root volume"], 1, "Read replicas serve read traffic.")],
 ("Database resource", r'''
resource "aws_db_instance" "app" {
  engine   = "postgres"
  username = "admin"
  password = "Summer2024!"
}''', 3, "A hard-coded password lands in git and state. Use manage_master_user_password or Secrets Manager."),
 ("Create a Postgres database for my app.", r'''
aws rds create-db-instance --db-instance-identifier app-db \
  --engine postgres --db-instance-class db.t3.micro \
  --allocated-storage 20 --master-username admin \
  --manage-master-user-password --no-publicly-accessible''', "correct", "Private and with a managed password. For production you would add a subnet group, Multi-AZ, backup retention and encryption."),
 ("You need a production-ready Postgres for an API.", [
  ("Make a Postgres database that I can connect to from anywhere.", False, "Public access is the risk to avoid."),
  ("Write CDK for an RDS PostgreSQL instance in private subnets, Multi-AZ, encrypted storage, 7-day backups, master password managed in Secrets Manager, reachable only from the API's security group.", True, "Covers network, availability, recovery and secrets."),
  ("Create an RDS database.", False, "Leaves security to defaults and guesses.")]))

dynamodb = T("dynamodb", "⚡", "DynamoDB: access-pattern-first NoSQL",
 "DynamoDB is a serverless key-value and document database. You design tables around the queries you need: a partition key (and optional sort key) finds items fast at any scale.",
 "AI often models DynamoDB like SQL, which leads to scans, hot partitions and large bills.",
 ["List your access patterns first, then choose the partition and sort keys.",
  "Query and GetItem use the key and are cheap. Scan reads the whole table and is expensive.",
  "On-demand capacity suits spiky or unknown traffic. Provisioned capacity with auto scaling suits steady traffic.",
  "A low-cardinality partition key (like status) creates hot partitions. Use high-cardinality keys."],
 ["AI uses Scan for lookups.", "AI picks partition keys like status or date.", "AI ignores capacity mode and TTL."],
 V(fcc="Databases: NoSQL Database Services, DynamoDB Follow Along.", uq="amazon dynamodb data modeling", yq="DynamoDB single table design access patterns"),
 [("Which is generally the cheapest way to fetch an item by key?", ["Scan", "GetItem or Query", "Full export", "Batch scan"], 1, "Key lookups read only the items needed."),
  ("Which is the worst partition key?", ["userId", "orderId", "status (3 values)", "sessionId"], 2, "Few distinct values concentrate traffic on a few partitions."),
  ("On-demand capacity is best for...", ["Steady predictable traffic", "Unpredictable or spiky traffic", "Nothing, it is deprecated", "Only global tables"], 1, "On-demand scales with traffic and bills per request.")],
 ("Find a customer's orders", r'''
const res = await ddb.send(new ScanCommand({
  TableName: "Orders",
  FilterExpression: "customerId = :c",
  ExpressionAttributeValues: { ":c": { S: id } },
}));''', 0, "Scan reads every item and filters afterward. Query by customerId (partition key or a GSI) instead."),
 ("Get all orders for a customer.", r'''
await ddb.send(new QueryCommand({
  TableName: "Orders",
  KeyConditionExpression: "customerId = :c",
  ExpressionAttributeValues: { ":c": { S: id } },
}));''', "correct", "A Query on the partition key is the right pattern, assuming customerId is the table's partition key."),
 ("Model orders so you can fetch a customer's orders by date.", [
  ("Create a table and use Scan with filters.", False, "Scans get slower and costlier as data grows."),
  ("Design a DynamoDB table with partition key customerId and sort key orderDate, on-demand capacity, with Query examples for 'latest 10 orders' and 'orders in March'. No Scan.", True, "Key design comes from the access patterns."),
  ("Make a flexible table where I can query anything.", False, "DynamoDB is not flexible that way.")]))

secrets = T("secrets", "🔑", "Secrets Manager, Parameter Store & KMS",
 "Secrets Manager stores and rotates secrets such as database passwords. Systems Manager Parameter Store holds configuration and low-cost secure strings. KMS manages the encryption keys behind S3, EBS, RDS and secrets.",
 "Leaked secrets are the fastest route to an AWS breach, and AI code samples love inline credentials.",
 ["Never put secrets in code, git, container images or AI prompts.",
  "Fetch secrets at runtime through an IAM role. Secrets Manager can rotate them automatically.",
  "Use Parameter Store for configuration and cheap secure strings. Use Secrets Manager when you need rotation.",
  "KMS keys control who can decrypt. Encrypt data at rest by default and use HTTPS in transit."],
 ["AI pastes API keys into code or .env files that get committed.", "AI logs secrets while debugging.", "AI forgets the role's KMS or secret permissions."],
 V(fcc="Security: Encryption, Cryptographic Keys, AWS KMS and AWS KMS Follow Along.", uq="aws secrets manager kms", yq="AWS Secrets Manager vs Parameter Store"),
 [("Where should a Lambda get its database password at runtime?", ["A hard-coded constant", "Secrets Manager through its execution role", "A public S3 file", "The function name"], 1, "The role fetches it at runtime, so nothing is stored in code."),
  ("Which service can rotate a database password automatically?", ["Secrets Manager", "Route 53", "CloudFront", "Cost Explorer"], 0, "Secrets Manager supports automatic rotation."),
  ("What does KMS manage?", ["Encryption keys", "IP addresses", "Billing alerts", "DNS records"], 0, "KMS creates and controls encryption keys.")],
 ("Call a payments API", r'''
API_KEY = "sk_live_51Hxxxxxxxx"
requests.get(url, headers={"Authorization": API_KEY})''', 0, "A live key in source code leaks through git, logs and screenshots. Load it from Secrets Manager."),
 ("Read the DB password safely in Lambda.", r'''
sm = boto3.client("secretsmanager")
secret = json.loads(sm.get_secret_value(SecretId="prod/app/db")["SecretString"])''', "correct", "It fetches at runtime through the role. Cache it between invocations and never log it."),
 ("Your Lambda calls a third-party API that needs a key.", [
  ("Put the key in an environment variable in the template.", False, "It would sit in the template and git history."),
  ("Store the key in Secrets Manager, give the Lambda's role secretsmanager:GetSecretValue on that one secret only, and write Python that fetches and caches it. Never log the value.", True, "Secure storage, minimum permission and a no-logging rule."),
  ("Hard-code the key so it is fast.", False, "Never hard-code secrets.")]))

edge = T("edge", "🌍", "Route 53, CloudFront & HTTPS (ACM)",
 "Route 53 is AWS DNS. CloudFront is a CDN that caches content at edge locations. ACM issues free public TLS certificates for CloudFront, load balancers and API Gateway.",
 "A custom domain with HTTPS is a routine task AI can script, but certificate Regions and DNS validation often trip it up.",
 ["Alias records in Route 53 point a domain at AWS resources such as CloudFront or an ALB.",
  "CloudFront caches near users and can keep an S3 origin private using origin access control.",
  "An ACM certificate for CloudFront must be requested in us-east-1. For a load balancer or API Gateway, request it in the resource's Region.",
  "Use DNS validation so certificate renewal is automatic."],
 ["AI requests the certificate in the wrong Region.", "AI makes the S3 bucket public instead of using origin access control.", "AI forgets the DNS validation records."],
 V(fcc="Networking: AWS CloudFront. Global Infrastructure: Points of Presence.", uq="aws route 53 cloudfront acm https", yq="host static website S3 CloudFront Route 53 HTTPS"),
 [("In which Region must an ACM certificate for CloudFront be requested?", ["Any Region", "us-east-1", "eu-west-1", "The bucket's Region"], 1, "CloudFront only uses certificates from us-east-1."),
  ("How can CloudFront serve a private S3 bucket?", ["Make the bucket public", "Origin access control", "Share access keys", "Use a NAT gateway"], 1, "OAC lets only that distribution read the bucket."),
  ("What does a CDN do?", ["Stores databases", "Caches content close to users", "Issues IAM policies", "Runs containers"], 1, "It lowers latency and origin load.")],
 ("Certificate for the site's CloudFront distribution", r'''
aws acm request-certificate --domain-name app.example.com \
  --validation-method DNS --region eu-west-1
# the certificate is for a CloudFront distribution''', 1, "CloudFront needs the certificate in us-east-1, not eu-west-1."),
 ("Serve my static site privately from S3 over HTTPS.", r'''
{
  "Effect": "Allow",
  "Principal": {"Service": "cloudfront.amazonaws.com"},
  "Action": "s3:GetObject",
  "Resource": "arn:aws:s3:::my-site/*",
  "Condition": {"StringEquals": {"AWS:SourceArn": "arn:aws:cloudfront::123456789012:distribution/E123"}}
}''', "correct", "Only that CloudFront distribution can read the private bucket."),
 ("Put a static site on a custom domain with HTTPS.", [
  ("Make the bucket public and point the domain at it.", False, "Public bucket, and S3 website endpoints don't do HTTPS."),
  ("Write CDK for a private S3 bucket behind CloudFront with origin access control, an ACM certificate in us-east-1 validated by DNS, and a Route 53 alias record for www.example.com.", True, "Private origin, correct certificate Region and DNS setup."),
  ("Set up hosting for my site.", False, "Too vague.")]))

lambda_ = T("lambda", "λ", "Lambda: functions, roles & limits",
 "Lambda runs your code on demand without servers. You configure memory (which also scales CPU), a timeout and an execution role. You pay per request and per millisecond of run time.",
 "Lambda is the default AI picks for AWS backends, so you need to review roles, timeouts and any loop that can run up a bill.",
 ["The execution role decides what the function can access. Keep it least-privilege.",
  "Timeout (maximum 15 minutes) and memory are the main tuning knobs. More memory also means more CPU.",
  "Cold starts add latency on a first invocation. Keep packages small and avoid heavy work at start-up.",
  "Functions are stateless and can run many copies at once. Make handlers idempotent and set concurrency limits to protect downstream systems."],
 ["AI gives the function administrator access.", "AI sets maximum timeout and memory 'to be safe'.", "AI creates a function that triggers itself, such as writing back to the bucket that invokes it."],
 V(fcc="Serverless: What is Serverless, Serverless Services.", uq="aws lambda", yq="AWS Lambda tutorial Python S3 trigger IAM role"),
 [("What does increasing Lambda memory also do?", ["Nothing else", "Increases CPU proportionally", "Lowers the price", "Raises the timeout limit"], 1, "CPU scales with the memory setting."),
  ("What is the maximum Lambda timeout?", ["30 seconds", "5 minutes", "15 minutes", "1 hour"], 2, "15 minutes (900 seconds)."),
  ("What controls which AWS services a function can call?", ["Its execution role", "Its name", "Its runtime", "Its memory"], 0, "The execution role grants the permissions.")],
 ("Thumbnail function", r'''
# Trigger: s3:ObjectCreated on bucket "images"
def handler(event, context):
    key = event["Records"][0]["s3"]["object"]["key"]
    s3.put_object(Bucket="images", Key="thumb-" + key, Body=make_thumb(key))''', 3, "Writing back to the same bucket triggers the function again, forever. Use a separate bucket or a prefix filter."),
 ("Process each uploaded file and save a summary.", r'''
def handler(event, context):
    for r in event["Records"]:
        process(r["s3"]["object"]["key"])
    return {"statusCode": 200}''', "subtle", "S3 can deliver an event more than once, so process() must be idempotent, and object keys arrive URL-encoded, so decode them with unquote_plus."),
 ("Create a Lambda that resizes uploaded images.", [
  ("Write a Lambda for images with admin permissions so nothing fails.", False, "Admin access violates least privilege."),
  ("Write a Python Lambda triggered by uploads to bucket 'uploads' that writes thumbnails to a different bucket 'thumbs', 512 MB, 30-second timeout, a role with only GetObject on uploads and PutObject on thumbs, idempotent, with structured logging.", True, "Avoids the loop and bounds the permissions, memory and time."),
  ("Make an image Lambda.", False, "Too vague.")]))

apigw = T("apigw", "🚪", "API Gateway: exposing Lambda as an API",
 "API Gateway gives managed HTTPS endpoints in front of Lambda or other backends. HTTP APIs are cheaper and simpler. REST APIs have more features such as usage plans and request validation. It handles authorization, throttling and CORS settings.",
 "An API without authorization is a public endpoint anyone can call and bill you for.",
 ["Use HTTP APIs unless you need REST API features.",
  "Add authorization: JWT with Cognito, IAM, or a Lambda authorizer.",
  "Set throttling limits and alarms to control abuse and cost.",
  "CORS only controls browser cross-origin access. It is not a security control."],
 ["AI deploys an API with no authorizer.", "AI sets CORS to allow every origin.", "AI forgets throttling and access logs."],
 V(fcc="Application Integration: API Gateway and Amazon API Gateway.", uq="aws api gateway lambda", yq="API Gateway HTTP API Lambda Cognito JWT authorizer"),
 [("Which is generally cheaper and simpler for a Lambda backend?", ["REST API", "HTTP API", "EC2", "Neither"], 1, "HTTP APIs have lower cost and fewer features."),
  ("Does CORS protect your API from unauthorized callers?", ["Yes", "No, it only controls browser cross-origin access", "Only for POST", "Only with HTTPS"], 1, "Non-browser clients ignore CORS entirely."),
  ("Which can authenticate API callers?", ["A Cognito JWT authorizer", "Route 53", "A CloudFront price class", "S3 versioning"], 0, "JWT authorizers validate tokens before the backend runs.")],
 ("Method that creates orders", r'''
aws apigateway put-method --rest-api-id abc123 --resource-id res456 \
  --http-method POST \
  --authorization-type NONE''', 2, "Anyone on the internet can create orders. Use an authorizer."),
 ("Add an API for my Lambda.", r'''
Events:
  Orders:
    Type: HttpApi
    Properties:
      Path: /orders
      Method: GET''', "subtle", "It works, but there is no authorizer or throttling, so the endpoint is open to everyone."),
 ("Expose a Lambda as a secure JSON API.", [
  ("Create an open API so the frontend can call it easily.", False, "Open APIs invite abuse."),
  ("Write SAM for an HTTP API in front of a Python Lambda with a Cognito JWT authorizer, CORS limited to https://app.example.com, throttling at 50 requests per second, and access logs to CloudWatch.", True, "Auth, CORS, throttling and logging are all specified."),
  ("Make an API Gateway.", False, "Too vague.")]))

messaging = T("messaging", "📬", "SQS, SNS & EventBridge: decoupling",
 "SQS is a queue where producers send messages and consumers poll them. SNS publishes one message to many subscribers. EventBridge routes events by rules from AWS services and your applications.",
 "Decoupling is how serverless apps survive spikes and failures. AI often forgets the failure handling that makes it work.",
 ["SQS absorbs spikes and lets you retry. Standard queues deliver at least once, so consumers must be idempotent.",
  "SNS fans out one event to many subscribers. EventBridge filters and routes events between services.",
  "Attach a dead-letter queue (DLQ) so poison messages stop looping.",
  "Set the queue's visibility timeout comfortably above the consumer's processing time. For Lambda, AWS recommends at least six times the function timeout."],
 ["AI skips DLQs and idempotency.", "AI sets the visibility timeout shorter than the Lambda timeout, causing duplicate processing.", "AI uses SQS where SNS fan-out is needed, or the reverse."],
 V(fcc="Application Integration: Queueing and SQS, Pub Sub and SNS, Event Bus and Amazon Event Bridge.", uq="aws sqs sns eventbridge", yq="SQS SNS EventBridge difference when to use"),
 [("Which service delivers one event to many subscribers?", ["SQS", "SNS", "S3", "Route 53"], 1, "SNS fans out to all subscribers."),
  ("Standard SQS queues deliver messages...", ["Exactly once always", "At least once, sometimes more than once", "Never twice", "Strictly in order"], 1, "Duplicates are possible, so make consumers idempotent."),
  ("What is a DLQ for?", ["Faster delivery", "Holding messages that repeatedly fail", "Encrypting messages", "Replacing SNS"], 1, "It isolates failing messages for inspection.")],
 ("Jobs queue", r'''
resource "aws_sqs_queue" "jobs" {
  name                       = "jobs"
  visibility_timeout_seconds = 5
}
# the consumer Lambda has a 60 second timeout''', 2, "A 5-second visibility timeout is shorter than the consumer's runtime, so messages are redelivered while still being processed."),
 ("Retry failed order messages safely.", r'''
resource "aws_sqs_queue" "orders" {
  name = "orders"
  redrive_policy = jsonencode({
    deadLetterTargetArn = aws_sqs_queue.orders_dlq.arn
    maxReceiveCount     = 5
  })
}''', "correct", "After five failed receives, the message moves to a DLQ."),
 ("Process order events reliably.", [
  ("Have the API call the processing Lambda directly and retry in a loop.", False, "A loop in the request path loses messages and adds latency."),
  ("Create an SQS queue with a DLQ (maxReceiveCount 5) feeding a Lambda. Make the handler idempotent by order ID, report partial batch failures, and set the visibility timeout to at least 6x the function timeout.", True, "Covers retries, duplicates and timeout safety."),
  ("Use a queue.", False, "Too vague.")]))

stepfn = T("stepfn", "🧭", "Step Functions: orchestrating workflows",
 "Step Functions coordinates multiple steps (Lambda calls, AWS service calls, waits, retries and branches) as a state machine defined in Amazon States Language.",
 "Chaining Lambdas by hand hides failures. A workflow makes retries, branches and errors explicit and visible.",
 ["Use it when a task has several steps, retries, waits or branches, rather than chaining Lambdas.",
  "Standard workflows suit long-running, auditable flows. Express workflows suit high-volume, short flows.",
  "Define Retry and Catch on states so failures are handled, not lost.",
  "Retrying a step that has side effects, like a payment, needs an idempotency key."],
 ["AI chains Lambdas by calling each from the previous one.", "AI omits Retry and Catch.", "AI retries payment steps with no idempotency."],
 V(fcc="Application Integration: State Machines and AWS Step Functions.", uq="aws step functions", yq="AWS Step Functions tutorial retry catch"),
 [("What defines a Step Functions workflow?", ["A state machine in Amazon States Language", "An IAM policy", "A route table", "A CloudFront behavior"], 0, "States and transitions define it."),
  ("Express workflows are for...", ["Long-running, rare flows", "High-volume, short flows", "Only human approval", "Billing reports"], 1, "Express is built for high-rate, short executions."),
  ("Why add Retry and Catch?", ["Speed", "Handle transient failures and route errors", "Reduce IAM needs", "Encrypt state"], 1, "They make failure handling explicit.")],
 ("Payment step", r'''
{
  "StartAt": "Charge",
  "States": {
    "Charge": { "Type": "Task", "Resource": "arn:aws:lambda:eu-west-1:123456789012:function:charge", "End": true }
  }
}''', 3, "No Retry or Catch. A transient failure ends the whole execution with no handling."),
 ("Charge the card, then send a receipt, retrying on failure.", r'''
"Charge": {
  "Type": "Task",
  "Resource": "arn:aws:lambda:eu-west-1:123456789012:function:charge",
  "Retry": [{ "ErrorEquals": ["States.TaskFailed"], "MaxAttempts": 3, "BackoffRate": 2 }],
  "Next": "SendReceipt"
}''', "subtle", "Retrying a charge can double-charge unless the Lambda uses an idempotency key. There is also no Catch for the final failure."),
 ("Build an order workflow.", [
  ("Chain three Lambdas, each calling the next.", False, "No visibility, retries or error handling."),
  ("Write a Step Functions definition: validate order, charge payment (3 retries with backoff, idempotency key = order ID), then email a receipt. A Catch state should mark the order failed.", True, "Explicit retries, idempotency and failure routing."),
  ("Make a workflow for orders.", False, "Too vague.")]))

sam = T("sam", "📦", "SAM: build & deploy serverless apps",
 "AWS SAM is a CloudFormation extension for serverless apps. A short template defines functions, APIs and tables, and the SAM CLI builds, tests locally and deploys.",
 "SAM is a quick way for AI to produce a whole serverless stack, and a concise template is easy to review.",
 ["sam build, sam local invoke, sam deploy --guided and sam delete are the main commands.",
  "SAM expands to CloudFormation, so you can review changes before executing them.",
  "Use SAM policy templates (such as DynamoDBCrudPolicy) for scoped permissions instead of broad managed policies.",
  "Keep one config per environment and delete test stacks when finished."],
 ["AI attaches broad managed policies.", "AI hard-codes ARNs and account IDs.", "AI never mentions sam delete."],
 V(uq="aws sam serverless application model", yq="AWS SAM CLI tutorial deploy Lambda API Gateway DynamoDB"),
 [("What does SAM expand to?", ["Terraform", "CloudFormation", "Docker Compose", "Kubernetes"], 1, "SAM is a CloudFormation transform."),
  ("Which command removes a deployed SAM app?", ["sam delete", "sam remove", "sam clean", "sam rm"], 0, "sam delete deletes the CloudFormation stack."),
  ("What gives scoped permissions to one table?", ["SAM policy templates", "Root access", "AdministratorAccess", "A public bucket"], 0, "Templates like DynamoDBCrudPolicy limit access to the named table.")],
 ("Function permissions", r'''
Policies:
  - AdministratorAccess''', 1, "Administrator access for a function is far too broad. Use a scoped policy template."),
 ("Let my function read and write one table.", r'''
Policies:
  - DynamoDBCrudPolicy:
      TableName: !Ref OrdersTable''', "correct", "The policy is limited to that single table."),
 ("Create a small serverless app.", [
  ("Write a SAM template with admin permissions so nothing breaks.", False, "Admin access is not acceptable."),
  ("Write a SAM template: Python Lambda, HTTP API and a DynamoDB table with on-demand billing. Use SAM policy templates scoped to that table, and give the commands to build, deploy and delete.", True, "Scoped permissions and full lifecycle commands."),
  ("Make a serverless app.", False, "Too vague.")]))

PART1 = [ai_workflow, vpc, rds, dynamodb, secrets, edge, lambda_, apigw, messaging, stepfn, sam]
