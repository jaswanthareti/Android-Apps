# DailyStack: learn AWS in the AI era (Android, Kotlin + Jetpack Compose)

A 40-day AWS plan (one topic per day, 1+ hour) focused on directing AI tools and verifying their work,
plus a place to add your own courses.

## Run it
Open in Android Studio and run on Android 8.0+. CI: `.github/workflows/build.yaml` builds the debug APK.

## App structure (matches the mascot mockup)
- Onboarding: welcome, goal, level, name.
- Bottom tabs: Home (greeting, level, continue card, stats, path), Learn (courses, weeks, progress, certificates),
  Practice (Quick Quiz, Code Lab, Scenario Challenge, Exam Style), Profile (stats, progress, achievements,
  certificates, courses, rewards, settings).
- Day gating: one new day per calendar day. Any unlocked day opens a lesson page with videos, documents, labs,
  a copyable AI prompt and notes.
- Lesson flow: check quiz -> notes/video/materials tabs -> spot the bug -> review AI output -> pick the best prompt.
- XP, levels, streaks with freezes, spaced repetition, 20-20-20 eye breaks, self-funded rewards, daily reminder.

## Adding courses (Learn tab -> "Add course", or Profile -> Courses)
1. Copy the built-in prompt, give it to your AI assistant, paste the JSON reply.
2. Or import a .json file, or paste JSON directly.
3. Or "Quick add": one line per day: `Day title | video link | document link`.
Added courses are stored on the device (files/courses). YouTube links play in-app; Udemy links open in the Udemy app.
Format: see `CourseImport.AI_PROMPT` in `CourseImport.kt`.

## Built-in content
`python3 gen_content.py` rebuilds `app/src/main/assets/courses/aws.json` from `part0.py` .. `part4.py`.
Drop more built-in courses into `assets/courses/*.json` (same shape as aws.json).
