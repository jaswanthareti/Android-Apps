# DailyStack: daily full stack learning (Android, Kotlin + Jetpack Compose)

## Run it
1. Open this folder in Android Studio (Ladybug or newer). Let Gradle sync (it downloads dependencies and the wrapper).
2. Run on a device or emulator (Android 8.0+).

## What's in this build
- Daily session: review due cards -> "Check yourself" quiz -> (lesson + video only if you missed something) -> spot-the-bug -> review AI output -> pick the best prompt.
- Videos play inside the app (YouTube, via android-youtube-player). Udemy lectures open in a Chrome Custom Tab.
- Spaced repetition (1/3/7/14/30 days), XP and levels with a daily cap, streaks with freeze days, daily goal ring.
- 20-20-20 eye break every 20 active minutes of a session (20 seconds, "look 20 meters away"); long-press to skip.
- Self-funded rewards store (add your own rewards, redeem with points).
- Daily reminder notification (time adjustable in settings).
- Fully offline lessons and quizzes (bundled in assets/content.json).

## Adding content
Edit `gen_content.py` (or `app/src/main/assets/content.json` directly) and run `python3 gen_content.py`.
Each topic has: lesson text, `videos` (kind "youtube" with an `id`, optional `startSec`/`endSec`; or kind "udemy"/"link" with a `url`), `checks`, `bugs`, `aiReviews`, `prompts`.

## Not built yet
Weekly boss challenge, weeks 2-4 content, Udemy break reminders (Custom Tabs run outside the app), video-rating-driven ordering.
