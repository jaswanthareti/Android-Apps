# DailyStack: learn AWS in the AI era (Android, Kotlin + Jetpack Compose)

A 40-day plan (8 weeks, one topic per day, 1+ hour) focused on getting AI to do AWS development
tasks while you direct, review and verify. You are not learning every service; you are learning
what to ask for, what good output looks like, and where AI goes wrong.

## Run it
Open this folder in Android Studio and run on a device or emulator (Android 8.0+).
CI: `.github/workflows/build.yaml` builds the debug APK on GitHub Actions.

## Curriculum
1. Foundations and working with AI: cloud basics and billing safety, IAM, S3, EC2, the safe AI loop
2. Networking, data, edge: VPC, RDS, DynamoDB, secrets/KMS, Route 53/CloudFront/ACM
3. Serverless and messaging: Lambda, API Gateway, SQS/SNS/EventBridge, Step Functions, SAM
4. Infrastructure as code and CI/CD: CloudFormation, CDK, Terraform, GitHub Actions OIDC, reviewing AI infrastructure
5. Compute, containers, storage: choosing compute, ECS/Fargate, ALB/Auto Scaling, Amplify, EBS/EFS/S3
6. Operations: CloudWatch, CloudTrail/Config, debugging with AI, backup/DR, cost control
7. Security at scale: baseline, Access Analyzer, Organizations/SCPs, Cognito, WAF
8. AI on AWS: Bedrock, RAG, agents and guardrails, AI dev tools and MCP, capstone

## Each day
Check-yourself quiz (skip the lesson if you pass) -> lesson -> video -> spot-the-bug -> review the
AI output -> pick the best prompt. Plus: spaced repetition, XP/levels, streaks with freezes, daily goal
ring, 20-20-20 eye breaks, self-funded rewards store, daily reminder.

## Videos
- YouTube plays in-app (own WebView embed with a valid origin) and always has "Open in YouTube".
- Udemy links open in the Udemy app/browser where you are logged in. Topics beyond the verified
  course use Udemy and YouTube search links, since lecture URLs can't be verified without your login.

## Content
`python3 gen_content.py` rebuilds `app/src/main/assets/content.json` from `part0.py` .. `part4.py`
(it validates that every planted bug line is correct). Add or replace a video in a topic's `V(...)` call.
