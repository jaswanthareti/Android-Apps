from part0 import *

cloudwatch = T("cloudwatch", "📈", "CloudWatch: logs, metrics & alarms",
 "CloudWatch collects logs and metrics from AWS services and your apps. Alarms watch metrics and notify you or trigger actions, and Logs Insights lets you query logs.",
 "When something breaks, logs and metrics are the evidence you give an AI to diagnose it. Good logging makes AI debugging far better.",
 ["Logs live in log groups. Set a retention period, because the default keeps logs forever and costs money.",
  "Metrics such as Lambda Errors, API 5xx and CPU feed alarms that notify through SNS.",
  "Logs Insights queries filter and aggregate logs with a SQL-like syntax.",
  "Write structured JSON logs and never log secrets or personal data."],
 ["AI logs secrets or full request bodies.", "AI forgets log retention and alarms.", "AI sets alarms on the wrong metric or period."],
 V(fcc="Logging: CloudWatch Alarm, Log Streams and Events, Log Insights, CloudWatch Metrics.", uq="aws cloudwatch logs insights", yq="CloudWatch Logs Insights queries tutorial"),
 [("What does the default log group retention do?", ["Deletes after 1 day", "Keeps logs forever", "Keeps 30 days", "Disables logging"], 1, "The default never expires, so costs accumulate."),
  ("What notifies you when a metric crosses a threshold?", ["A CloudWatch alarm", "A security group", "A route table", "A tag"], 0, "Alarms evaluate metrics and trigger actions."),
  ("What is a good logging format for easy filtering?", ["Structured JSON", "Free text paragraphs", "Binary", "Screenshots"], 0, "Fields can be queried and aggregated.")],
 ("Calling the payments API", r'''
api_key = secrets.get("payments")
logger.info("Calling payments API with key %s", api_key)''', 1, "Logging the key puts a secret in CloudWatch, where many people and tools can read it."),
 ("Alert me when my Lambda fails.", r'''
aws cloudwatch put-metric-alarm --alarm-name api-errors \
  --namespace AWS/Lambda --metric-name Errors \
  --dimensions Name=FunctionName,Value=api \
  --statistic Sum --period 300 --evaluation-periods 1 \
  --threshold 1 --comparison-operator GreaterThanOrEqualToThreshold \
  --alarm-actions arn:aws:sns:eu-west-1:123456789012:oncall''', "correct", "It alarms on Lambda errors and notifies an SNS topic."),
 ("Find out why a Lambda is failing.", [
  ("Why is my Lambda broken?", False, "No evidence, so the AI will guess."),
  ("Here are the last 50 log lines and the Errors metric graph. List the likely causes, give a Logs Insights query to confirm each, and suggest the smallest fix. Say what you cannot know from this evidence.", True, "Evidence in, hypotheses and verification out."),
  ("Fix my Lambda.", False, "Vague and risky.")]))

audit = T("audit", "🕵️", "CloudTrail & Config: who changed what",
 "CloudTrail records API calls made in your account. AWS Config records resource configurations and checks them against rules.",
 "When an AI tool or a teammate changes something, CloudTrail is how you find out what happened and who did it.",
 ["CloudTrail Event history keeps 90 days of management events. Create a trail to keep them longer in S3.",
  "Use a multi-Region trail so activity in every Region is captured.",
  "Config tracks configuration changes over time and flags non-compliant resources such as public buckets.",
  "Search with lookup-events, CloudTrail Lake or Athena."],
 ["AI creates single-Region trails.", "AI forgets log file validation and protected storage.", "AI gives wrong event names for investigations."],
 V(fcc="Logging: AWS CloudTrail and Follow Along. Governance: AWS Config.", uq="aws cloudtrail config", yq="CloudTrail lookup events investigate who deleted"),
 [("How long does CloudTrail Event history keep management events?", ["24 hours", "90 days", "1 year", "Forever"], 1, "For longer retention, create a trail."),
  ("Which service tracks resource configuration changes and compliance?", ["AWS Config", "Route 53", "CloudFront", "SQS"], 0, "Config records configuration history and evaluates rules."),
  ("What is a good trail setting for full coverage?", ["Single Region only", "Multi-Region", "Disabled", "Per user"], 1, "A multi-Region trail captures every Region.")],
 ("Create the audit trail", r'''
# requirement: capture activity in every Region
aws cloudtrail create-trail --name audit --s3-bucket-name audit-logs''', 1, "Without --is-multi-region-trail the trail only covers one Region."),
 ("Who deleted my S3 bucket?", r'''
aws cloudtrail lookup-events --lookup-attributes AttributeKey=EventName,AttributeValue=DeleteBucket''', "correct", "That finds DeleteBucket events with the principal and source IP. Event history only goes back 90 days."),
 ("Investigate an unexpected change.", [
  ("Who did this?", False, "No event or time range."),
  ("Give me the steps and a lookup-events command to find who called DeleteBucket in the last 7 days, including the IAM principal and source IP, and show how to enable a multi-Region trail so future events are kept in S3.", True, "Specific event, time window and follow-up."),
  ("Check the logs.", False, "Too vague.")]))

debug = T("debug", "🧪", "Debugging AWS issues with AI",
 "AI is a strong debugging partner when you give it evidence: the exact error, the relevant logs, the policy or configuration, and the service and Region.",
 "Most AWS problems are permissions, networking or limits. AI finds these quickly if you ask for hypotheses and verification, and badly if you accept 'give it admin'.",
 ["Give the AI the exact error text, the relevant log lines and the config. Redact secrets and account IDs when you can.",
  "Common causes: AccessDenied (IAM, resource policy or SCP), timeouts (security group, route or NAT), throttling (limits).",
  "Ask for a list of hypotheses and how to verify each, using the IAM policy simulator, CloudTrail or VPC Reachability Analyzer, before changing anything.",
  "Never accept 'attach AdministratorAccess' as the fix."],
 ["AI guesses without evidence.", "AI proposes admin access to silence AccessDenied.", "AI raises the timeout when the real issue is a missing route."],
 V(uq="aws troubleshooting", yq="AWS AccessDenied troubleshooting IAM policy simulator CloudTrail"),
 [("What is the first thing to give an AI to debug an AWS error?", ["The exact error and relevant logs", "Your root password", "A screenshot of the console home", "Nothing"], 0, "Evidence enables specific hypotheses."),
  ("A Lambda in a private subnet times out calling the internet. A likely cause is...", ["A missing NAT gateway or route", "Too few log groups", "An unpinned image", "A wrong tag"], 0, "Private subnets need a NAT gateway for outbound internet."),
  ("Which tool can test whether a policy allows an action?", ["IAM policy simulator", "Route 53", "CloudFront", "Cost Explorer"], 0, "It evaluates policies without making the call.")],
 ("AI's suggested fix for AccessDenied on s3:GetObject", r'''
# suggested by the AI
aws iam attach-role-policy --role-name app --policy-arn arn:aws:iam::aws:policy/AdministratorAccess''', 1, "Admin access removes the error by removing every limit. Add only s3:GetObject on the specific bucket."),
 ("My Lambda times out calling a third-party API.", r'''
Timeout: 900''', "subtle", "Raising the timeout hides the problem. A Lambda in a private subnet without a NAT route cannot reach the internet, so it will just wait longer."),
 ("Debug an AccessDenied error.", [
  ("Make the role an administrator so it works.", False, "That bypasses the problem."),
  ("My Lambda gets AccessDenied on s3:GetObject. Here are the error, the role policy and the bucket policy. List the possible causes in order of likelihood and how to check each with CloudTrail or the policy simulator, then propose the smallest policy change.", True, "Evidence, ranked hypotheses and a minimal fix."),
  ("Fix AccessDenied.", False, "No context.")]))

backup = T("backup", "🛟", "Backups & disaster recovery (RTO/RPO)",
 "RPO is how much data you can afford to lose. RTO is how long you can be down. Your backup and recovery design follows from those two numbers.",
 "AI will cheerfully produce a backup plan with no restore test and everything in one account and Region.",
 ["Strategies, in rising cost: backup and restore, pilot light, warm standby, active-active.",
  "AWS Backup centralizes backup schedules and retention for many services.",
  "Copy critical backups to another Region or account, and test restores regularly.",
  "RDS automated backups and S3 versioning are built-in protections. Turning backup retention to zero disables point-in-time recovery."],
 ["AI sets retention to 0 or skips backups for 'cost'.", "AI keeps backups in the same account and Region as production.", "AI never mentions testing a restore."],
 V(fcc="Cloud Architecture: Business Continuity Plan, Disaster Recovery Options, RTO and RPO Visualized.", uq="aws backup disaster recovery", yq="AWS disaster recovery strategies RTO RPO"),
 [("RPO describes...", ["Acceptable data loss", "Acceptable downtime", "Monthly cost", "Request rate"], 0, "Recovery Point Objective is how much data loss is tolerable."),
  ("Which strategy has the lowest cost but slowest recovery?", ["Backup and restore", "Warm standby", "Active-active", "Pilot light with full capacity"], 0, "It keeps only backups until a disaster."),
  ("What is the most important test of a backup?", ["Restoring from it", "Counting the files", "Checking the tag", "Renaming it"], 0, "An untested backup may not work.")],
 ("Turn off database backups to save money", r'''
aws rds modify-db-instance --db-instance-identifier prod-db \
  --backup-retention-period 0 --apply-immediately''', 1, "Retention 0 disables automated backups and point-in-time recovery."),
 ("Backup plan for prod data.", r'''
Schedule: daily 03:00 UTC
Retention: 7 days
Vault: default (same account, same Region)''', "subtle", "A single account and Region is a single point of failure, and the plan doesn't test restores. Add a copy to another Region or account and schedule restore tests."),
 ("Design recovery for a business app.", [
  ("Back up everything daily and hope for the best.", False, "No RPO, RTO or restore test."),
  ("Our RPO is 1 hour and RTO is 4 hours for an RDS-backed API. Propose a recovery design with backup frequency, cross-Region copies, a restore test schedule, and the approximate cost trade-offs.", True, "Starts from the objectives and covers testing."),
  ("Set up backups.", False, "Too vague.")]))

cost = T("cost", "💰", "Cost control: budgets, tags & cleanup",
 "Cost Explorer shows where money goes. Budgets alert you before limits are hit. Cost allocation tags attribute spend to projects. Cleanup stops charges.",
 "AI creates resources quickly and rarely tells you what they cost. This is the day that saves you from a nasty bill.",
 ["Set an AWS Budget with email alerts on day one, and activate cost allocation tags such as Project and Owner.",
  "Common surprise costs: NAT gateways, idle EC2 and EBS, unattached Elastic IPs, data transfer, oversized databases and log retention.",
  "Savings Plans or reserved capacity help for steady workloads, not experiments.",
  "Use infrastructure as code to destroy test stacks, and review Cost Explorer regularly."],
 ["AI creates a NAT gateway in every AZ for a demo.", "AI leaves resources untagged and running.", "AI quotes prices from memory."],
 V(fcc="Billing and Pricing: AWS Budgets, Cost Explorer, Cost Allocation Tags, Savings Plans.", uq="aws cost optimization", yq="AWS cost optimization surprise bill NAT gateway"),
 [("Which service alerts you when spend passes a limit?", ["AWS Budgets", "AWS Config", "Amazon Inspector", "AWS Shield"], 0, "Budgets send alerts at thresholds."),
  ("Which is a common cause of surprise costs in a small project?", ["NAT gateways", "A tag", "A VPC", "An IAM user"], 0, "NAT gateways bill hourly plus per GB."),
  ("What do cost allocation tags do?", ["Attribute spend to projects", "Encrypt data", "Speed up queries", "Grant access"], 0, "They let you group costs.")],
 ("Dev sandbox network", r'''
for az in a b c; do
  aws ec2 create-nat-gateway --subnet-id subnet-$az --allocation-id eipalloc-$az
done
# environment: short-lived dev sandbox''', 1, "Three NAT gateways cost hourly plus data charges for a short-lived sandbox. One is plenty, or use VPC endpoints."),
 ("Keep my sandbox costs under control.", r'''
aws budgets create-budget --account-id 123456789012 \
  --budget file://budget.json \
  --notifications-with-subscribers file://notify.json''', "correct", "A budget with alert subscribers is the baseline. Check the budget.json limit and the email subscriber."),
 ("Estimate and limit cost for a new stack.", [
  ("Tell me what this will cost.", False, "AI may quote stale or invented prices."),
  ("List every billable resource in this template, the pricing dimension for each, and the ones most likely to surprise me. Tell me which numbers I must check on the AWS pricing page, and add Budget alerts and Project tags.", True, "Asks for dimensions, not guessed prices, plus controls."),
  ("Make it cheap.", False, "No target.")]))

secbase = T("secbase", "🛡️", "Security baseline: MFA, GuardDuty & Security Hub",
 "A baseline is the small set of controls every account should have: MFA, audit logging, threat detection and findings in one place.",
 "AI helps you build the baseline in minutes, but only if you know what belongs in it.",
 ["Enable MFA on the root user and all human users, and don't create root access keys.",
  "Turn on CloudTrail, GuardDuty (threat detection) and Security Hub (consolidated findings), and enable account-level S3 Block Public Access.",
  "Remove unused users and access keys, and prefer roles and SSO over long-lived keys.",
  "Review findings regularly. A finding nobody reads protects nothing."],
 ["AI skips MFA and logging.", "AI turns off Block Public Access.", "AI creates long-lived access keys."],
 V(fcc="Security: GuardDuty, Defense in Depth, Compliance and related chapters.", uq="aws security fundamentals", yq="AWS account security baseline GuardDuty Security Hub"),
 [("Which service detects threats such as unusual API calls?", ["GuardDuty", "Route 53", "CloudFront", "SNS"], 0, "GuardDuty analyzes logs for threats."),
  ("What should every root user have?", ["MFA", "Access keys", "A public key pair", "An EC2 instance"], 0, "Protect root with MFA and avoid access keys."),
  ("What does Security Hub provide?", ["Consolidated security findings", "DNS", "A database", "A CDN"], 0, "It aggregates findings across services.")],
 ("Allow public access at account level", r'''
aws s3control put-public-access-block --account-id 123456789012 \
  --public-access-block-configuration BlockPublicAcls=false,IgnorePublicAcls=false,BlockPublicPolicy=false,RestrictPublicBuckets=false''', 1, "Setting every flag to false removes the account-wide safety net."),
 ("Set up a security baseline for my new account.", r'''
aws guardduty create-detector --enable
aws securityhub enable-security-hub''', "subtle", "A good start, but the baseline also needs MFA on root, CloudTrail, account-level Block Public Access and a place where someone reads the findings."),
 ("Create a baseline for a new AWS account.", [
  ("Enable security services.", False, "No specifics."),
  ("Give me a checklist and the IaC to enable root MFA reminders, a multi-Region CloudTrail, GuardDuty, Security Hub, account-level S3 Block Public Access and a budget alarm, and tell me which parts need manual console steps.", True, "Covers the real baseline and its manual parts."),
  ("Make my account secure.", False, "Too broad.")]))

analyzer = T("analyzer", "🔬", "Least privilege in practice: Access Analyzer",
 "IAM Access Analyzer validates policies, finds resources shared outside your account, and can generate a least-privilege policy from CloudTrail activity. The policy simulator tests what a policy allows.",
 "AI drafts policies quickly and often too broad. These tools turn 'looks right' into 'checked'.",
 ["Ask AI to draft a policy, then validate it with Access Analyzer and test it with the policy simulator.",
  "Start with broader access in a sandbox, then generate a tighter policy from real usage.",
  "Use permission boundaries and SCPs as guardrails on the maximum permissions.",
  "Review external access findings for buckets, roles and keys shared outside your account."],
 ["AI keeps wildcard permissions after 'fixing' a policy.", "AI forgets resource-level restrictions.", "AI doesn't mention validation tools."],
 V(fcc="Identity: Principle of Least Privilege and IAM Policies Follow Along.", uq="aws iam access analyzer least privilege", yq="IAM Access Analyzer generate policy from CloudTrail"),
 [("Which tool can generate a policy from actual CloudTrail activity?", ["IAM Access Analyzer", "Route 53", "CloudFront", "SQS"], 0, "It builds a policy from observed actions."),
  ("What does the policy simulator do?", ["Tests whether a policy allows an action", "Deploys the policy", "Encrypts the policy", "Deletes the role"], 0, "It evaluates access without making the call."),
  ("An external-access finding means...", ["A resource is shared outside your account or organization", "A cost spike", "A slow Lambda", "A failed deploy"], 0, "Access Analyzer reports resources accessible externally.")],
 ("Tightened policy", r'''
{
  "Effect": "Allow",
  "Action": ["s3:GetObject", "s3:PutObject", "s3:DeleteObject"],
  "Resource": "*"
}''', 3, "The actions are narrower, but Resource * covers every bucket. Restrict to the specific bucket ARN."),
 ("Make this policy least-privilege.", r'''
{
  "Effect": "Allow",
  "Action": "dynamodb:*",
  "Resource": "arn:aws:dynamodb:eu-west-1:123456789012:table/Orders"
}''', "subtle", "It is scoped to one table, but dynamodb:* allows deleting the table. Limit to the specific actions the app needs, like GetItem and Query."),
 ("Tighten an IAM role.", [
  ("Make this role more secure.", False, "No input for the AI to work with."),
  ("Here is a role policy and 30 days of CloudTrail actions for the role. Propose a least-privilege replacement with specific actions and resource ARNs, and give me the Access Analyzer and simulator steps to validate it.", True, "Real usage data and validation steps."),
  ("Reduce the permissions.", False, "Unclear target.")]))

orgs = T("orgs", "🏢", "Organizations, SCPs & multi-account setup",
 "AWS Organizations groups multiple accounts. Service control policies (SCPs) set the maximum permissions for accounts. Control Tower sets up a recommended multi-account landing zone, and IAM Identity Center provides single sign-on.",
 "Real teams use several accounts (prod, dev, sandbox). Separate accounts are the strongest guardrail you can give AI tooling.",
 ["Use separate accounts for production, development and experiments.",
  "SCPs restrict what accounts can do. They do not grant permissions.",
  "IAM Identity Center gives people temporary access to accounts, avoiding long-lived users.",
  "Consolidated billing and tag policies keep costs and ownership clear."],
 ["AI puts everything in one account.", "AI treats an SCP as a way to grant access.", "AI creates IAM users per person."],
 V(fcc="Governance: Organizations and Accounts, AWS Control Tower, Tagging.", uq="aws organizations scp control tower", yq="AWS Organizations SCP multi account strategy"),
 [("Do SCPs grant permissions?", ["Yes", "No, they only set maximum permissions", "Only for root", "Only for S3"], 1, "An SCP can only restrict what accounts may do."),
  ("What is the safest place to let AI tools experiment?", ["A separate sandbox account", "The production account", "The management account", "A shared admin user"], 0, "A sandbox account isolates risk."),
  ("What provides single sign-on to many accounts?", ["IAM Identity Center", "Route 53", "CloudFront", "SQS"], 0, "It gives temporary role-based access.")],
 ("Guardrail SCP", r'''
{
  "Effect": "Allow",
  "Action": "*",
  "Resource": "*"
}''', 1, "An SCP with Allow * adds no restriction. Guardrails use Deny statements, for example denying unapproved Regions."),
 ("Stop people from using other Regions.", r'''
{
  "Effect": "Deny",
  "NotAction": ["iam:*", "organizations:*", "route53:*", "cloudfront:*", "support:*"],
  "Resource": "*",
  "Condition": {"StringNotEquals": {"aws:RequestedRegion": ["eu-west-1"]}}
}''', "correct", "A common Region-restriction pattern that exempts global services. Test it in a non-production OU first."),
 ("Design accounts for a small team using AI tools.", [
  ("Use one account for everything.", False, "No isolation."),
  ("Propose a multi-account layout for a 5-person team: management, prod, dev and sandbox, with SCPs denying unapproved Regions and expensive services in the sandbox, IAM Identity Center for access, and budgets per account.", True, "Isolation, guardrails, access and costs."),
  ("Set up Organizations.", False, "Too vague.")]))

cognito = T("cognito", "👤", "Cognito: user sign-in for your apps",
 "Cognito user pools handle sign-up, sign-in, MFA and tokens (JWTs) for your app's users. Identity pools can exchange identities for temporary AWS credentials.",
 "Don't roll your own authentication. AI can wire Cognito in quickly, but token handling and callback settings are easy to get wrong.",
 ["A user pool authenticates users and issues JWTs. API Gateway can validate them with a JWT authorizer.",
  "Use the hosted UI or an established library and the authorization code flow with PKCE for apps.",
  "Restrict callback and sign-out URLs to your exact domains.",
  "Keep tokens short-lived, protect refresh tokens, and enable MFA where appropriate."],
 ["AI stores tokens insecurely or logs them.", "AI sets wildcard callback URLs.", "AI skips server-side authorization checks."],
 V(uq="aws cognito user pool", yq="AWS Cognito user pool API Gateway JWT authorizer tutorial"),
 [("What does a Cognito user pool issue?", ["JWT tokens after sign-in", "S3 buckets", "Route tables", "DNS records"], 0, "Users get ID, access and refresh tokens."),
  ("Which OAuth flow is recommended for apps?", ["Authorization code with PKCE", "Implicit", "Password sharing", "None"], 0, "PKCE protects the code exchange."),
  ("Why restrict callback URLs?", ["To prevent tokens being sent to attackers' sites", "To save cost", "To speed up login", "To enable logging"], 0, "Open redirects can leak tokens.")],
 ("App client settings", r'''
CallbackURLs:
  - "https://*"''', 1, "A wildcard callback lets tokens be sent to any site. List exact URLs."),
 ("Add login to my API.", r'''
Auth:
  DefaultAuthorizer: CognitoJwt
  Authorizers:
    CognitoJwt:
      JwtConfiguration:
        issuer: !Sub https://cognito-idp.${AWS::Region}.amazonaws.com/${UserPool}
        audience: [!Ref UserPoolClient]''', "correct", "A JWT authorizer validating issuer and audience. The API still has to check which user owns each resource."),
 ("Add secure sign-in to a web app.", [
  ("Build my own login with a password table.", False, "Rolling your own auth is risky."),
  ("Write CDK for a Cognito user pool with email sign-up and MFA, a public app client using authorization code with PKCE, exact callback URLs for https://app.example.com, and an HTTP API JWT authorizer. Explain how my Lambda should check resource ownership.", True, "Standard flow, locked-down URLs and authorization."),
  ("Add login.", False, "Too vague.")]))

waf = T("waf", "🧯", "Protecting public endpoints: WAF, Shield & throttling",
 "AWS WAF filters web requests with rules. Shield protects against DDoS attacks, and API throttling and rate-based rules limit abusive callers.",
 "Public endpoints get attacked fast. A few cheap controls block most of the noise, and AI can set them up if you ask.",
 ["WAF can attach to CloudFront, ALB and API Gateway, with managed rule groups for common attacks and rate-based rules for abusers.",
  "Shield Standard protects against common network-layer DDoS at no extra cost. Shield Advanced adds extra protection and support.",
  "Use API throttling and quotas to cap cost and abuse.",
  "Log WAF requests and review the blocked and counted ones before switching rules from count to block."],
 ["AI deploys WAF in block mode without testing.", "AI skips rate limits.", "AI exposes origins directly instead of behind CloudFront."],
 V(fcc="Security: AWS WAF, AWS Shield, DDoS.", uq="aws waf shield", yq="AWS WAF rate based rule managed rules tutorial"),
 [("Which service filters web requests with rules?", ["AWS WAF", "AWS Config", "Amazon SNS", "AWS Backup"], 0, "WAF inspects HTTP requests."),
  ("What does a rate-based rule do?", ["Limits requests from a single source", "Encrypts traffic", "Creates backups", "Speeds up DNS"], 0, "It blocks sources that exceed a rate."),
  ("Why start new WAF rules in count mode?", ["To see what would be blocked before enforcing", "To save money", "It is required", "To disable logging"], 0, "It avoids blocking legitimate traffic.")],
 ("Allow everything through the web ACL", r'''
resource "aws_wafv2_web_acl" "api" {
  default_action {
    allow {}
  }
}''', 2, "The default action allows everything, and with no rules the ACL protects nothing. Add managed rule groups and a rate-based rule."),
 ("Protect my public API from abuse.", r'''
RateBasedStatement:
  Limit: 1000
  AggregateKeyType: IP''', "correct", "A rate-based rule per IP address is a good first control. Tune the limit and start in count mode."),
 ("Protect a public site from common attacks.", [
  ("Turn on WAF.", False, "No rules, no testing."),
  ("Write Terraform for a WAF web ACL on CloudFront with AWS managed common and known-bad-input rule groups in count mode first, a rate-based rule of 1000 requests per 5 minutes per IP, and logging to CloudWatch.", True, "Specific rules, testing mode and logging."),
  ("Make it hacker proof.", False, "Impossible and vague.")]))

PART3 = [cloudwatch, audit, debug, backup, cost, secbase, analyzer, orgs, cognito, waf]
