package com.smslocator.app

/** Central place for shared keys, ids and tunables so no magic strings are duplicated. */
object Constants {

    const val PREFS_NAME = "sms_locator_prefs"
    const val EVENTS_PREFS_NAME = "sms_locator_events"

    // PrefsRepository keys
    const val KEY_ENABLED = "enabled"
    const val KEY_TRIGGER_PHRASE = "trigger_phrase"
    const val KEY_CASE_SENSITIVE = "case_sensitive"
    const val KEY_TRIM_WHITESPACE = "trim_whitespace"
    const val KEY_ALLOWED_SENDERS = "allowed_senders"
    const val KEY_DESTINATION_NUMBER = "destination_number"
    const val KEY_REPLY_TO_SENDER = "reply_to_sender"
    const val KEY_SIM_SUBSCRIPTION_ID = "sim_subscription_id"
    const val KEY_LAST_SENT_TIMESTAMP = "last_sent_timestamp"

    // EventLogRepository
    const val KEY_EVENTS_JSON = "events_json"
    const val MAX_LOG_ENTRIES = 50

    // Notifications
    const val NOTIFICATION_CHANNEL_ID = "location_events"
    const val NOTIFICATION_ID_WORKING = 1001
    const val NOTIFICATION_ID_RESULT = 1002

    // Timing
    const val GPS_TIMEOUT_MS = 60_000L
    const val RATE_LIMIT_MS = 60_000L // at most one reply per minute

    // Service intent actions / extras
    const val ACTION_SMS_TRIGGER = "com.smslocator.app.action.SMS_TRIGGER"
    const val ACTION_TEST_TRIGGER = "com.smslocator.app.action.TEST_TRIGGER"
    const val EXTRA_SENDER = "extra_sender"

    const val NO_SUBSCRIPTION_ID = -1
}
