package com.smslocator.app

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsControllerCompat
import com.smslocator.app.databinding.ActivityOnboardingBinding

/**
 * First-launch-only screen. Shown exactly once: [PrefsRepository.onboardingShown] gates it, and
 * if it's already true this finishes immediately and hands off to [MainActivity] before the user
 * ever sees a frame of it - so re-opening the app later always lands straight on the bottom-nav
 * shell, never back here.
 */
class OnboardingActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = PrefsRepository(this)
        if (prefs.onboardingShown) {
            goToMainActivity()
            return
        }

        val binding = ActivityOnboardingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // White text/icons throughout this screen sit on a fixed dark gradient regardless of the
        // system's day/night setting (see bg_onboarding_gradient.xml's comment), so the status
        // bar icons need to stay light here even in light mode, unlike the rest of the app.
        WindowInsetsControllerCompat(window, binding.root).isAppearanceLightStatusBars = false

        binding.buttonGetStarted.setOnClickListener {
            prefs.onboardingShown = true
            goToMainActivity()
        }
    }

    private fun goToMainActivity() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
