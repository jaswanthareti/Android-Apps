package com.smslocator.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.DateFormat
import java.util.Date

data class EventEntry(val timestampMillis: Long, val message: String) {
    fun formatted(): String {
        val time = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.MEDIUM).format(Date(timestampMillis))
        return "$time  $message"
    }
}

/**
 * Small ring-buffer event log, newest first, capped at [Constants.MAX_LOG_ENTRIES]. Backed by a
 * single JSON array string in its own SharedPreferences file (org.json is part of the Android
 * framework, so this needs no extra JSON library). Used to satisfy the "visible event log"
 * transparency requirement: every ignored trigger, rate-limited trigger, send, and failure is
 * recorded here and shown on the Settings screen.
 */
object EventLogRepository {

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(Constants.EVENTS_PREFS_NAME, Context.MODE_PRIVATE)

    @Synchronized
    fun addEvent(context: Context, message: String) {
        val array = readArray(context)
        val entry = JSONObject()
            .put("ts", System.currentTimeMillis())
            .put("msg", message)

        // Newest first: rebuild with the new entry prepended, capped at MAX_LOG_ENTRIES.
        val rebuilt = JSONArray()
        rebuilt.put(entry)
        val limit = Constants.MAX_LOG_ENTRIES - 1
        for (i in 0 until minOf(array.length(), limit)) {
            rebuilt.put(array.get(i))
        }

        prefs(context).edit().putString(Constants.KEY_EVENTS_JSON, rebuilt.toString()).apply()
    }

    @Synchronized
    fun getEvents(context: Context): List<EventEntry> {
        val array = readArray(context)
        val result = ArrayList<EventEntry>(array.length())
        for (i in 0 until array.length()) {
            val obj = array.optJSONObject(i) ?: continue
            result.add(EventEntry(obj.optLong("ts"), obj.optString("msg")))
        }
        return result
    }

    @Synchronized
    fun clear(context: Context) {
        prefs(context).edit().remove(Constants.KEY_EVENTS_JSON).apply()
    }

    private fun readArray(context: Context): JSONArray {
        val raw = prefs(context).getString(Constants.KEY_EVENTS_JSON, null) ?: return JSONArray()
        return try {
            JSONArray(raw)
        } catch (_: Exception) {
            JSONArray()
        }
    }
}
