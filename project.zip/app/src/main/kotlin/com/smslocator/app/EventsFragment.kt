package com.smslocator.app

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.fragment.app.Fragment
import com.smslocator.app.databinding.FragmentEventsBinding

/** Events tab: the local, device-only log of every trigger, send, skip, and failure. */
class EventsFragment : Fragment() {

    private var binding: FragmentEventsBinding? = null
    private lateinit var eventAdapter: EventAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        val b = FragmentEventsBinding.inflate(inflater, container, false)
        binding = b
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val b = binding ?: return

        eventAdapter = EventAdapter(emptyList())
        b.recyclerEvents.layoutManager = LinearLayoutManager(requireContext())
        b.recyclerEvents.adapter = eventAdapter

        b.buttonRefreshLog.setOnClickListener { refreshEventLog() }
        b.buttonClearLog.setOnClickListener {
            EventLogRepository.clear(requireContext())
            refreshEventLog()
        }

        refreshEventLog()
    }

    override fun onResume() {
        super.onResume()
        refreshEventLog()
    }

    private fun refreshEventLog() {
        val b = binding ?: return
        val events = EventLogRepository.getEvents(requireContext())
        if (events.isEmpty()) {
            b.textEventLogEmpty.visibility = View.VISIBLE
            b.recyclerEvents.visibility = View.GONE
        } else {
            b.textEventLogEmpty.visibility = View.GONE
            b.recyclerEvents.visibility = View.VISIBLE
            eventAdapter.submitList(events)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        binding = null
    }
}
