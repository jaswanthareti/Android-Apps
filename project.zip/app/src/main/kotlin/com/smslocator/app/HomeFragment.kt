package com.smslocator.app

import android.os.Bundle
import android.text.format.DateFormat
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.smslocator.app.databinding.FragmentHomeBinding
import java.util.Date

/**
 * Home tab: the Protection on/off switch plus status readout. Flipping the switch here writes
 * straight to [PrefsRepository.enabled] - there is no separate Save button for it, since the
 * switch is the kind of control people expect to take effect immediately. Everything else
 * (trigger phrase, allowed senders, destination, SIM) lives in the Settings tab and still needs
 * its own Save button there.
 */
class HomeFragment : Fragment() {

    private var binding: FragmentHomeBinding? = null
    private val mainActivity get() = requireActivity() as MainActivity
    private val prefs get() = mainActivity.prefs

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        val b = FragmentHomeBinding.inflate(inflater, container, false)
        binding = b
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val b = binding ?: return

        // Set the initial state before attaching the listener below, so loading the saved value
        // doesn't itself fire the "user changed it" handling.
        b.switchEnabled.isChecked = prefs.enabled

        b.switchEnabled.setOnCheckedChangeListener { switchView, isChecked ->
            if (isChecked && !prefs.isConfiguredForSending()) {
                mainActivity.showSnackbar(R.string.toast_configure_before_enabling)
                switchView.isChecked = false
                return@setOnCheckedChangeListener
            }
            prefs.enabled = isChecked
            mainActivity.updateToolbarSubtitle()
            refreshStatusCard()
        }

        b.buttonGoToSettings.setOnClickListener {
            mainActivity.switchToTab(R.id.navSettings)
        }

        refreshStatusCard()
    }

    override fun onResume() {
        super.onResume()
        binding?.switchEnabled?.isChecked = prefs.enabled
        refreshStatusCard()
    }

    private fun refreshStatusCard() {
        val b = binding ?: return
        val active = prefs.enabled && prefs.isConfiguredForSending()
        b.textStatusSummary.text = getString(
            if (prefs.enabled) R.string.status_active else R.string.status_inactive
        )
        b.textStatusSummary.setCompoundDrawablesRelativeWithIntrinsicBounds(
            if (active) R.drawable.ic_shield_check else R.drawable.ic_status_warning, 0, 0, 0
        )

        val lastSent = prefs.lastSentTimestamp
        b.textLastSent.text = if (lastSent <= 0L) {
            getString(R.string.status_last_sent_never)
        } else {
            val formatted = DateFormat.getLongDateFormat(requireContext()).format(Date(lastSent)).toString() +
                ", " + DateFormat.getTimeFormat(requireContext()).format(Date(lastSent))
            getString(R.string.status_last_sent_format, formatted)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        binding = null
    }
}
