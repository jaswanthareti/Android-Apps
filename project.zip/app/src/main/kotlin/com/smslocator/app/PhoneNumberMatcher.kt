package com.smslocator.app

/**
 * Compares SMS sender addresses against the configured allow-list. Carriers and devices report
 * the same number in different shapes (+919876543210, 919876543210, 09876543210, with spaces or
 * dashes), so an exact string match is too brittle. Instead this strips everything but digits
 * and compares the end of the two digit strings, which is robust to a missing/extra country
 * code or leading trunk zero while still requiring a long, specific match (never just the last
 * couple of digits).
 */
object PhoneNumberMatcher {

    /** Shortest suffix length that counts as a meaningful match; avoids trivial collisions. */
    private const val MIN_MATCH_DIGITS = 7

    private fun digitsOnly(number: String): String = number.filter { it.isDigit() }

    fun matches(incomingAddress: String, allowList: List<String>): Boolean {
        val incomingDigits = digitsOnly(incomingAddress)
        if (incomingDigits.length < MIN_MATCH_DIGITS) return false
        return allowList.any { allowed ->
            val allowedDigits = digitsOnly(allowed)
            if (allowedDigits.length < MIN_MATCH_DIGITS) return@any false
            incomingDigits == allowedDigits ||
                incomingDigits.endsWith(allowedDigits) ||
                allowedDigits.endsWith(incomingDigits)
        }
    }
}
