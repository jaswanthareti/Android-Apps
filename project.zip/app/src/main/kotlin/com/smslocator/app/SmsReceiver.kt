package com.smslocator.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import androidx.core.content.ContextCompat

/**
 * Manifest-registered receiver for the protected android.provider.Telephony.SMS_RECEIVED_ACTION
 * broadcast. Only the telephony stack can ever send that broadcast (it's a protected system
 * broadcast), so the sender-number allow-list below is the real security boundary, not this
 * receiver's existence.
 *
 * Everything here runs synchronously inside onReceive() and is kept fast and allocation-light:
 * while onReceive() is executing the app counts as actively handling a broadcast rather than
 * sitting in the background, which is what lets startForegroundService() be called a few lines
 * down without hitting Android 12+'s background-start restriction. If this work were deferred
 * to a coroutine or another thread that outlives onReceive(), that window would close and the
 * foreground-service start could be refused.
 */
class SmsReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        val prefs = PrefsRepository(context)
        if (!prefs.enabled) return

        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        if (messages.isNullOrEmpty()) return

        val sender = messages[0].originatingAddress ?: return
        // A long SMS arrives as several PDUs; stitch the body back together before matching.
        val fullBody = messages.joinToString(separator = "") { it.messageBody ?: "" }

        val configuredPhrase = prefs.triggerPhrase
        if (configuredPhrase.isBlank()) return

        val candidateBody = if (prefs.trimWhitespace) fullBody.trim() else fullBody
        val candidatePhrase = if (prefs.trimWhitespace) configuredPhrase.trim() else configuredPhrase

        val phraseMatches = if (prefs.caseSensitive) {
            candidateBody == candidatePhrase
        } else {
            candidateBody.equals(candidatePhrase, ignoreCase = true)
        }
        if (!phraseMatches) return

        if (!PhoneNumberMatcher.matches(sender, prefs.allowedSendersList)) {
            EventLogRepository.addEvent(context, "Ignored: trigger phrase from non-allowed number $sender")
            return
        }

        if (prefs.isRateLimited()) {
            EventLogRepository.addEvent(context, "Rate-limited: trigger from $sender ignored")
            return
        }

        EventLogRepository.addEvent(context, "Trigger matched from $sender, starting location fetch")

        val serviceIntent = Intent(context, LocationForegroundService::class.java).apply {
            action = Constants.ACTION_SMS_TRIGGER
            putExtra(Constants.EXTRA_SENDER, sender)
        }
        ContextCompat.startForegroundService(context, serviceIntent)
    }
}
