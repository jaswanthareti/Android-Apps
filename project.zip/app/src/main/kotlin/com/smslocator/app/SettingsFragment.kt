package com.smslocator.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SubscriptionManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.smslocator.app.databinding.FragmentSettingsBinding

/**
 * Settings tab: trigger phrase, allowed senders, destination number, and outgoing SIM - the
 * fields the old single screen's Save button wrote to PrefsRepository (everything except the
 * Protection on/off switch itself, which now lives on the Home tab and saves immediately).
 */
class SettingsFragment : Fragment() {

    private var binding: FragmentSettingsBinding? = null
    private val mainActivity get() = requireActivity() as MainActivity
    private val prefs get() = mainActivity.prefs

    private var simSubscriptionIds: List<Int> = listOf(Constants.NO_SUBSCRIPTION_ID)
    private var simLabels: List<String> = listOf("Default SIM")

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        val b = FragmentSettingsBinding.inflate(inflater, container, false)
        binding = b
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val b = binding ?: return

        loadFromPrefs()
        populateSimDropdown()

        b.buttonSave.setOnClickListener { saveToPrefs() }
        b.buttonTestNow.setOnClickListener { runTestNow() }
    }

    override fun onResume() {
        super.onResume()
        // The SIM list (and READ_PHONE_STATE's effect on it) can change while this tab wasn't
        // visible, e.g. right after granting permissions on the Permissions tab.
        populateSimDropdown()
    }

    private fun loadFromPrefs() {
        val b = binding ?: return
        b.editTriggerPhrase.setText(prefs.triggerPhrase)
        b.checkCaseSensitive.isChecked = prefs.caseSensitive
        b.checkTrimWhitespace.isChecked = prefs.trimWhitespace
        b.editAllowedSenders.setText(prefs.allowedSendersRaw)
        b.editDestinationNumber.setText(prefs.destinationNumber)
        b.checkReplyToSender.isChecked = prefs.replyToSender
    }

    private fun saveToPrefs() {
        val b = binding ?: return
        val triggerPhrase = b.editTriggerPhrase.text.toString()
        val allowedSendersRaw = b.editAllowedSenders.text.toString()
        val destinationNumber = b.editDestinationNumber.text.toString()
        val replyToSender = b.checkReplyToSender.isChecked

        prefs.triggerPhrase = triggerPhrase
        prefs.caseSensitive = b.checkCaseSensitive.isChecked
        prefs.trimWhitespace = b.checkTrimWhitespace.isChecked
        prefs.allowedSendersRaw = allowedSendersRaw
        prefs.destinationNumber = destinationNumber
        prefs.replyToSender = replyToSender
        prefs.simSubscriptionId = currentlySelectedSubscriptionId()

        // Protection's on/off switch lives on the Home tab now and saves itself immediately, but
        // if it was already on and this save just made the config incomplete (e.g. the allowed
        // senders list got cleared), silently leaving it "on" would be worse than the old
        // single-screen app ever allowed - so turn it off and say why, same safety net as before.
        if (prefs.enabled && !prefs.isConfiguredForSending()) {
            prefs.enabled = false
            mainActivity.updateToolbarSubtitle()
            mainActivity.showSnackbar(R.string.toast_protection_disabled_incomplete)
        } else {
            mainActivity.showSnackbar(R.string.toast_saved)
        }
    }

    private fun runTestNow() {
        // Persist current field values first so the test run uses exactly what's on screen,
        // even if the user hasn't pressed Save yet.
        saveToPrefs()

        if (prefs.destinationNumber.isBlank()) {
            mainActivity.showSnackbar(R.string.toast_test_needs_destination)
            return
        }
        if (!mainActivity.hasAllCorePermissionsGranted()) {
            mainActivity.showSnackbar(R.string.toast_test_needs_permissions)
            return
        }

        val serviceIntent = Intent(requireContext(), LocationForegroundService::class.java).apply {
            action = Constants.ACTION_TEST_TRIGGER
        }
        ContextCompat.startForegroundService(requireContext(), serviceIntent)
        mainActivity.showSnackbar(R.string.toast_test_triggered)
    }

    private fun populateSimDropdown() {
        val b = binding ?: return
        val labels = mutableListOf("Default SIM")
        val ids = mutableListOf(Constants.NO_SUBSCRIPTION_ID)

        val hasPhoneStatePermission = ContextCompat.checkSelfPermission(
            requireContext(), Manifest.permission.READ_PHONE_STATE
        ) == PackageManager.PERMISSION_GRANTED

        if (hasPhoneStatePermission) {
            try {
                val subscriptionManager = requireContext().getSystemService(SubscriptionManager::class.java)
                val activeSubs = subscriptionManager?.activeSubscriptionInfoList
                activeSubs?.forEach { info ->
                    val displayName = info.displayName?.toString() ?: "SIM ${info.simSlotIndex + 1}"
                    labels.add("$displayName (slot ${info.simSlotIndex + 1})")
                    ids.add(info.subscriptionId)
                }
            } catch (_: SecurityException) {
                // Permission was granted a moment ago but revoked again, or OEM quirk; dropdown
                // just falls back to "Default SIM only", which is still a safe, working choice.
            }
        }

        simSubscriptionIds = ids
        simLabels = labels

        b.dropdownSim.setAdapter(
            ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, labels)
        )

        val savedIndex = ids.indexOf(prefs.simSubscriptionId).let { if (it < 0) 0 else it }
        b.dropdownSim.setText(labels[savedIndex], false)
    }

    private fun currentlySelectedSubscriptionId(): Int {
        val b = binding ?: return Constants.NO_SUBSCRIPTION_ID
        val currentText = b.dropdownSim.text.toString()
        val index = simLabels.indexOf(currentText)
        return simSubscriptionIds.getOrElse(if (index < 0) 0 else index) { Constants.NO_SUBSCRIPTION_ID }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        binding = null
    }
}
