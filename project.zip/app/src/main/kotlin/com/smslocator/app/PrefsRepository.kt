package com.smslocator.app

import android.content.Context
import android.content.SharedPreferences

/**
 * Thin wrapper around a private SharedPreferences file holding every user-configurable setting.
 * Everything defaults to "off"/empty so a freshly installed app is inert until the owner fills
 * in the Settings screen and flips Enable on.
 */
class PrefsRepository(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)

    var enabled: Boolean
        get() = prefs.getBoolean(Constants.KEY_ENABLED, false)
        set(value) = prefs.edit().putBoolean(Constants.KEY_ENABLED, value).apply()

    var triggerPhrase: String
        get() = prefs.getString(Constants.KEY_TRIGGER_PHRASE, "") ?: ""
        set(value) = prefs.edit().putString(Constants.KEY_TRIGGER_PHRASE, value).apply()

    var caseSensitive: Boolean
        get() = prefs.getBoolean(Constants.KEY_CASE_SENSITIVE, false)
        set(value) = prefs.edit().putBoolean(Constants.KEY_CASE_SENSITIVE, value).apply()

    var trimWhitespace: Boolean
        get() = prefs.getBoolean(Constants.KEY_TRIM_WHITESPACE, true)
        set(value) = prefs.edit().putBoolean(Constants.KEY_TRIM_WHITESPACE, value).apply()

    /** Raw newline-separated storage; use [allowedSendersList] for the parsed, trimmed form. */
    var allowedSendersRaw: String
        get() = prefs.getString(Constants.KEY_ALLOWED_SENDERS, "") ?: ""
        set(value) = prefs.edit().putString(Constants.KEY_ALLOWED_SENDERS, value).apply()

    val allowedSendersList: List<String>
        get() = allowedSendersRaw
            .lines()
            .map { it.trim() }
            .filter { it.isNotEmpty() }

    var destinationNumber: String
        get() = prefs.getString(Constants.KEY_DESTINATION_NUMBER, "") ?: ""
        set(value) = prefs.edit().putString(Constants.KEY_DESTINATION_NUMBER, value).apply()

    var replyToSender: Boolean
        get() = prefs.getBoolean(Constants.KEY_REPLY_TO_SENDER, false)
        set(value) = prefs.edit().putBoolean(Constants.KEY_REPLY_TO_SENDER, value).apply()

    /** Android subscriptionId of the SIM to send from, or [Constants.NO_SUBSCRIPTION_ID] for "default". */
    var simSubscriptionId: Int
        get() = prefs.getInt(Constants.KEY_SIM_SUBSCRIPTION_ID, Constants.NO_SUBSCRIPTION_ID)
        set(value) = prefs.edit().putInt(Constants.KEY_SIM_SUBSCRIPTION_ID, value).apply()

    var lastSentTimestamp: Long
        get() = prefs.getLong(Constants.KEY_LAST_SENT_TIMESTAMP, 0L)
        set(value) = prefs.edit().putLong(Constants.KEY_LAST_SENT_TIMESTAMP, value).apply()

    /** True once the person has tapped "Get started" on the onboarding screen at least once. */
    var onboardingShown: Boolean
        get() = prefs.getBoolean(Constants.KEY_ONBOARDING_SHOWN, false)
        set(value) = prefs.edit().putBoolean(Constants.KEY_ONBOARDING_SHOWN, value).apply()

    fun isRateLimited(now: Long = System.currentTimeMillis()): Boolean =
        (now - lastSentTimestamp) < Constants.RATE_LIMIT_MS

    /** True once there's enough configured for a trigger to plausibly work end to end. */
    fun isConfiguredForSending(): Boolean {
        if (triggerPhrase.isBlank()) return false
        if (allowedSendersList.isEmpty()) return false
        if (!replyToSender && destinationNumber.isBlank()) return false
        return true
    }
}
