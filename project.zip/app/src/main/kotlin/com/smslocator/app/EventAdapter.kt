package com.smslocator.app

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.smslocator.app.databinding.ItemEventBinding

/**
 * Binds [EventEntry] rows into the event-log RecyclerView. Each row gets a status icon worked
 * out by sniffing a few keywords in the stored message text (the log only ever stores short,
 * plain-English sentences written by this app itself, e.g. "Sent location to ...", "Rate
 * limited, ignored trigger from ...", "Send failed: ..." - there's no separate stored "level"
 * field, so classifying the text is simplest and keeps EventLogRepository's format unchanged).
 */
class EventAdapter(private var entries: List<EventEntry>) :
    RecyclerView.Adapter<EventAdapter.EventViewHolder>() {

    class EventViewHolder(val binding: ItemEventBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EventViewHolder {
        val binding = ItemEventBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return EventViewHolder(binding)
    }

    override fun onBindViewHolder(holder: EventViewHolder, position: Int) {
        val entry = entries[position]
        holder.binding.textEventMessage.text = entry.message
        holder.binding.textEventTime.text = entry.formatted().substringBefore("  ").let {
            // formatted() is "$time  $message"; show just the time here since the message is
            // already shown in full above, on its own line.
            it
        }
        holder.binding.imageEventIcon.setImageResource(iconFor(entry.message))
    }

    override fun getItemCount(): Int = entries.size

    fun submitList(newEntries: List<EventEntry>) {
        entries = newEntries
        notifyDataSetChanged()
    }

    private fun iconFor(message: String): Int {
        val lower = message.lowercase()
        return when {
            "failed" in lower || "error" in lower || "denied" in lower -> R.drawable.ic_status_error
            "rate limited" in lower || "ignored" in lower || "no destination" in lower ||
                "missing" in lower || "skipped" in lower -> R.drawable.ic_status_warning
            "sent" in lower || "triggered" in lower || "test" in lower -> R.drawable.ic_status_success
            else -> R.drawable.ic_status_info
        }
    }
}
