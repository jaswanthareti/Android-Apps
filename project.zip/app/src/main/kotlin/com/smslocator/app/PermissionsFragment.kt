package com.smslocator.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.smslocator.app.databinding.FragmentPermissionsBinding
import com.smslocator.app.databinding.ItemPermissionRowBinding

/** Permissions tab: one row per required permission, plus the two "fix it" buttons. */
class PermissionsFragment : Fragment() {

    private var binding: FragmentPermissionsBinding? = null
    private val mainActivity get() = requireActivity() as MainActivity

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        val b = FragmentPermissionsBinding.inflate(inflater, container, false)
        binding = b
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val b = binding ?: return

        b.buttonGrantPermissions.setOnClickListener {
            mainActivity.launchCorePermissionsRequest()
        }
        b.buttonBackgroundLocation.setOnClickListener {
            mainActivity.requestBackgroundLocationAccess()
        }
        b.buttonOpenAppSettings.setOnClickListener {
            mainActivity.openAppSettings()
        }

        refreshPermissionStatus()
    }

    override fun onResume() {
        super.onResume()
        // Permission state (and background location, which often routes through system Settings)
        // can change while this tab isn't visible, so re-check every time it's shown.
        refreshPermissionStatus()
    }

    /** One row per required permission, each with a status icon + label + granted/missing text. */
    private fun refreshPermissionStatus() {
        val b = binding ?: return
        val entries = buildList {
            add("SMS receive & send" to Manifest.permission.RECEIVE_SMS)
            add("Phone state (for dual-SIM)" to Manifest.permission.READ_PHONE_STATE)
            add("Precise location" to Manifest.permission.ACCESS_FINE_LOCATION)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                add("Notifications" to Manifest.permission.POST_NOTIFICATIONS)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                add("Background location" to Manifest.permission.ACCESS_BACKGROUND_LOCATION)
            }
        }

        b.layoutPermissionRows.removeAllViews()
        for ((label, permission) in entries) {
            val granted = ContextCompat.checkSelfPermission(requireContext(), permission) ==
                PackageManager.PERMISSION_GRANTED
            b.layoutPermissionRows.addView(buildPermissionRow(label, granted))
        }
    }

    /**
     * Inflated from item_permission_row.xml rather than built with `View(context)`/`TextView(context)`
     * calls, so every text-appearance/color reference goes through normal XML resource
     * resolution (which sees Material's styles and theme attrs) instead of this app module's own
     * generated R class, which under AGP's non-transitive R classes does not contain them.
     */
    private fun buildPermissionRow(label: String, granted: Boolean): View {
        val b = binding ?: error("buildPermissionRow called with no view")
        val row = layoutInflater.inflate(R.layout.item_permission_row, b.layoutPermissionRows, false)
        val rowBinding = ItemPermissionRowBinding.bind(row)

        rowBinding.imagePermissionIcon.setImageResource(
            if (granted) R.drawable.ic_status_success else R.drawable.ic_status_warning
        )
        rowBinding.textPermissionLabel.text = label
        rowBinding.textPermissionStatus.text =
            getString(if (granted) R.string.permission_granted else R.string.permission_missing)
        rowBinding.textPermissionStatus.setTextAppearance(
            if (granted) R.style.TextAppearance_SmsLocator_PermissionGranted
            else R.style.TextAppearance_SmsLocator_PermissionMissing
        )

        return row
    }

    override fun onDestroyView() {
        super.onDestroyView()
        binding = null
    }
}
