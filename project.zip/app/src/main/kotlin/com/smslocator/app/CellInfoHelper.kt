package com.smslocator.app

import android.os.Build
import android.telephony.CellInfo
import android.telephony.CellInfoGsm
import android.telephony.CellInfoLte
import android.telephony.CellInfoNr
import android.telephony.CellInfoWcdma
import android.telephony.TelephonyManager

data class CellSnapshot(
    val radioType: String,
    val isServing: Boolean,
    val mcc: String?,
    val mnc: String?,
    val tac: String?,
    val cellId: String?,
    val dbm: Int?
) {
    /** Compact single-line form kept deliberately short so several fit in an SMS. */
    fun toCompactString(): String {
        val label = if (isServing) "serv" else "nbr"
        val sb = StringBuilder()
        sb.append(radioType).append(' ').append(label)
        if (mcc != null && mnc != null) sb.append(" MCC").append(mcc).append(" MNC").append(mnc)
        if (tac != null) sb.append(" TAC").append(tac)
        if (cellId != null) sb.append(" CID").append(cellId)
        if (dbm != null) sb.append(' ').append(dbm).append("dBm")
        return sb.toString()
    }
}

/**
 * Reads serving + neighbouring cell identifiers straight from TelephonyManager. Requires
 * READ_PHONE_STATE and (since API 29) ACCESS_FINE_LOCATION, both already requested by this app.
 * Wrapped defensively: OEM telephony stacks are inconsistent about what they return, and a
 * failure here must never stop the GPS fix or the SMS send from going out.
 */
object CellInfoHelper {

    private const val UNAVAILABLE_INT = Int.MAX_VALUE
    private const val UNAVAILABLE_LONG = Long.MAX_VALUE

    /** Serving cell first, then up to [maxNeighbors] neighbours, to keep the SMS short. */
    fun getCellSnapshots(telephonyManager: TelephonyManager, maxNeighbors: Int = 2): List<CellSnapshot> {
        return try {
            val allCellInfo: List<CellInfo> = telephonyManager.allCellInfo ?: emptyList()
            val serving = allCellInfo.filter { it.isRegistered }.mapNotNull { toSnapshot(it) }
            val neighbors = allCellInfo.filterNot { it.isRegistered }
                .mapNotNull { toSnapshot(it) }
                .take(maxNeighbors)
            serving + neighbors
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun toSnapshot(cellInfo: CellInfo): CellSnapshot? {
        return try {
            when {
                cellInfo is CellInfoLte -> {
                    val id = cellInfo.cellIdentity
                    val strength = cellInfo.cellSignalStrength
                    val mccStr = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) id.mccString else null
                    val mncStr = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) id.mncString else null
                    CellSnapshot(
                        radioType = "LTE",
                        isServing = cellInfo.isRegistered,
                        mcc = mccStringOf(mccStr, id.mcc),
                        mnc = mccStringOf(mncStr, id.mnc),
                        tac = intOrNull(id.tac)?.toString(),
                        cellId = intOrNull(id.ci)?.toString(),
                        dbm = intOrNull(strength.dbm)
                    )
                }
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && cellInfo is CellInfoNr -> {
                    val id = cellInfo.cellIdentity as? android.telephony.CellIdentityNr ?: return null
                    val strength = cellInfo.cellSignalStrength as? android.telephony.CellSignalStrengthNr
                    CellSnapshot(
                        radioType = "NR",
                        isServing = cellInfo.isRegistered,
                        mcc = id.mccString,
                        mnc = id.mncString,
                        tac = intOrNull(id.tac)?.toString(),
                        cellId = longOrNull(id.nci)?.toString(),
                        dbm = strength?.let { intOrNull(it.dbm) }
                    )
                }
                cellInfo is CellInfoWcdma -> {
                    val id = cellInfo.cellIdentity
                    val strength = cellInfo.cellSignalStrength
                    val mccStr = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) id.mccString else null
                    val mncStr = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) id.mncString else null
                    CellSnapshot(
                        radioType = "WCDMA",
                        isServing = cellInfo.isRegistered,
                        mcc = mccStringOf(mccStr, id.mcc),
                        mnc = mccStringOf(mncStr, id.mnc),
                        tac = intOrNull(id.lac)?.toString(),
                        cellId = intOrNull(id.cid)?.toString(),
                        dbm = intOrNull(strength.dbm)
                    )
                }
                cellInfo is CellInfoGsm -> {
                    val id = cellInfo.cellIdentity
                    val strength = cellInfo.cellSignalStrength
                    val mccStr = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) id.mccString else null
                    val mncStr = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) id.mncString else null
                    CellSnapshot(
                        radioType = "GSM",
                        isServing = cellInfo.isRegistered,
                        mcc = mccStringOf(mccStr, id.mcc),
                        mnc = mccStringOf(mncStr, id.mnc),
                        tac = intOrNull(id.lac)?.toString(),
                        cellId = intOrNull(id.cid)?.toString(),
                        dbm = intOrNull(strength.dbm)
                    )
                }
                else -> null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun mccStringOf(stringValue: String?, intValue: Int): String? {
        if (!stringValue.isNullOrEmpty()) return stringValue
        val fallback = intOrNull(intValue) ?: return null
        return fallback.toString()
    }

    private fun intOrNull(value: Int): Int? =
        if (value == UNAVAILABLE_INT || value < 0) null else value

    private fun longOrNull(value: Long): Long? =
        if (value == UNAVAILABLE_LONG || value < 0) null else value
}
