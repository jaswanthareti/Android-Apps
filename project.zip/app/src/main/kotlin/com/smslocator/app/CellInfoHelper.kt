package com.smslocator.app

import android.os.Build
import android.telephony.CellInfo
import android.telephony.CellInfoGsm
import android.telephony.CellInfoLte
import android.telephony.CellInfoNr
import android.telephony.CellInfoWcdma
import android.telephony.TelephonyManager

data class CellSnapshot(
    val radioType: String,
    val isServing: Boolean,
    val mcc: String?,
    val mnc: String?,
    val tac: String?,
    val cellId: String?,
    val dbm: Int?
) {
    /** Compact single-line form kept deliberately short so several fit in an SMS. */
    fun toCompactString(): String {
        val label = if (isServing) "serv" else "nbr"
        val sb = StringBuilder()
        sb.append(radioType).append(' ').append(label)
        if (mcc != null && mnc != null) sb.append(" MCC").append(mcc).append(" MNC").append(mnc)
        if (tac != null) sb.append(" TAC").append(tac)
        if (cellId != null) sb.append(" CID").append(cellId)
        if (dbm != null) sb.append(' ').append(dbm).append("dBm")
        return sb.toString()
    }
}

/**
 * Reads serving + neighbouring cell identifiers straight from TelephonyManager. Requires
 * READ_PHONE_STATE and (since API 29) ACCESS_FINE_LOCATION, both already requested by this app.
 * Wrapped defensively: OEM telephony stacks are inconsistent about what they return, and a
 * failure here must never stop the GPS fix or the SMS send from going out.
 */
object CellInfoHelper {

    private const val UNAVAILABLE_INT = Int.MAX_VALUE
    private const val UNAVAILABLE_LONG = Long.MAX_VALUE

    /** Serving cell first, then up to [maxNeighbors] neighbours, to keep the SMS short. */
    fun getCellSnapshots(telephonyManager: TelephonyManager, maxNeighbors: Int = 2): List<CellSnapshot> {
        return try {
            val allCellInfo: List<CellInfo> = telephonyManager.allCellInfo ?: emptyList()
            val serving = allCellInfo.filter { it.isRegistered }.mapNotNull { toSnapshot(it) }
            val neighbors = allCellInfo.filterNot { it.isRegistered }
                .mapNotNull { toSnapshot(it) }
                // Many radios report a neighbour with signal strength but no real identity -
                // tac/lac AND cell id both reported as 0, which isn't a real tower location,
                // just the radio's way of saying "don't know." A line with no cell id carries no
                // information worth the SMS characters, so drop it rather than send "TAC0 CID0".
                .filter { it.cellId != null }
                .take(maxNeighbors)
            serving + neighbors
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun toSnapshot(cellInfo: CellInfo): CellSnapshot? {
        return try {
            when {
                cellInfo is CellInfoLte -> {
                    val id = cellInfo.cellIdentity
                    val strength = cellInfo.cellSignalStrength
                    val mccStr = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) id.mccString else null
                    val mncStr = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) id.mncString else null
                    CellSnapshot(
                        radioType = "LTE",
                        isServing = cellInfo.isRegistered,
                        mcc = mccStringOf(mccStr, id.mcc),
                        mnc = mccStringOf(mncStr, id.mnc),
                        tac = cellIdentifierOrNull(id.tac)?.toString(),
                        cellId = cellIdentifierOrNull(id.ci)?.toString(),
                        dbm = intOrNull(strength.dbm)
                    )
                }
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && cellInfo is CellInfoNr -> {
                    val id = cellInfo.cellIdentity as? android.telephony.CellIdentityNr ?: return null
                    val strength = cellInfo.cellSignalStrength as? android.telephony.CellSignalStrengthNr
                    CellSnapshot(
                        radioType = "NR",
                        isServing = cellInfo.isRegistered,
                        mcc = id.mccString,
                        mnc = id.mncString,
                        tac = cellIdentifierOrNull(id.tac)?.toString(),
                        cellId = cellIdentifierLongOrNull(id.nci)?.toString(),
                        dbm = strength?.let { intOrNull(it.dbm) }
                    )
                }
                cellInfo is CellInfoWcdma -> {
                    val id = cellInfo.cellIdentity
                    val strength = cellInfo.cellSignalStrength
                    val mccStr = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) id.mccString else null
                    val mncStr = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) id.mncString else null
                    CellSnapshot(
                        radioType = "WCDMA",
                        isServing = cellInfo.isRegistered,
                        mcc = mccStringOf(mccStr, id.mcc),
                        mnc = mccStringOf(mncStr, id.mnc),
                        tac = cellIdentifierOrNull(id.lac)?.toString(),
                        cellId = cellIdentifierOrNull(id.cid)?.toString(),
                        dbm = intOrNull(strength.dbm)
                    )
                }
                cellInfo is CellInfoGsm -> {
                    val id = cellInfo.cellIdentity
                    val strength = cellInfo.cellSignalStrength
                    val mccStr = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) id.mccString else null
                    val mncStr = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) id.mncString else null
                    CellSnapshot(
                        radioType = "GSM",
                        isServing = cellInfo.isRegistered,
                        mcc = mccStringOf(mccStr, id.mcc),
                        mnc = mccStringOf(mncStr, id.mnc),
                        tac = cellIdentifierOrNull(id.lac)?.toString(),
                        cellId = cellIdentifierOrNull(id.cid)?.toString(),
                        dbm = intOrNull(strength.dbm)
                    )
                }
                else -> null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun mccStringOf(stringValue: String?, intValue: Int): String? {
        if (!stringValue.isNullOrEmpty()) return stringValue
        val fallback = intOrNull(intValue) ?: return null
        return fallback.toString()
    }

    /** For mcc/mnc/signal-strength fields, where 0 is a theoretically real value. */
    private fun intOrNull(value: Int): Int? =
        if (value == UNAVAILABLE_INT || value < 0) null else value

    /**
     * For tac/lac/cid/ci fields specifically: besides the documented UNAVAILABLE sentinel, many
     * radios report an all-zero identity (tac=0, cid=0) for a neighbour cell they only have a
     * signal reading for, not a real identity. A real-world tower is never actually at
     * identifier 0, so treating 0 the same as "unavailable" here turns that into a clean null
     * instead of a misleading "TAC0 CID0" in the outgoing SMS.
     */
    private fun cellIdentifierOrNull(value: Int): Int? =
        if (value == UNAVAILABLE_INT || value <= 0) null else value

    private fun cellIdentifierLongOrNull(value: Long): Long? =
        if (value == UNAVAILABLE_LONG || value <= 0) null else value
}
