package com.smslocator.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.telephony.TelephonyManager
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Foreground service (type "location") that does the actual work: wait briefly for a GPS fix
 * (falling back to last-known location), read cell identifiers, compose the SMS, send it, log
 * the outcome and post the mandatory result notification.
 *
 * One instance handles one trigger at a time. A second trigger that arrives while the first is
 * still waiting on GPS is logged and dropped rather than queued or run concurrently - with a
 * one-reply-per-minute rate limit already in front of this, overlap is an edge case, not the
 * normal path. The in-flight request's own startId is threaded through every helper so a
 * dropped, overlapping request can never call stopSelf() on behalf of the one still running.
 */
class LocationForegroundService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private var timeoutRunnable: Runnable? = null
    private var locationListener: LocationListener? = null

    companion object {
        private val isProcessing = AtomicBoolean(false)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!isProcessing.compareAndSet(false, true)) {
            // A request is already running under its own startId; just drop this one. Do NOT
            // call stopSelf(startId) here - stopSelf(startId) stops the service outright if
            // startId is the most recent one received, which would tear down the still-running
            // request underneath it.
            EventLogRepository.addEvent(this, "Ignored: a location request is already in progress")
            return START_NOT_STICKY
        }

        ServiceCompat.startForeground(
            this,
            Constants.NOTIFICATION_ID_WORKING,
            NotificationHelper.buildWorkingNotification(this),
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
            } else {
                0
            }
        )

        try {
            handleTrigger(startId, intent)
        } catch (e: Exception) {
            // Belt and braces: an unexpected exception anywhere in the pipeline must not leave
            // isProcessing stuck true for the rest of this process's life.
            EventLogRepository.addEvent(this, "Failed: unexpected error (${e.javaClass.simpleName})")
            finishAndStop(startId)
        }
        return START_NOT_STICKY
    }

    private fun handleTrigger(startId: Int, intent: Intent?) {
        val isTest = intent?.action == Constants.ACTION_TEST_TRIGGER
        val triggerSender = intent?.getStringExtra(Constants.EXTRA_SENDER)
        val prefs = PrefsRepository(this)

        if (!isTest && prefs.isRateLimited()) {
            // Re-checked here, race-safe against SharedPreferences, in case two triggers slipped
            // past the receiver's own check in close succession.
            EventLogRepository.addEvent(this, "Rate-limited at service start, dropping trigger")
            finishAndStop(startId)
            return
        }

        val destination = if (isTest) {
            prefs.destinationNumber
        } else if (prefs.replyToSender && triggerSender != null) {
            triggerSender
        } else {
            prefs.destinationNumber
        }

        if (destination.isBlank()) {
            EventLogRepository.addEvent(this, "Failed: no destination number configured")
            NotificationHelper.showResultNotification(
                this,
                getString(R.string.notification_failed_title),
                getString(R.string.notification_failed_no_destination)
            )
            broadcastResult(isTest, success = false, destination = destination, failureReason = "no_destination")
            finishAndStop(startId)
            return
        }

        if (!hasRequiredPermissions()) {
            EventLogRepository.addEvent(this, "Failed: a required permission is missing")
            NotificationHelper.showResultNotification(
                this,
                getString(R.string.notification_failed_title),
                getString(R.string.notification_failed_permissions)
            )
            broadcastResult(isTest, success = false, destination = destination, failureReason = "missing_permission")
            finishAndStop(startId)
            return
        }

        beginLocationFetch(startId, isTest, destination, prefs.simSubscriptionId)
    }

    /** Called when the system itself is ending this FGS run (API 35+); must stop promptly. */
    override fun onTimeout(startId: Int, fgsType: Int) {
        EventLogRepository.addEvent(this, "System ended the foreground service before completion")
        cleanupLocationRequest()
        isProcessing.set(false)
        stopSelf(startId)
    }

    private fun hasRequiredPermissions(): Boolean {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED
        val sendSms = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) ==
            PackageManager.PERMISSION_GRANTED
        val phoneState = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) ==
            PackageManager.PERMISSION_GRANTED
        return fine && sendSms && phoneState
    }

    @SuppressLint("MissingPermission") // hasRequiredPermissions() already verified ACCESS_FINE_LOCATION
    private fun beginLocationFetch(startId: Int, isTest: Boolean, destination: String, subscriptionId: Int) {
        val locationManager = getSystemService(LocationManager::class.java)
        if (locationManager == null) {
            finishWithResult(startId, isTest, destination, subscriptionId, location = null, ageLabel = null)
            return
        }

        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            .filter {
                try { locationManager.isProviderEnabled(it) } catch (_: Exception) { false }
            }

        if (providers.isEmpty()) {
            // No enabled provider at all: go straight to last-known, no point waiting.
            useLastKnownAndFinish(startId, isTest, locationManager, destination, subscriptionId)
            return
        }

        var resolved = false
        val listener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                if (resolved) return
                resolved = true
                cleanupLocationRequest()
                finishWithResult(startId, isTest, destination, subscriptionId, location, ageLabel = null)
            }

            @Deprecated("Deprecated in Java")
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) { }
            override fun onProviderEnabled(provider: String) { }
            override fun onProviderDisabled(provider: String) { }
        }
        locationListener = listener

        try {
            for (provider in providers) {
                locationManager.requestLocationUpdates(provider, 0L, 0f, listener, Looper.getMainLooper())
            }
        } catch (_: SecurityException) {
            finishWithResult(startId, isTest, destination, subscriptionId, location = null, ageLabel = null)
            return
        }

        val timeout = Runnable {
            if (resolved) return@Runnable
            resolved = true
            try { locationManager.removeUpdates(listener) } catch (_: Exception) { }
            useLastKnownAndFinish(startId, isTest, locationManager, destination, subscriptionId)
        }
        timeoutRunnable = timeout
        handler.postDelayed(timeout, Constants.GPS_TIMEOUT_MS)
    }

    @SuppressLint("MissingPermission") // hasRequiredPermissions() already verified ACCESS_FINE_LOCATION
    private fun useLastKnownAndFinish(
        startId: Int,
        isTest: Boolean,
        locationManager: LocationManager,
        destination: String,
        subscriptionId: Int
    ) {
        val candidates = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
            .mapNotNull {
                try { locationManager.getLastKnownLocation(it) } catch (_: Exception) { null }
            }
        val best = candidates.maxByOrNull { it.time }
        if (best == null) {
            finishWithResult(startId, isTest, destination, subscriptionId, location = null, ageLabel = null)
            return
        }
        val ageMs = System.currentTimeMillis() - best.time
        val ageLabel = formatAge(ageMs)
        finishWithResult(startId, isTest, destination, subscriptionId, best, ageLabel)
    }

    private fun formatAge(ageMs: Long): String {
        val minutes = ageMs / 60_000L
        return when {
            minutes < 1 -> "last known, <1 min old"
            minutes < 60 -> "last known, ${minutes}min old"
            else -> "last known, ${minutes / 60}h old"
        }
    }

    private fun finishWithResult(
        startId: Int,
        isTest: Boolean,
        destination: String,
        subscriptionId: Int,
        location: Location?,
        ageLabel: String?
    ) {
        val cellSnapshots = try {
            val telephonyManager = getSystemService(TelephonyManager::class.java)
            if (telephonyManager != null) CellInfoHelper.getCellSnapshots(telephonyManager) else emptyList()
        } catch (_: Exception) {
            emptyList()
        }

        val body = MessageBuilder.build(location, ageLabel, cellSnapshots)
        val sent = SmsSender.send(this, destination, subscriptionId, body)

        if (sent) {
            PrefsRepository(this).lastSentTimestamp = System.currentTimeMillis()
            val summary = if (location != null) "fix sent" else "no fix, cell info only"
            EventLogRepository.addEvent(this, "Sent location to $destination ($summary)")
            NotificationHelper.showResultNotification(
                this,
                getString(R.string.notification_sent_title),
                getString(R.string.notification_sent_text, destination)
            )
            broadcastResult(
                isTest, success = true, destination = destination,
                hasFix = location != null, latitude = location?.latitude, longitude = location?.longitude,
                accuracyMeters = if (location?.hasAccuracy() == true) location.accuracy else null,
                ageLabel = ageLabel, failureReason = null
            )
        } else {
            EventLogRepository.addEvent(this, "Failed to send SMS to $destination")
            NotificationHelper.showResultNotification(
                this,
                getString(R.string.notification_failed_title),
                getString(R.string.notification_failed_send)
            )
            broadcastResult(isTest, success = false, destination = destination, failureReason = "send_failed")
        }

        finishAndStop(startId)
    }

    /**
     * Local, same-package broadcast of the outcome, so the UI (if it's open) can show a result
     * screen instead of the person having to dig through the event log. Purely additive - every
     * existing notification/event-log/prefs write above still happens exactly as before, whether
     * or not anything is listening for this.
     */
    private fun broadcastResult(
        isTest: Boolean,
        success: Boolean,
        destination: String,
        hasFix: Boolean = false,
        latitude: Double? = null,
        longitude: Double? = null,
        accuracyMeters: Float? = null,
        ageLabel: String? = null,
        failureReason: String?
    ) {
        val intent = Intent(Constants.ACTION_LOCATION_RESULT).apply {
            setPackage(packageName)
            putExtra(Constants.EXTRA_IS_TEST, isTest)
            putExtra(Constants.EXTRA_SUCCESS, success)
            putExtra(Constants.EXTRA_DESTINATION, destination)
            putExtra(Constants.EXTRA_TIMESTAMP, System.currentTimeMillis())
            putExtra(Constants.EXTRA_HAS_FIX, hasFix)
            if (latitude != null) putExtra(Constants.EXTRA_LATITUDE, latitude)
            if (longitude != null) putExtra(Constants.EXTRA_LONGITUDE, longitude)
            if (accuracyMeters != null) putExtra(Constants.EXTRA_ACCURACY_METERS, accuracyMeters)
            if (ageLabel != null) putExtra(Constants.EXTRA_AGE_LABEL, ageLabel)
            if (failureReason != null) putExtra(Constants.EXTRA_FAILURE_REASON, failureReason)
        }
        sendBroadcast(intent)
    }

    private fun cleanupLocationRequest() {
        timeoutRunnable?.let { handler.removeCallbacks(it) }
        timeoutRunnable = null
        val listener = locationListener
        if (listener != null) {
            try {
                getSystemService(LocationManager::class.java)?.removeUpdates(listener)
            } catch (_: Exception) {
            }
        }
        locationListener = null
    }

    private fun finishAndStop(startId: Int) {
        cleanupLocationRequest()
        isProcessing.set(false)
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf(startId)
    }

    override fun onDestroy() {
        cleanupLocationRequest()
        isProcessing.set(false)
        super.onDestroy()
    }
}
