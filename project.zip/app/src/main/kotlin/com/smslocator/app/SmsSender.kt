package com.smslocator.app

import android.content.Context
import android.os.Build
import android.telephony.SmsManager

/** Thin wrapper over SmsManager that resolves the configured SIM and splits long bodies. */
object SmsSender {

    /** @return true if the send was handed to the radio without an immediate exception. */
    fun send(context: Context, destination: String, subscriptionId: Int, body: String): Boolean {
        return try {
            val smsManager = resolveManager(context, subscriptionId)
            val parts = smsManager.divideMessage(body)
            if (parts.size <= 1) {
                smsManager.sendTextMessage(destination, null, body, null, null)
            } else {
                smsManager.sendMultipartTextMessage(destination, null, parts, null, null)
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    @Suppress("DEPRECATION")
    private fun resolveManager(context: Context, subscriptionId: Int): SmsManager {
        if (subscriptionId == Constants.NO_SUBSCRIPTION_ID) {
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                context.getSystemService(SmsManager::class.java) ?: SmsManager.getDefault()
            } else {
                SmsManager.getDefault()
            }
        }
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val base = context.getSystemService(SmsManager::class.java) ?: SmsManager.getDefault()
                base.createForSubscriptionId(subscriptionId)
            } else {
                SmsManager.getSmsManagerForSubscriptionId(subscriptionId)
            }
        } catch (_: Exception) {
            SmsManager.getDefault()
        }
    }
}
