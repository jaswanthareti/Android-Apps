package com.smslocator.app

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.text.format.DateFormat
import android.view.WindowManager
import androidx.core.content.ContextCompat
import androidx.core.widget.ImageViewCompat
import androidx.fragment.app.DialogFragment
import com.smslocator.app.databinding.FragmentResultDialogBinding
import java.util.Date

/**
 * Shown right after a "Test now" run finishes - success or failure - with the time, whether a
 * live GPS fix or a last-known/cell-only reply went out, and the accuracy if known. Only ever
 * shown for a Test trigger (see MainActivity's broadcast receiver): a real incoming SMS trigger
 * still only surfaces through the existing notification, so this never pops up unprompted while
 * someone is just using the app for something else.
 */
class ResultDialogFragment : DialogFragment() {

    companion object {
        const val TAG = "ResultDialogFragment"

        private const val ARG_SUCCESS = "arg_success"
        private const val ARG_DESTINATION = "arg_destination"
        private const val ARG_TIMESTAMP = "arg_timestamp"
        private const val ARG_HAS_FIX = "arg_has_fix"
        private const val ARG_LATITUDE = "arg_latitude"
        private const val ARG_LONGITUDE = "arg_longitude"
        private const val ARG_ACCURACY = "arg_accuracy"
        private const val ARG_AGE_LABEL = "arg_age_label"
        private const val ARG_FAILURE_REASON = "arg_failure_reason"

        fun newInstance(
            success: Boolean,
            destination: String,
            timestamp: Long,
            hasFix: Boolean,
            latitude: Double?,
            longitude: Double?,
            accuracyMeters: Float?,
            ageLabel: String?,
            failureReason: String?
        ): ResultDialogFragment {
            val fragment = ResultDialogFragment()
            fragment.arguments = Bundle().apply {
                putBoolean(ARG_SUCCESS, success)
                putString(ARG_DESTINATION, destination)
                putLong(ARG_TIMESTAMP, timestamp)
                putBoolean(ARG_HAS_FIX, hasFix)
                if (latitude != null) putDouble(ARG_LATITUDE, latitude)
                if (longitude != null) putDouble(ARG_LONGITUDE, longitude)
                if (accuracyMeters != null) putFloat(ARG_ACCURACY, accuracyMeters)
                if (ageLabel != null) putString(ARG_AGE_LABEL, ageLabel)
                if (failureReason != null) putString(ARG_FAILURE_REASON, failureReason)
            }
            return fragment
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val binding = FragmentResultDialogBinding.inflate(layoutInflater)
        val args = requireArguments()

        val success = args.getBoolean(ARG_SUCCESS)
        val destination = args.getString(ARG_DESTINATION).orEmpty()
        val timestamp = args.getLong(ARG_TIMESTAMP)
        val hasFix = args.getBoolean(ARG_HAS_FIX)

        val successColor = ContextCompat.getColor(requireContext(), R.color.status_success)
        val successContainer = ContextCompat.getColor(requireContext(), R.color.status_success_container)
        val errorColor = ContextCompat.getColor(requireContext(), R.color.status_error)
        val errorContainer = ContextCompat.getColor(requireContext(), R.color.status_error_container)

        if (success) {
            binding.imageResultIcon.setImageResource(R.drawable.ic_status_success)
            ImageViewCompat.setImageTintList(binding.imageResultIcon, android.content.res.ColorStateList.valueOf(successColor))
            binding.imageResultIcon.backgroundTintList = android.content.res.ColorStateList.valueOf(successContainer)
            binding.textResultTitle.text = getString(R.string.result_title_success)
            binding.textResultSubtitle.text = getString(R.string.result_subtitle_success, destination)
        } else {
            binding.imageResultIcon.setImageResource(R.drawable.ic_status_error)
            ImageViewCompat.setImageTintList(binding.imageResultIcon, android.content.res.ColorStateList.valueOf(errorColor))
            binding.imageResultIcon.backgroundTintList = android.content.res.ColorStateList.valueOf(errorContainer)
            binding.textResultTitle.text = getString(R.string.result_title_failure)
            binding.textResultSubtitle.text = when (args.getString(ARG_FAILURE_REASON)) {
                "no_destination" -> getString(R.string.result_subtitle_failure_no_destination)
                "missing_permission" -> getString(R.string.result_subtitle_failure_missing_permission)
                else -> getString(R.string.result_subtitle_failure_send_failed, destination)
            }
        }

        binding.textResultTime.text = DateFormat.getLongDateFormat(requireContext()).format(Date(timestamp)).toString() +
            ", " + DateFormat.getTimeFormat(requireContext()).format(Date(timestamp))

        if (success) {
            binding.textResultLocation.text = if (hasFix && args.containsKey(ARG_LATITUDE) && args.containsKey(ARG_LONGITUDE)) {
                val lat = args.getDouble(ARG_LATITUDE)
                val lon = args.getDouble(ARG_LONGITUDE)
                val latDir = if (lat >= 0) "N" else "S"
                val lonDir = if (lon >= 0) "E" else "W"
                "%.4f° %s, %.4f° %s".format(kotlin.math.abs(lat), latDir, kotlin.math.abs(lon), lonDir)
            } else {
                getString(R.string.result_location_no_fix)
            }

            binding.textResultAccuracy.text = if (args.containsKey(ARG_ACCURACY)) {
                getString(R.string.result_accuracy_meters, args.getFloat(ARG_ACCURACY))
            } else {
                args.getString(ARG_AGE_LABEL) ?: getString(R.string.result_accuracy_unknown)
            }
        } else {
            binding.rowLocation.visibility = android.view.View.GONE
            binding.rowAccuracy.visibility = android.view.View.GONE
        }

        binding.buttonResultOk.setOnClickListener { dismiss() }

        val dialog = Dialog(requireContext())
        dialog.setContentView(binding.root)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            // A plain Dialog's window defaults to WRAP_CONTENT width, which has nothing to wrap
            // against and collapses to the narrowest forced measurement inside (every word on its
            // own line, the OK button text wrapping mid-word) - this is what made the dialog
            // unreadably thin. Setting an explicit width fixes that; 90% of the screen, capped so
            // it doesn't look stretched on a tablet.
            val maxWidthPx = (360 * resources.displayMetrics.density).toInt()
            val width = minOf((resources.displayMetrics.widthPixels * 0.9).toInt(), maxWidthPx)
            setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT)
        }
        return dialog
    }
}
