package com.smslocator.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.telephony.SubscriptionManager
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.smslocator.app.databinding.ActivityMainBinding

/**
 * Settings screen. Owns no background logic itself - it only reads/writes [PrefsRepository],
 * requests runtime permissions, and offers a "Test now" button that starts
 * [LocationForegroundService] directly, exactly the way [SmsReceiver] would, so the full
 * pipeline (GPS, cell info, SMS send, notification, log) can be exercised without waiting for a
 * real trigger SMS.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: PrefsRepository

    /** subscriptionId per spinner position; position 0 is always "Default SIM". */
    private var simSubscriptionIds: List<Int> = listOf(Constants.NO_SUBSCRIPTION_ID)

    private val corePermissions = buildList {
        add(Manifest.permission.RECEIVE_SMS)
        add(Manifest.permission.SEND_SMS)
        add(Manifest.permission.READ_PHONE_STATE)
        add(Manifest.permission.ACCESS_FINE_LOCATION)
        add(Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            add(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private val requestCorePermissions = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
    ) {
        refreshPermissionStatus()
    }

    private val requestBackgroundLocation = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) {
        refreshPermissionStatus()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = PrefsRepository(this)
        NotificationHelper.ensureChannel(this)

        loadFromPrefs()
        populateSimSpinner()
        refreshPermissionStatus()
        refreshEventLog()

        binding.buttonGrantPermissions.setOnClickListener {
            requestCorePermissions.launch(corePermissions.toTypedArray())
        }

        binding.buttonBackgroundLocation.setOnClickListener {
            requestBackgroundLocationAccess()
        }

        binding.buttonOpenAppSettings.setOnClickListener {
            openAppSettings()
        }

        binding.buttonSave.setOnClickListener {
            saveToPrefs()
        }

        binding.buttonTestNow.setOnClickListener {
            runTestNow()
        }

        binding.buttonRefreshLog.setOnClickListener {
            refreshEventLog()
        }

        binding.buttonClearLog.setOnClickListener {
            EventLogRepository.clear(this)
            refreshEventLog()
        }
    }

    override fun onResume() {
        super.onResume()
        // Permission state (and background location, which often routes through system Settings)
        // can change while this activity isn't in the foreground, so re-check every time it's shown.
        refreshPermissionStatus()
        refreshEventLog()
    }

    private fun loadFromPrefs() {
        binding.switchEnabled.isChecked = prefs.enabled
        binding.editTriggerPhrase.setText(prefs.triggerPhrase)
        binding.checkCaseSensitive.isChecked = prefs.caseSensitive
        binding.checkTrimWhitespace.isChecked = prefs.trimWhitespace
        binding.editAllowedSenders.setText(prefs.allowedSendersRaw)
        binding.editDestinationNumber.setText(prefs.destinationNumber)
        binding.checkReplyToSender.isChecked = prefs.replyToSender
    }

    private fun saveToPrefs() {
        val triggerPhrase = binding.editTriggerPhrase.text.toString()
        val allowedSendersRaw = binding.editAllowedSenders.text.toString()
        val destinationNumber = binding.editDestinationNumber.text.toString()
        val replyToSender = binding.checkReplyToSender.isChecked
        val wantsEnabled = binding.switchEnabled.isChecked

        if (wantsEnabled && triggerPhrase.isBlank()) {
            Toast.makeText(this, R.string.toast_trigger_phrase_required, Toast.LENGTH_LONG).show()
            binding.switchEnabled.isChecked = false
        }
        if (wantsEnabled && allowedSendersRaw.lines().map { it.trim() }.none { it.isNotEmpty() }) {
            Toast.makeText(this, R.string.toast_allowed_senders_required, Toast.LENGTH_LONG).show()
            binding.switchEnabled.isChecked = false
        }
        if (wantsEnabled && !replyToSender && destinationNumber.isBlank()) {
            Toast.makeText(this, R.string.toast_destination_required, Toast.LENGTH_LONG).show()
            binding.switchEnabled.isChecked = false
        }

        prefs.triggerPhrase = triggerPhrase
        prefs.caseSensitive = binding.checkCaseSensitive.isChecked
        prefs.trimWhitespace = binding.checkTrimWhitespace.isChecked
        prefs.allowedSendersRaw = allowedSendersRaw
        prefs.destinationNumber = destinationNumber
        prefs.replyToSender = replyToSender
        prefs.simSubscriptionId = currentlySelectedSubscriptionId()
        prefs.enabled = binding.switchEnabled.isChecked

        Toast.makeText(this, R.string.toast_saved, Toast.LENGTH_SHORT).show()
    }

    private fun runTestNow() {
        // Persist current field values first so the test run uses exactly what's on screen,
        // even if the user hasn't pressed Save yet.
        saveToPrefs()

        if (prefs.destinationNumber.isBlank()) {
            Toast.makeText(this, R.string.toast_test_needs_destination, Toast.LENGTH_LONG).show()
            return
        }
        if (!hasAllCorePermissionsGranted()) {
            Toast.makeText(this, R.string.toast_test_needs_permissions, Toast.LENGTH_LONG).show()
            return
        }

        val serviceIntent = Intent(this, LocationForegroundService::class.java).apply {
            action = Constants.ACTION_TEST_TRIGGER
        }
        ContextCompat.startForegroundService(this, serviceIntent)
        Toast.makeText(this, R.string.toast_test_triggered, Toast.LENGTH_SHORT).show()
    }

    private fun populateSimSpinner() {
        val labels = mutableListOf("Default SIM")
        val ids = mutableListOf(Constants.NO_SUBSCRIPTION_ID)

        val hasPhoneStatePermission = ContextCompat.checkSelfPermission(
            this, Manifest.permission.READ_PHONE_STATE
        ) == PackageManager.PERMISSION_GRANTED

        if (hasPhoneStatePermission) {
            try {
                val subscriptionManager = getSystemService(SubscriptionManager::class.java)
                val activeSubs = subscriptionManager?.activeSubscriptionInfoList
                activeSubs?.forEach { info ->
                    val displayName = info.displayName?.toString() ?: "SIM ${info.simSlotIndex + 1}"
                    labels.add("$displayName (slot ${info.simSlotIndex + 1})")
                    ids.add(info.subscriptionId)
                }
            } catch (_: SecurityException) {
                // Permission was granted a moment ago but revoked again, or OEM quirk; spinner
                // just falls back to "Default SIM only", which is still a safe, working choice.
            }
        }

        simSubscriptionIds = ids
        binding.spinnerSim.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

        val savedIndex = ids.indexOf(prefs.simSubscriptionId).let { if (it < 0) 0 else it }
        binding.spinnerSim.setSelection(savedIndex)
    }

    private fun currentlySelectedSubscriptionId(): Int {
        val position = binding.spinnerSim.selectedItemPosition
        return simSubscriptionIds.getOrElse(position) { Constants.NO_SUBSCRIPTION_ID }
    }

    private fun requestBackgroundLocationAccess() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            // Below API 29, ACCESS_FINE_LOCATION alone already grants background access.
            refreshPermissionStatus()
            return
        }
        val fineGranted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        if (!fineGranted) {
            Toast.makeText(this, R.string.toast_test_needs_permissions, Toast.LENGTH_LONG).show()
            requestCorePermissions.launch(corePermissions.toTypedArray())
            return
        }
        // On many OEMs (including Samsung's One UI), the system refuses to show the
        // "Allow all the time" dialog directly and instead silently no-ops the request; the
        // reliable path is sending the user to this app's permission screen in Settings.
        requestBackgroundLocation.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
    }

    private fun openAppSettings() {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", packageName, null)
        }
        startActivity(intent)
    }

    private fun hasAllCorePermissionsGranted(): Boolean =
        corePermissions.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }

    private fun refreshPermissionStatus() {
        val sb = StringBuilder()
        val entries = listOf(
            "RECEIVE_SMS" to Manifest.permission.RECEIVE_SMS,
            "SEND_SMS" to Manifest.permission.SEND_SMS,
            "READ_PHONE_STATE" to Manifest.permission.READ_PHONE_STATE,
            "ACCESS_FINE_LOCATION" to Manifest.permission.ACCESS_FINE_LOCATION,
        )
        for ((label, permission) in entries) {
            val granted = ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
            sb.append(label).append(": ")
                .append(getString(if (granted) R.string.permission_granted else R.string.permission_missing))
                .append('\n')
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
            sb.append("POST_NOTIFICATIONS: ")
                .append(getString(if (granted) R.string.permission_granted else R.string.permission_missing))
                .append('\n')
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_BACKGROUND_LOCATION) ==
                PackageManager.PERMISSION_GRANTED
            sb.append("ACCESS_BACKGROUND_LOCATION: ")
                .append(getString(if (granted) R.string.permission_granted else R.string.permission_missing))
        }
        binding.textPermissionsStatus.text = sb.toString().trimEnd()
    }

    private fun refreshEventLog() {
        val events = EventLogRepository.getEvents(this)
        binding.textEventLog.text = if (events.isEmpty()) {
            getString(R.string.placeholder_event_log)
        } else {
            events.joinToString("\n") { it.formatted() }
        }
    }
}
