package com.smslocator.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.telephony.SubscriptionManager
import android.text.format.DateFormat
import android.view.View
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.snackbar.Snackbar
import com.smslocator.app.databinding.ActivityMainBinding
import com.smslocator.app.databinding.ItemPermissionRowBinding
import java.util.Date

/**
 * Settings screen. Owns no background logic itself - it only reads/writes [PrefsRepository],
 * requests runtime permissions, and offers a "Test now" button that starts
 * [LocationForegroundService] directly, exactly the way [SmsReceiver] would, so the full
 * pipeline (GPS, cell info, SMS send, notification, log) can be exercised without waiting for a
 * real trigger SMS.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: PrefsRepository
    private lateinit var eventAdapter: EventAdapter

    /** subscriptionId per dropdown position; position 0 is always "Default SIM". */
    private var simSubscriptionIds: List<Int> = listOf(Constants.NO_SUBSCRIPTION_ID)
    private var simLabels: List<String> = listOf("Default SIM")

    private val corePermissions = buildList {
        add(Manifest.permission.RECEIVE_SMS)
        add(Manifest.permission.SEND_SMS)
        add(Manifest.permission.READ_PHONE_STATE)
        add(Manifest.permission.ACCESS_FINE_LOCATION)
        add(Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            add(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private val requestCorePermissions = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
    ) {
        refreshPermissionStatus()
    }

    private val requestBackgroundLocation = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) {
        refreshPermissionStatus()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Edge-to-edge is mandatory from API 36 (no more opt-out), so draw behind both system
        // bars ourselves and push the real content down/up with insets below.
        WindowCompat.setDecorFitsSystemWindows(window, false)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        applyEdgeToEdgeInsets()
        applyStatusBarIconAppearance()

        prefs = PrefsRepository(this)
        NotificationHelper.ensureChannel(this)

        setSupportActionBar(binding.toolbar)

        eventAdapter = EventAdapter(emptyList())
        binding.recyclerEvents.layoutManager = LinearLayoutManager(this)
        binding.recyclerEvents.adapter = eventAdapter

        loadFromPrefs()
        populateSimDropdown()
        refreshPermissionStatus()
        refreshEventLog()
        refreshStatusCard()

        binding.buttonGrantPermissions.setOnClickListener {
            requestCorePermissions.launch(corePermissions.toTypedArray())
        }

        binding.buttonBackgroundLocation.setOnClickListener {
            requestBackgroundLocationAccess()
        }

        binding.buttonOpenAppSettings.setOnClickListener {
            openAppSettings()
        }

        binding.buttonSave.setOnClickListener {
            saveToPrefs()
        }

        binding.buttonTestNow.setOnClickListener {
            runTestNow()
        }

        binding.buttonRefreshLog.setOnClickListener {
            refreshEventLog()
        }

        binding.buttonClearLog.setOnClickListener {
            EventLogRepository.clear(this)
            refreshEventLog()
        }
    }

    override fun onResume() {
        super.onResume()
        // Permission state (and background location, which often routes through system Settings)
        // can change while this activity isn't in the foreground, so re-check every time it's shown.
        refreshPermissionStatus()
        refreshEventLog()
        refreshStatusCard()
    }

    /**
     * With decorFitsSystemWindows(false), nothing pads around the status/navigation bars on its
     * own anymore, so the toolbar would sit under the status bar and the scroll content under
     * the navigation bar unless we apply the insets ourselves.
     */
    private fun applyEdgeToEdgeInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(binding.appBarLayout) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.updatePadding(top = bars.top)
            insets
        }
        ViewCompat.setOnApplyWindowInsetsListener(binding.scrollRoot) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.updatePadding(bottom = bars.bottom)
            insets
        }
    }

    /** Dark status-bar icons on a light background, light icons on a dark background. */
    private fun applyStatusBarIconAppearance() {
        val isNightMode = (resources.configuration.uiMode and
            android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES
        val controller = androidx.core.view.WindowInsetsControllerCompat(window, binding.root)
        controller.isAppearanceLightStatusBars = !isNightMode
        controller.isAppearanceLightNavigationBars = !isNightMode
    }

    private fun loadFromPrefs() {
        binding.switchEnabled.isChecked = prefs.enabled
        binding.editTriggerPhrase.setText(prefs.triggerPhrase)
        binding.checkCaseSensitive.isChecked = prefs.caseSensitive
        binding.checkTrimWhitespace.isChecked = prefs.trimWhitespace
        binding.editAllowedSenders.setText(prefs.allowedSendersRaw)
        binding.editDestinationNumber.setText(prefs.destinationNumber)
        binding.checkReplyToSender.isChecked = prefs.replyToSender
    }

    private fun saveToPrefs() {
        val triggerPhrase = binding.editTriggerPhrase.text.toString()
        val allowedSendersRaw = binding.editAllowedSenders.text.toString()
        val destinationNumber = binding.editDestinationNumber.text.toString()
        val replyToSender = binding.checkReplyToSender.isChecked
        var wantsEnabled = binding.switchEnabled.isChecked

        if (wantsEnabled && triggerPhrase.isBlank()) {
            showSnackbar(R.string.toast_trigger_phrase_required)
            wantsEnabled = false
            binding.switchEnabled.isChecked = false
        }
        if (wantsEnabled && allowedSendersRaw.lines().map { it.trim() }.none { it.isNotEmpty() }) {
            showSnackbar(R.string.toast_allowed_senders_required)
            wantsEnabled = false
            binding.switchEnabled.isChecked = false
        }
        if (wantsEnabled && !replyToSender && destinationNumber.isBlank()) {
            showSnackbar(R.string.toast_destination_required)
            wantsEnabled = false
            binding.switchEnabled.isChecked = false
        }

        prefs.triggerPhrase = triggerPhrase
        prefs.caseSensitive = binding.checkCaseSensitive.isChecked
        prefs.trimWhitespace = binding.checkTrimWhitespace.isChecked
        prefs.allowedSendersRaw = allowedSendersRaw
        prefs.destinationNumber = destinationNumber
        prefs.replyToSender = replyToSender
        prefs.simSubscriptionId = currentlySelectedSubscriptionId()
        prefs.enabled = binding.switchEnabled.isChecked

        refreshStatusCard()
        showSnackbar(R.string.toast_saved)
    }

    private fun runTestNow() {
        // Persist current field values first so the test run uses exactly what's on screen,
        // even if the user hasn't pressed Save yet.
        saveToPrefs()

        if (prefs.destinationNumber.isBlank()) {
            showSnackbar(R.string.toast_test_needs_destination)
            return
        }
        if (!hasAllCorePermissionsGranted()) {
            showSnackbar(R.string.toast_test_needs_permissions)
            return
        }

        val serviceIntent = Intent(this, LocationForegroundService::class.java).apply {
            action = Constants.ACTION_TEST_TRIGGER
        }
        ContextCompat.startForegroundService(this, serviceIntent)
        showSnackbar(R.string.toast_test_triggered)
    }

    private fun populateSimDropdown() {
        val labels = mutableListOf("Default SIM")
        val ids = mutableListOf(Constants.NO_SUBSCRIPTION_ID)

        val hasPhoneStatePermission = ContextCompat.checkSelfPermission(
            this, Manifest.permission.READ_PHONE_STATE
        ) == PackageManager.PERMISSION_GRANTED

        if (hasPhoneStatePermission) {
            try {
                val subscriptionManager = getSystemService(SubscriptionManager::class.java)
                val activeSubs = subscriptionManager?.activeSubscriptionInfoList
                activeSubs?.forEach { info ->
                    val displayName = info.displayName?.toString() ?: "SIM ${info.simSlotIndex + 1}"
                    labels.add("$displayName (slot ${info.simSlotIndex + 1})")
                    ids.add(info.subscriptionId)
                }
            } catch (_: SecurityException) {
                // Permission was granted a moment ago but revoked again, or OEM quirk; dropdown
                // just falls back to "Default SIM only", which is still a safe, working choice.
            }
        }

        simSubscriptionIds = ids
        simLabels = labels

        binding.dropdownSim.setAdapter(
            ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
        )

        val savedIndex = ids.indexOf(prefs.simSubscriptionId).let { if (it < 0) 0 else it }
        binding.dropdownSim.setText(labels[savedIndex], false)
    }

    private fun currentlySelectedSubscriptionId(): Int {
        val currentText = binding.dropdownSim.text.toString()
        val index = simLabels.indexOf(currentText)
        return simSubscriptionIds.getOrElse(if (index < 0) 0 else index) { Constants.NO_SUBSCRIPTION_ID }
    }

    private fun requestBackgroundLocationAccess() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            // Below API 29, ACCESS_FINE_LOCATION alone already grants background access.
            refreshPermissionStatus()
            return
        }
        val fineGranted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        if (!fineGranted) {
            showSnackbar(R.string.toast_test_needs_permissions)
            requestCorePermissions.launch(corePermissions.toTypedArray())
            return
        }
        // On many OEMs (including Samsung's One UI), the system refuses to show the
        // "Allow all the time" dialog directly and instead silently no-ops the request; the
        // reliable path is sending the user to this app's permission screen in Settings.
        requestBackgroundLocation.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
    }

    private fun openAppSettings() {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", packageName, null)
        }
        startActivity(intent)
    }

    private fun hasAllCorePermissionsGranted(): Boolean =
        corePermissions.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }

    /** One row per required permission, each with a status icon + label + granted/missing text. */
    private fun refreshPermissionStatus() {
        val entries = buildList {
            add(Triple("SMS receive & send", Manifest.permission.RECEIVE_SMS, true))
            add(Triple("Phone state (for dual-SIM)", Manifest.permission.READ_PHONE_STATE, true))
            add(Triple("Precise location", Manifest.permission.ACCESS_FINE_LOCATION, true))
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                add(Triple("Notifications", Manifest.permission.POST_NOTIFICATIONS, true))
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                add(Triple("Background location", Manifest.permission.ACCESS_BACKGROUND_LOCATION, false))
            }
        }

        binding.layoutPermissionRows.removeAllViews()
        for ((label, permission, _) in entries) {
            val granted = ContextCompat.checkSelfPermission(this, permission) ==
                PackageManager.PERMISSION_GRANTED
            val row = buildPermissionRow(label, granted)
            binding.layoutPermissionRows.addView(row)
        }
    }

    /**
     * Inflated from item_permission_row.xml rather than built with `View(this)`/`TextView(this)`
     * calls, so every text-appearance/color reference goes through normal XML resource
     * resolution (which sees Material's styles and theme attrs) instead of this app module's own
     * generated R class, which under AGP's non-transitive R classes does not contain them.
     */
    private fun buildPermissionRow(label: String, granted: Boolean): View {
        val row = layoutInflater.inflate(R.layout.item_permission_row, binding.layoutPermissionRows, false)
        val rowBinding = ItemPermissionRowBinding.bind(row)

        rowBinding.imagePermissionIcon.setImageResource(
            if (granted) R.drawable.ic_status_success else R.drawable.ic_status_warning
        )
        rowBinding.textPermissionLabel.text = label
        rowBinding.textPermissionStatus.text =
            getString(if (granted) R.string.permission_granted else R.string.permission_missing)
        rowBinding.textPermissionStatus.setTextAppearance(
            if (granted) R.style.TextAppearance_SmsLocator_PermissionGranted
            else R.style.TextAppearance_SmsLocator_PermissionMissing
        )

        return row
    }

    private fun refreshEventLog() {
        val events = EventLogRepository.getEvents(this)
        if (events.isEmpty()) {
            binding.textEventLogEmpty.visibility = View.VISIBLE
            binding.recyclerEvents.visibility = View.GONE
        } else {
            binding.textEventLogEmpty.visibility = View.GONE
            binding.recyclerEvents.visibility = View.VISIBLE
            eventAdapter.submitList(events)
        }
    }

    /** Updates the top status card: active/inactive pill, icon, and "last sent" line. */
    private fun refreshStatusCard() {
        val active = prefs.enabled && prefs.isConfiguredForSending()
        binding.textStatusSummary.text = getString(
            if (prefs.enabled) R.string.status_active else R.string.status_inactive
        )
        binding.textStatusSummary.setCompoundDrawablesRelativeWithIntrinsicBounds(
            if (active) R.drawable.ic_shield_check else R.drawable.ic_status_warning, 0, 0, 0
        )

        val lastSent = prefs.lastSentTimestamp
        binding.textLastSent.text = if (lastSent <= 0L) {
            getString(R.string.status_last_sent_never)
        } else {
            val formatted = DateFormat.getLongDateFormat(this).format(Date(lastSent)).toString() +
                ", " + DateFormat.getTimeFormat(this).format(Date(lastSent))
            getString(R.string.status_last_sent_format, formatted)
        }
    }

    private fun showSnackbar(resId: Int) {
        Snackbar.make(binding.coordinatorRoot, resId, Snackbar.LENGTH_LONG).show()
    }
}
