package com.smslocator.app

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import com.google.android.material.snackbar.Snackbar
import com.smslocator.app.databinding.ActivityMainBinding

/**
 * Nav shell: owns the toolbar, the bottom navigation, and everything shared across tabs
 * (preferences access, runtime permission requests) - every section that used to be one long
 * scrolling screen now lives in its own Fragment (see HomeFragment / SettingsFragment /
 * PermissionsFragment / EventsFragment), swapped into [binding].fragmentContainer below.
 *
 * Fragments reach the shared bits through `(requireActivity() as MainActivity)` rather than each
 * re-implementing permission checks or opening their own PrefsRepository instance, so there's one
 * source of truth for "is everything granted" and one SharedPreferences-backed repository shared
 * by all four tabs.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    /** Shared by every fragment - there is exactly one SharedPreferences-backed repository. */
    val prefs: PrefsRepository by lazy { PrefsRepository(this) }

    val corePermissions: List<String> = buildList {
        add(Manifest.permission.RECEIVE_SMS)
        add(Manifest.permission.SEND_SMS)
        add(Manifest.permission.READ_PHONE_STATE)
        add(Manifest.permission.ACCESS_FINE_LOCATION)
        add(Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            add(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // No-op result callbacks deliberately: each fragment re-checks live permission state itself
    // in its own onResume(), which already fires right after the system permission dialog (or the
    // app-settings screen) closes and this activity comes back to the foreground. That's the same
    // "re-check on resume" behavior the single-screen version relied on.
    private val requestCorePermissionsLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    private val requestBackgroundLocationLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Edge-to-edge is mandatory from API 36 (no more opt-out), so draw behind both system
        // bars ourselves and push the real content down/up with insets below.
        WindowCompat.setDecorFitsSystemWindows(window, false)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        applyEdgeToEdgeInsets()
        applyStatusBarIconAppearance()
        NotificationHelper.ensureChannel(this)

        setSupportActionBar(binding.toolbar)
        updateToolbarSubtitle()

        binding.bottomNav.setOnItemSelectedListener { item ->
            val fragment = when (item.itemId) {
                R.id.navHome -> HomeFragment()
                R.id.navPermissions -> PermissionsFragment()
                R.id.navEvents -> EventsFragment()
                R.id.navSettings -> SettingsFragment()
                else -> return@setOnItemSelectedListener false
            }
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, fragment)
                .commit()
            true
        }

        if (savedInstanceState == null) {
            binding.bottomNav.selectedItemId = R.id.navHome
        }
    }

    override fun onResume() {
        super.onResume()
        updateToolbarSubtitle()
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(Constants.ACTION_LOCATION_RESULT)
        ContextCompat.registerReceiver(
            this, locationResultReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    override fun onStop() {
        super.onStop()
        try {
            unregisterReceiver(locationResultReceiver)
        } catch (_: IllegalArgumentException) {
            // Already unregistered (e.g. onStart never ran this instance) - harmless.
        }
    }

    /**
     * Only a Test-now run (EXTRA_IS_TEST) ever pops this dialog. A real incoming trigger SMS
     * still only surfaces through the existing system notification, same as before this phase -
     * so this never interrupts someone who's just using the app for something unrelated when a
     * genuine trigger happens to arrive.
     */
    private val locationResultReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (!intent.getBooleanExtra(Constants.EXTRA_IS_TEST, false)) return
            if (supportFragmentManager.findFragmentByTag(ResultDialogFragment.TAG) != null) return

            val hasFix = intent.getBooleanExtra(Constants.EXTRA_HAS_FIX, false)
            val dialog = ResultDialogFragment.newInstance(
                success = intent.getBooleanExtra(Constants.EXTRA_SUCCESS, false),
                destination = intent.getStringExtra(Constants.EXTRA_DESTINATION).orEmpty(),
                timestamp = intent.getLongExtra(Constants.EXTRA_TIMESTAMP, System.currentTimeMillis()),
                hasFix = hasFix,
                latitude = if (intent.hasExtra(Constants.EXTRA_LATITUDE)) intent.getDoubleExtra(Constants.EXTRA_LATITUDE, 0.0) else null,
                longitude = if (intent.hasExtra(Constants.EXTRA_LONGITUDE)) intent.getDoubleExtra(Constants.EXTRA_LONGITUDE, 0.0) else null,
                accuracyMeters = if (intent.hasExtra(Constants.EXTRA_ACCURACY_METERS)) intent.getFloatExtra(Constants.EXTRA_ACCURACY_METERS, 0f) else null,
                ageLabel = intent.getStringExtra(Constants.EXTRA_AGE_LABEL),
                failureReason = intent.getStringExtra(Constants.EXTRA_FAILURE_REASON)
            )
            dialog.show(supportFragmentManager, ResultDialogFragment.TAG)

            // The dialog itself is the result feedback now; the old "Test triggered..." snackbar
            // text is still shown the instant the button is tapped (see SettingsFragment), but
            // this is the actual outcome, so also refresh the Home tab status card if it's visible.
            updateToolbarSubtitle()
        }
    }

    /** Switches to a tab by its bottom-nav item id, e.g. from HomeFragment's "Open Settings" button. */
    fun switchToTab(itemId: Int) {
        binding.bottomNav.selectedItemId = itemId
    }

    /** The soothing line replaces the generic subtitle once Protection is actually on. */
    fun updateToolbarSubtitle() {
        binding.toolbar.subtitle = if (prefs.enabled) {
            getString(R.string.toolbar_subtitle_active)
        } else {
            getString(R.string.toolbar_subtitle)
        }
    }

    /**
     * With decorFitsSystemWindows(false), nothing pads around the status/navigation bars on its
     * own anymore, so the toolbar would sit under the status bar and the bottom nav under the
     * gesture/navigation bar unless we apply the insets ourselves.
     */
    private fun applyEdgeToEdgeInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(binding.appBarLayout) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.updatePadding(top = bars.top)
            insets
        }
        ViewCompat.setOnApplyWindowInsetsListener(binding.bottomNav) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.updatePadding(bottom = bars.bottom)
            insets
        }
    }

    /** Dark status-bar icons on a light background, light icons on a dark background. */
    private fun applyStatusBarIconAppearance() {
        val isNightMode = (resources.configuration.uiMode and
            android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES
        val controller = androidx.core.view.WindowInsetsControllerCompat(window, binding.root)
        controller.isAppearanceLightStatusBars = !isNightMode
        controller.isAppearanceLightNavigationBars = !isNightMode
    }

    fun hasAllCorePermissionsGranted(): Boolean =
        corePermissions.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }

    fun launchCorePermissionsRequest() {
        requestCorePermissionsLauncher.launch(corePermissions.toTypedArray())
    }

    fun requestBackgroundLocationAccess() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            // Below API 29, ACCESS_FINE_LOCATION alone already grants background access.
            return
        }
        val fineGranted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        if (!fineGranted) {
            showSnackbar(R.string.toast_test_needs_permissions)
            launchCorePermissionsRequest()
            return
        }
        // On many OEMs (including Samsung's One UI), the system refuses to show the
        // "Allow all the time" dialog directly and instead silently no-ops the request; the
        // reliable path is sending the user to this app's permission screen in Settings.
        requestBackgroundLocationLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
    }

    fun openAppSettings() {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", packageName, null)
        }
        startActivity(intent)
    }

    fun showSnackbar(resId: Int) {
        Snackbar.make(binding.root, resId, Snackbar.LENGTH_LONG).show()
    }
}
