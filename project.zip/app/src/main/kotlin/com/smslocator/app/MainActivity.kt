package com.smslocator.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import com.google.android.material.snackbar.Snackbar
import com.smslocator.app.databinding.ActivityMainBinding

/**
 * Nav shell: owns the toolbar, the bottom navigation, and everything shared across tabs
 * (preferences access, runtime permission requests) - every section that used to be one long
 * scrolling screen now lives in its own Fragment (see HomeFragment / SettingsFragment /
 * PermissionsFragment / EventsFragment), swapped into [binding].fragmentContainer below.
 *
 * Fragments reach the shared bits through `(requireActivity() as MainActivity)` rather than each
 * re-implementing permission checks or opening their own PrefsRepository instance, so there's one
 * source of truth for "is everything granted" and one SharedPreferences-backed repository shared
 * by all four tabs.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    /** Shared by every fragment - there is exactly one SharedPreferences-backed repository. */
    val prefs: PrefsRepository by lazy { PrefsRepository(this) }

    val corePermissions: List<String> = buildList {
        add(Manifest.permission.RECEIVE_SMS)
        add(Manifest.permission.SEND_SMS)
        add(Manifest.permission.READ_PHONE_STATE)
        add(Manifest.permission.ACCESS_FINE_LOCATION)
        add(Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            add(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // No-op result callbacks deliberately: each fragment re-checks live permission state itself
    // in its own onResume(), which already fires right after the system permission dialog (or the
    // app-settings screen) closes and this activity comes back to the foreground. That's the same
    // "re-check on resume" behavior the single-screen version relied on.
    private val requestCorePermissionsLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    private val requestBackgroundLocationLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Edge-to-edge is mandatory from API 36 (no more opt-out), so draw behind both system
        // bars ourselves and push the real content down/up with insets below.
        WindowCompat.setDecorFitsSystemWindows(window, false)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        applyEdgeToEdgeInsets()
        applyStatusBarIconAppearance()
        NotificationHelper.ensureChannel(this)

        setSupportActionBar(binding.toolbar)
        updateToolbarSubtitle()

        binding.bottomNav.setOnItemSelectedListener { item ->
            val fragment = when (item.itemId) {
                R.id.navHome -> HomeFragment()
                R.id.navPermissions -> PermissionsFragment()
                R.id.navEvents -> EventsFragment()
                R.id.navSettings -> SettingsFragment()
                else -> return@setOnItemSelectedListener false
            }
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, fragment)
                .commit()
            true
        }

        if (savedInstanceState == null) {
            binding.bottomNav.selectedItemId = R.id.navHome
        }
    }

    override fun onResume() {
        super.onResume()
        updateToolbarSubtitle()
    }

    /** Switches to a tab by its bottom-nav item id, e.g. from HomeFragment's "Open Settings" button. */
    fun switchToTab(itemId: Int) {
        binding.bottomNav.selectedItemId = itemId
    }

    /** The soothing line replaces the generic subtitle once Protection is actually on. */
    fun updateToolbarSubtitle() {
        binding.toolbar.subtitle = if (prefs.enabled) {
            getString(R.string.toolbar_subtitle_active)
        } else {
            getString(R.string.toolbar_subtitle)
        }
    }

    /**
     * With decorFitsSystemWindows(false), nothing pads around the status/navigation bars on its
     * own anymore, so the toolbar would sit under the status bar and the bottom nav under the
     * gesture/navigation bar unless we apply the insets ourselves.
     */
    private fun applyEdgeToEdgeInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(binding.appBarLayout) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.updatePadding(top = bars.top)
            insets
        }
        ViewCompat.setOnApplyWindowInsetsListener(binding.bottomNav) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.updatePadding(bottom = bars.bottom)
            insets
        }
    }

    /** Dark status-bar icons on a light background, light icons on a dark background. */
    private fun applyStatusBarIconAppearance() {
        val isNightMode = (resources.configuration.uiMode and
            android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES
        val controller = androidx.core.view.WindowInsetsControllerCompat(window, binding.root)
        controller.isAppearanceLightStatusBars = !isNightMode
        controller.isAppearanceLightNavigationBars = !isNightMode
    }

    fun hasAllCorePermissionsGranted(): Boolean =
        corePermissions.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }

    fun launchCorePermissionsRequest() {
        requestCorePermissionsLauncher.launch(corePermissions.toTypedArray())
    }

    fun requestBackgroundLocationAccess() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            // Below API 29, ACCESS_FINE_LOCATION alone already grants background access.
            return
        }
        val fineGranted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        if (!fineGranted) {
            showSnackbar(R.string.toast_test_needs_permissions)
            launchCorePermissionsRequest()
            return
        }
        // On many OEMs (including Samsung's One UI), the system refuses to show the
        // "Allow all the time" dialog directly and instead silently no-ops the request; the
        // reliable path is sending the user to this app's permission screen in Settings.
        requestBackgroundLocationLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
    }

    fun openAppSettings() {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", packageName, null)
        }
        startActivity(intent)
    }

    fun showSnackbar(resId: Int) {
        Snackbar.make(binding.root, resId, Snackbar.LENGTH_LONG).show()
    }
}
