package com.smslocator.app

import android.location.Location
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Builds the outgoing SMS body. Kept to plain ASCII throughout so the message is guaranteed to
 * use GSM-7 encoding (160 chars/part, 153 chars/part when concatenated) rather than UCS-2 (70/67
 * chars/part) - roughly doubling the budget for a 1-2 part message.
 */
object MessageBuilder {

    /** Conservative character budget for 2 concatenated GSM-7 SMS parts (153 * 2, minus margin). */
    private const val MAX_CHARS = 290

    private val timeFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

    fun build(
        location: Location?,
        locationAgeLabel: String?,
        cellSnapshots: List<CellSnapshot>
    ): String {
        val lines = ArrayList<String>()

        if (location != null) {
            val ageSuffix = if (locationAgeLabel != null) " ($locationAgeLabel)" else ""
            lines.add("Loc$ageSuffix: ${"%.6f".format(Locale.US, location.latitude)},${"%.6f".format(Locale.US, location.longitude)}")
            lines.add("Acc:${location.accuracy.toInt()}m @${timeFormat.format(Date(location.time))}")
            lines.add("https://maps.google.com/?q=${"%.6f".format(Locale.US, location.latitude)},${"%.6f".format(Locale.US, location.longitude)}")
        } else {
            lines.add("No GPS fix or last-known location available.")
        }

        if (cellSnapshots.isEmpty()) {
            lines.add("Cell: unavailable")
        } else {
            for (cell in cellSnapshots) {
                lines.add(cell.toCompactString())
            }
        }

        var body = lines.joinToString("\n")
        if (body.length > MAX_CHARS) {
            // Trim neighbour-cell lines first (dropping from the end) before ever truncating the
            // location fix itself, which is the most important part of the message.
            while (lines.size > 1 && body.length > MAX_CHARS) {
                lines.removeAt(lines.size - 1)
                body = lines.joinToString("\n")
            }
            if (body.length > MAX_CHARS) {
                body = body.take(MAX_CHARS)
            }
        }
        return body
    }
}
