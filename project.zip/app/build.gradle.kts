plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.smslocator.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.smslocator.app"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
        debug {
            // Explicit so `gradle assembleDebug` has a clearly defined, non-minified build.
            isMinifyEnabled = false
            isDebuggable = true
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    // AndroidX core + appcompat only: needed for ContextCompat/ServiceCompat/NotificationCompat
    // helpers that normalize permission, foreground-service and notification APIs across the
    // API 26-36 range this app supports, and for a DayNight-aware settings UI theme. No
    // networking, DI, image-loading or location-fused libraries are used; location and cell
    // data come straight from the framework's LocationManager and TelephonyManager.
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    // Explicit, rather than relying on it transitively through appcompat, because
    // MainActivity uses registerForActivityResult / ActivityResultContracts directly.
    implementation("androidx.activity:activity-ktx:1.9.3")
}
